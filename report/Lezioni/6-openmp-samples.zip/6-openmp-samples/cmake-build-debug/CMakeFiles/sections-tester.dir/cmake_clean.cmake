file(REMOVE_RECURSE
  "CMakeFiles/sections-tester.dir/sections-tester.cpp.o"
  "CMakeFiles/sections-tester.dir/sections-tester.cpp.o.d"
  "sections-tester"
  "sections-tester.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/sections-tester.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
