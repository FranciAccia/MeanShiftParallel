#include <iostream>
#include <iomanip>
#include <string>
#include <chrono>
#include <vector>
#include <numeric>

using namespace std;
using namespace chrono;

const int NUM_ELEMENTS = 10'000'000;

struct Person {
    Person(const string &n, uint8_t a, uint32_t d)
            : name(n), age(a), height(d) {}

    string name;
    uint8_t age;
    uint32_t height;
};

using VP = vector<Person>;

void addPerson(VP &v, Person &&p) { v.push_back(std::move(p)); }

uint64_t averageNameLen(const VP &v) {
    return accumulate(begin(v), end(v), (uint64_t) 0,
                      [](auto sum, auto &p) { return sum + p.name.length(); }) / v.size();
}

uint64_t averageAge(const VP &v) {
    return accumulate(begin(v), end(v), (uint64_t) 0,
                      [](auto sum, auto &p) { return sum + p.age; }) / v.size();
}

uint64_t averageHeigth(const VP &v) {
    return accumulate(begin(v), end(v), (uint64_t) 0,
                      [](auto sum, auto &p) { return sum + p.height; }) / v.size();
}

struct Persons {
    vector<string> names;
    vector<uint8_t> ages;
    vector<uint32_t> height;

    void addPerson(const string &n, uint8_t a, uint32_t d) {
        names.push_back(n);
        ages.push_back(a);
        height.push_back(d);
    }

    uint64_t averageNameLen() const {
        return accumulate(begin(names), end(names), (uint64_t) 0,
                          [](auto sum, auto &n) { return sum + n.length(); }) / names.size();
    }

    uint64_t averageAge() const {
        return accumulate(begin(ages), end(ages), (uint64_t) 0) / ages.size();
    }

    uint64_t averageHeight() const {
        return accumulate(begin(height), end(height), (uint64_t) 0) / height.size();
    }
};

int main(int argc, char **argv) {
    VP v1;
    v1.reserve(NUM_ELEMENTS);
    for (int i = 0; i < NUM_ELEMENTS; ++i)
        addPerson(v1, Person(string(string().capacity(), 'N'), i % 0xFF, i % 0xFFFF));

    // AoS
    auto start_time = high_resolution_clock::now();
    // use sum to avoid elimination of function calls due to compiler optimization
    auto sum = averageNameLen(v1);
    sum += averageAge(v1);
    sum += averageHeigth(v1);
    auto end_time = high_resolution_clock::now();
    cout << fixed << setprecision(3);
    auto aos_time = duration_cast<microseconds>(end_time - start_time).count() / 1000.f;
    cout << "AoS duration " << aos_time << " ms" << endl;
    v1.clear();
    v1.shrink_to_fit();

    // SoA
    Persons p;
    p.names.reserve(NUM_ELEMENTS);
    p.ages.reserve(NUM_ELEMENTS);
    p.height.reserve(NUM_ELEMENTS);
    for (int i = 0; i < NUM_ELEMENTS; ++i)
        p.addPerson(string(string().capacity(), 'N'), rand() % 0xFF, rand() % 0xFFFF);

    start_time = high_resolution_clock::now();
    sum += p.averageNameLen();
    sum += p.averageAge();
    sum += p.averageHeight();
    end_time = high_resolution_clock::now();
    auto soa_time = duration_cast<microseconds>(end_time - start_time).count() / 1000.f;
    cout << "SoA duration " << soa_time << " ms" << endl;

    cout << "Speedup SoA vs. AoS: " << float(aos_time) / soa_time << endl;
    return sum;  // to avoid elimination of function calls due to compiler optimization
}