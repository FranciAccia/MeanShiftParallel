	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 15, 0	sdk_version 26, 0
	.globl	__ZN5TimerC2Ev                  ## -- Begin function _ZN5TimerC2Ev
	.p2align	4, 0x90
__ZN5TimerC2Ev:                         ## @_ZN5TimerC2Ev
Lfunc_begin0:
	.file	0 "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization/cmake-build-debug" "Timer.cpp" md5 0x5390ff1dfa3710af1265e70f3ab7deab
	.file	1 "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization" "Timer.cpp"
	.loc	1 22 0                          ## Timer.cpp:22:0
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
Ltmp0:
	.loc	1 28 44 prologue_end            ## Timer.cpp:28:44
	movl	$0, 32(%rax)
	.loc	1 28 23 is_stmt 0               ## Timer.cpp:28:23
	movq	$0, 24(%rax)
	.loc	1 29 40 is_stmt 1               ## Timer.cpp:29:40
	movl	$0, 48(%rax)
	.loc	1 29 21 is_stmt 0               ## Timer.cpp:29:21
	movq	$0, 40(%rax)
	.loc	1 32 13 is_stmt 1               ## Timer.cpp:32:13
	movl	$0, 16(%rax)
	.loc	1 33 25                         ## Timer.cpp:33:25
	xorps	%xmm0, %xmm0
	movsd	%xmm0, (%rax)
	.loc	1 34 23                         ## Timer.cpp:34:23
	xorps	%xmm0, %xmm0
	movsd	%xmm0, 8(%rax)
Ltmp1:
	.loc	1 35 1 epilogue_begin           ## Timer.cpp:35:1
	popq	%rbp
	retq
Ltmp2:
Lfunc_end0:
	.cfi_endproc
	.file	2 "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization" "Timer.h"
	.file	3 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/i386" "_types.h"
	.file	4 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types" "_timeval.h"
	.file	5 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys" "_types.h"
                                        ## -- End function
	.globl	__ZN5TimerC1Ev                  ## -- Begin function _ZN5TimerC1Ev
	.p2align	4, 0x90
__ZN5TimerC1Ev:                         ## @_ZN5TimerC1Ev
Lfunc_begin1:
	.loc	1 22 0                          ## Timer.cpp:22:0
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rdi
Ltmp3:
	.loc	1 22 1 prologue_end             ## Timer.cpp:22:1
	callq	__ZN5TimerC2Ev
	.loc	1 35 1 epilogue_begin           ## Timer.cpp:35:1
	addq	$16, %rsp
	popq	%rbp
	retq
Ltmp4:
Lfunc_end1:
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN5TimerD2Ev                  ## -- Begin function _ZN5TimerD2Ev
	.p2align	4, 0x90
__ZN5TimerD2Ev:                         ## @_ZN5TimerD2Ev
Lfunc_begin2:
	.loc	1 43 0                          ## Timer.cpp:43:0
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
Ltmp5:
	.loc	1 44 1 prologue_end epilogue_begin ## Timer.cpp:44:1
	popq	%rbp
	retq
Ltmp6:
Lfunc_end2:
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN5TimerD1Ev                  ## -- Begin function _ZN5TimerD1Ev
	.p2align	4, 0x90
__ZN5TimerD1Ev:                         ## @_ZN5TimerD1Ev
Lfunc_begin3:
	.loc	1 43 0                          ## Timer.cpp:43:0
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rdi
Ltmp7:
	.loc	1 43 1 prologue_end             ## Timer.cpp:43:1
	callq	__ZN5TimerD2Ev
	.loc	1 44 1 epilogue_begin           ## Timer.cpp:44:1
	addq	$16, %rsp
	popq	%rbp
	retq
Ltmp8:
Lfunc_end3:
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN5Timer5startEv              ## -- Begin function _ZN5Timer5startEv
	.p2align	4, 0x90
__ZN5Timer5startEv:                     ## @_ZN5Timer5startEv
Lfunc_begin4:
	.loc	1 53 0                          ## Timer.cpp:53:0
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rdi
Ltmp9:
	.loc	1 54 13 prologue_end            ## Timer.cpp:54:13
	movl	$0, 16(%rdi)
	.loc	1 58 19                         ## Timer.cpp:58:19
	addq	$24, %rdi
	.loc	1 58 5 is_stmt 0                ## Timer.cpp:58:5
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	_gettimeofday
	.loc	1 60 1 epilogue_begin is_stmt 1 ## Timer.cpp:60:1
	addq	$16, %rsp
	popq	%rbp
	retq
Ltmp10:
Lfunc_end4:
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN5Timer4stopEv               ## -- Begin function _ZN5Timer4stopEv
	.p2align	4, 0x90
__ZN5Timer4stopEv:                      ## @_ZN5Timer4stopEv
Lfunc_begin5:
	.loc	1 69 0                          ## Timer.cpp:69:0
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rdi
Ltmp11:
	.loc	1 70 13 prologue_end            ## Timer.cpp:70:13
	movl	$1, 16(%rdi)
	.loc	1 75 19                         ## Timer.cpp:75:19
	addq	$40, %rdi
	.loc	1 75 5 is_stmt 0                ## Timer.cpp:75:5
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	_gettimeofday
	.loc	1 77 1 epilogue_begin is_stmt 1 ## Timer.cpp:77:1
	addq	$16, %rsp
	popq	%rbp
	retq
Ltmp12:
Lfunc_end5:
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ## -- Begin function _ZN5Timer24getElapsedTimeInMicroSecEv
LCPI6_0:
	.quad	0x412e848000000000              ## double 1.0E+6
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN5Timer24getElapsedTimeInMicroSecEv
	.p2align	4, 0x90
__ZN5Timer24getElapsedTimeInMicroSecEv: ## @_ZN5Timer24getElapsedTimeInMicroSecEv
Lfunc_begin6:
	.loc	1 86 0                          ## Timer.cpp:86:0
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, -16(%rbp)                 ## 8-byte Spill
Ltmp13:
	.loc	1 94 9 prologue_end             ## Timer.cpp:94:9
	cmpl	$0, 16(%rax)
Ltmp14:
	.loc	1 94 8 is_stmt 0                ## Timer.cpp:94:8
	jne	LBB6_2
## %bb.1:
	.loc	1 0 8                           ## Timer.cpp:0:8
	movq	-16(%rbp), %rdi                 ## 8-byte Reload
Ltmp15:
	.loc	1 95 23 is_stmt 1               ## Timer.cpp:95:23
	addq	$40, %rdi
	.loc	1 95 9 is_stmt 0                ## Timer.cpp:95:9
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	_gettimeofday
Ltmp16:
LBB6_2:
	.loc	1 0 9                           ## Timer.cpp:0:9
	movq	-16(%rbp), %rax                 ## 8-byte Reload
	.loc	1 97 28 is_stmt 1               ## Timer.cpp:97:28
	cvtsi2sdq	24(%rax), %xmm0
	.loc	1 97 61 is_stmt 0               ## Timer.cpp:97:61
	cvtsi2sdl	32(%rax), %xmm1
	movsd	LCPI6_0(%rip), %xmm2            ## xmm2 = [1.0E+6,0.0E+0]
	.loc	1 97 59                         ## Timer.cpp:97:59
	mulsd	%xmm2, %xmm0
	addsd	%xmm1, %xmm0
	.loc	1 97 25                         ## Timer.cpp:97:25
	movsd	%xmm0, (%rax)
	.loc	1 98 26 is_stmt 1               ## Timer.cpp:98:26
	cvtsi2sdq	40(%rax), %xmm0
	.loc	1 98 57 is_stmt 0               ## Timer.cpp:98:57
	cvtsi2sdl	48(%rax), %xmm1
	movsd	LCPI6_0(%rip), %xmm2            ## xmm2 = [1.0E+6,0.0E+0]
	.loc	1 98 55                         ## Timer.cpp:98:55
	mulsd	%xmm2, %xmm0
	addsd	%xmm1, %xmm0
	.loc	1 98 23                         ## Timer.cpp:98:23
	movsd	%xmm0, 8(%rax)
	.loc	1 101 12 is_stmt 1              ## Timer.cpp:101:12
	movsd	8(%rax), %xmm0                  ## xmm0 = mem[0],zero
	.loc	1 101 30 is_stmt 0              ## Timer.cpp:101:30
	subsd	(%rax), %xmm0
	.loc	1 101 5 epilogue_begin          ## Timer.cpp:101:5
	addq	$16, %rsp
	popq	%rbp
	retq
Ltmp17:
Lfunc_end6:
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ## -- Begin function _ZN5Timer24getElapsedTimeInMilliSecEv
LCPI7_0:
	.quad	0x3f50624dd2f1a9fc              ## double 0.001
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN5Timer24getElapsedTimeInMilliSecEv
	.p2align	4, 0x90
__ZN5Timer24getElapsedTimeInMilliSecEv: ## @_ZN5Timer24getElapsedTimeInMilliSecEv
Lfunc_begin7:
	.loc	1 110 0 is_stmt 1               ## Timer.cpp:110:0
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rdi
Ltmp18:
	.loc	1 111 18 prologue_end           ## Timer.cpp:111:18
	callq	__ZN5Timer24getElapsedTimeInMicroSecEv
	.loc	1 111 45 is_stmt 0              ## Timer.cpp:111:45
	movsd	LCPI7_0(%rip), %xmm1            ## xmm1 = [1.0E-3,0.0E+0]
	mulsd	%xmm1, %xmm0
	.loc	1 111 5 epilogue_begin          ## Timer.cpp:111:5
	addq	$16, %rsp
	popq	%rbp
	retq
Ltmp19:
Lfunc_end7:
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ## -- Begin function _ZN5Timer19getElapsedTimeInSecEv
LCPI8_0:
	.quad	0x3eb0c6f7a0b5ed8d              ## double 9.9999999999999995E-7
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN5Timer19getElapsedTimeInSecEv
	.p2align	4, 0x90
__ZN5Timer19getElapsedTimeInSecEv:      ## @_ZN5Timer19getElapsedTimeInSecEv
Lfunc_begin8:
	.loc	1 120 0 is_stmt 1               ## Timer.cpp:120:0
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rdi
Ltmp20:
	.loc	1 121 18 prologue_end           ## Timer.cpp:121:18
	callq	__ZN5Timer24getElapsedTimeInMicroSecEv
	.loc	1 121 45 is_stmt 0              ## Timer.cpp:121:45
	movsd	LCPI8_0(%rip), %xmm1            ## xmm1 = [9.9999999999999995E-7,0.0E+0]
	mulsd	%xmm1, %xmm0
	.loc	1 121 5 epilogue_begin          ## Timer.cpp:121:5
	addq	$16, %rsp
	popq	%rbp
	retq
Ltmp21:
Lfunc_end8:
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN5Timer14getElapsedTimeEv    ## -- Begin function _ZN5Timer14getElapsedTimeEv
	.p2align	4, 0x90
__ZN5Timer14getElapsedTimeEv:           ## @_ZN5Timer14getElapsedTimeEv
Lfunc_begin9:
	.loc	1 130 0 is_stmt 1               ## Timer.cpp:130:0
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rdi
Ltmp22:
	.loc	1 131 18 prologue_end           ## Timer.cpp:131:18
	callq	__ZN5Timer19getElapsedTimeInSecEv
	.loc	1 131 5 epilogue_begin is_stmt 0 ## Timer.cpp:131:5
	addq	$16, %rsp
	popq	%rbp
	retq
Ltmp23:
Lfunc_end9:
	.cfi_endproc
                                        ## -- End function
	.section	__DWARF,__debug_abbrev,regular,debug
Lsection_abbrev:
	.byte	1                               ## Abbreviation Code
	.byte	17                              ## DW_TAG_compile_unit
	.byte	1                               ## DW_CHILDREN_yes
	.byte	37                              ## DW_AT_producer
	.byte	37                              ## DW_FORM_strx1
	.byte	19                              ## DW_AT_language
	.byte	5                               ## DW_FORM_data2
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.ascii	"\202|"                         ## DW_AT_LLVM_sysroot
	.byte	37                              ## DW_FORM_strx1
	.byte	114                             ## DW_AT_str_offsets_base
	.byte	23                              ## DW_FORM_sec_offset
	.byte	16                              ## DW_AT_stmt_list
	.byte	23                              ## DW_FORM_sec_offset
	.byte	27                              ## DW_AT_comp_dir
	.byte	37                              ## DW_FORM_strx1
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	115                             ## DW_AT_addr_base
	.byte	23                              ## DW_FORM_sec_offset
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	2                               ## Abbreviation Code
	.byte	2                               ## DW_TAG_class_type
	.byte	1                               ## DW_CHILDREN_yes
	.byte	54                              ## DW_AT_calling_convention
	.byte	11                              ## DW_FORM_data1
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	11                              ## DW_AT_byte_size
	.byte	11                              ## DW_FORM_data1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	3                               ## Abbreviation Code
	.byte	13                              ## DW_TAG_member
	.byte	0                               ## DW_CHILDREN_no
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	56                              ## DW_AT_data_member_location
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	4                               ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	60                              ## DW_AT_declaration
	.byte	25                              ## DW_FORM_flag_present
	.byte	63                              ## DW_AT_external
	.byte	25                              ## DW_FORM_flag_present
	.byte	50                              ## DW_AT_accessibility
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	5                               ## Abbreviation Code
	.byte	5                               ## DW_TAG_formal_parameter
	.byte	0                               ## DW_CHILDREN_no
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	52                              ## DW_AT_artificial
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	6                               ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	110                             ## DW_AT_linkage_name
	.byte	37                              ## DW_FORM_strx1
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	60                              ## DW_AT_declaration
	.byte	25                              ## DW_FORM_flag_present
	.byte	63                              ## DW_AT_external
	.byte	25                              ## DW_FORM_flag_present
	.byte	50                              ## DW_AT_accessibility
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	7                               ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	110                             ## DW_AT_linkage_name
	.byte	37                              ## DW_FORM_strx1
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	60                              ## DW_AT_declaration
	.byte	25                              ## DW_FORM_flag_present
	.byte	63                              ## DW_AT_external
	.byte	25                              ## DW_FORM_flag_present
	.byte	50                              ## DW_AT_accessibility
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	8                               ## Abbreviation Code
	.byte	36                              ## DW_TAG_base_type
	.byte	0                               ## DW_CHILDREN_no
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	62                              ## DW_AT_encoding
	.byte	11                              ## DW_FORM_data1
	.byte	11                              ## DW_AT_byte_size
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	9                               ## Abbreviation Code
	.byte	19                              ## DW_TAG_structure_type
	.byte	1                               ## DW_CHILDREN_yes
	.byte	54                              ## DW_AT_calling_convention
	.byte	11                              ## DW_FORM_data1
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	11                              ## DW_AT_byte_size
	.byte	11                              ## DW_FORM_data1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	10                              ## Abbreviation Code
	.byte	22                              ## DW_TAG_typedef
	.byte	0                               ## DW_CHILDREN_no
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	11                              ## Abbreviation Code
	.byte	15                              ## DW_TAG_pointer_type
	.byte	0                               ## DW_CHILDREN_no
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	12                              ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	64                              ## DW_AT_frame_base
	.byte	24                              ## DW_FORM_exprloc
	.byte	100                             ## DW_AT_object_pointer
	.byte	19                              ## DW_FORM_ref4
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	110                             ## DW_AT_linkage_name
	.byte	37                              ## DW_FORM_strx1
	.byte	71                              ## DW_AT_specification
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	13                              ## Abbreviation Code
	.byte	5                               ## DW_TAG_formal_parameter
	.byte	0                               ## DW_CHILDREN_no
	.byte	2                               ## DW_AT_location
	.byte	24                              ## DW_FORM_exprloc
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	52                              ## DW_AT_artificial
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	14                              ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	64                              ## DW_AT_frame_base
	.byte	24                              ## DW_FORM_exprloc
	.byte	100                             ## DW_AT_object_pointer
	.byte	19                              ## DW_FORM_ref4
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	71                              ## DW_AT_specification
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	0                               ## EOM(3)
	.section	__DWARF,__debug_info,regular,debug
Lsection_info:
Lcu_begin0:
.set Lset0, Ldebug_info_end0-Ldebug_info_start0 ## Length of Unit
	.long	Lset0
Ldebug_info_start0:
	.short	5                               ## DWARF version number
	.byte	1                               ## DWARF Unit Type
	.byte	8                               ## Address Size (in bytes)
.set Lset1, Lsection_abbrev-Lsection_abbrev ## Offset Into Abbrev. Section
	.long	Lset1
	.byte	1                               ## Abbrev [1] 0xc:0x21e DW_TAG_compile_unit
	.byte	0                               ## DW_AT_producer
	.short	26                              ## DW_AT_language
	.byte	1                               ## DW_AT_name
	.byte	2                               ## DW_AT_LLVM_sysroot
.set Lset2, Lstr_offsets_base0-Lsection_str_off ## DW_AT_str_offsets_base
	.long	Lset2
.set Lset3, Lline_table_start0-Lsection_line ## DW_AT_stmt_list
	.long	Lset3
	.byte	3                               ## DW_AT_comp_dir
	.byte	0                               ## DW_AT_low_pc
.set Lset4, Lfunc_end9-Lfunc_begin0     ## DW_AT_high_pc
	.long	Lset4
.set Lset5, Laddr_table_base0-Lsection_info0 ## DW_AT_addr_base
	.long	Lset5
	.byte	2                               ## Abbrev [2] 0x24:0xa2 DW_TAG_class_type
	.byte	4                               ## DW_AT_calling_convention
	.byte	18                              ## DW_AT_name
	.byte	56                              ## DW_AT_byte_size
	.byte	2                               ## DW_AT_decl_file
	.byte	25                              ## DW_AT_decl_line
	.byte	3                               ## Abbrev [3] 0x2a:0x9 DW_TAG_member
	.byte	4                               ## DW_AT_name
	.long	198                             ## DW_AT_type
	.byte	2                               ## DW_AT_decl_file
	.byte	43                              ## DW_AT_decl_line
	.byte	0                               ## DW_AT_data_member_location
	.byte	3                               ## Abbrev [3] 0x33:0x9 DW_TAG_member
	.byte	6                               ## DW_AT_name
	.long	198                             ## DW_AT_type
	.byte	2                               ## DW_AT_decl_file
	.byte	44                              ## DW_AT_decl_line
	.byte	8                               ## DW_AT_data_member_location
	.byte	3                               ## Abbrev [3] 0x3c:0x9 DW_TAG_member
	.byte	7                               ## DW_AT_name
	.long	202                             ## DW_AT_type
	.byte	2                               ## DW_AT_decl_file
	.byte	45                              ## DW_AT_decl_line
	.byte	16                              ## DW_AT_data_member_location
	.byte	3                               ## Abbrev [3] 0x45:0x9 DW_TAG_member
	.byte	9                               ## DW_AT_name
	.long	206                             ## DW_AT_type
	.byte	2                               ## DW_AT_decl_file
	.byte	51                              ## DW_AT_decl_line
	.byte	24                              ## DW_AT_data_member_location
	.byte	3                               ## Abbrev [3] 0x4e:0x9 DW_TAG_member
	.byte	17                              ## DW_AT_name
	.long	206                             ## DW_AT_type
	.byte	2                               ## DW_AT_decl_file
	.byte	52                              ## DW_AT_decl_line
	.byte	40                              ## DW_AT_data_member_location
	.byte	4                               ## Abbrev [4] 0x57:0xb DW_TAG_subprogram
	.byte	18                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	28                              ## DW_AT_decl_line
                                        ## DW_AT_declaration
                                        ## DW_AT_external
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0x5c:0x5 DW_TAG_formal_parameter
	.long	259                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	4                               ## Abbrev [4] 0x62:0xb DW_TAG_subprogram
	.byte	19                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	29                              ## DW_AT_decl_line
                                        ## DW_AT_declaration
                                        ## DW_AT_external
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0x67:0x5 DW_TAG_formal_parameter
	.long	259                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	6                               ## Abbrev [6] 0x6d:0xc DW_TAG_subprogram
	.byte	20                              ## DW_AT_linkage_name
	.byte	21                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	31                              ## DW_AT_decl_line
                                        ## DW_AT_declaration
                                        ## DW_AT_external
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0x73:0x5 DW_TAG_formal_parameter
	.long	259                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	6                               ## Abbrev [6] 0x79:0xc DW_TAG_subprogram
	.byte	22                              ## DW_AT_linkage_name
	.byte	23                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	32                              ## DW_AT_decl_line
                                        ## DW_AT_declaration
                                        ## DW_AT_external
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0x7f:0x5 DW_TAG_formal_parameter
	.long	259                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	7                               ## Abbrev [7] 0x85:0x10 DW_TAG_subprogram
	.byte	24                              ## DW_AT_linkage_name
	.byte	25                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	33                              ## DW_AT_decl_line
	.long	198                             ## DW_AT_type
                                        ## DW_AT_declaration
                                        ## DW_AT_external
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0x8f:0x5 DW_TAG_formal_parameter
	.long	259                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	7                               ## Abbrev [7] 0x95:0x10 DW_TAG_subprogram
	.byte	26                              ## DW_AT_linkage_name
	.byte	27                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	34                              ## DW_AT_decl_line
	.long	198                             ## DW_AT_type
                                        ## DW_AT_declaration
                                        ## DW_AT_external
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0x9f:0x5 DW_TAG_formal_parameter
	.long	259                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	7                               ## Abbrev [7] 0xa5:0x10 DW_TAG_subprogram
	.byte	28                              ## DW_AT_linkage_name
	.byte	29                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	35                              ## DW_AT_decl_line
	.long	198                             ## DW_AT_type
                                        ## DW_AT_declaration
                                        ## DW_AT_external
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0xaf:0x5 DW_TAG_formal_parameter
	.long	259                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	7                               ## Abbrev [7] 0xb5:0x10 DW_TAG_subprogram
	.byte	30                              ## DW_AT_linkage_name
	.byte	31                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	36                              ## DW_AT_decl_line
	.long	198                             ## DW_AT_type
                                        ## DW_AT_declaration
                                        ## DW_AT_external
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0xbf:0x5 DW_TAG_formal_parameter
	.long	259                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	0                               ## End Of Children Mark
	.byte	8                               ## Abbrev [8] 0xc6:0x4 DW_TAG_base_type
	.byte	5                               ## DW_AT_name
	.byte	4                               ## DW_AT_encoding
	.byte	8                               ## DW_AT_byte_size
	.byte	8                               ## Abbrev [8] 0xca:0x4 DW_TAG_base_type
	.byte	8                               ## DW_AT_name
	.byte	5                               ## DW_AT_encoding
	.byte	4                               ## DW_AT_byte_size
	.byte	9                               ## Abbrev [9] 0xce:0x19 DW_TAG_structure_type
	.byte	5                               ## DW_AT_calling_convention
	.byte	16                              ## DW_AT_name
	.byte	16                              ## DW_AT_byte_size
	.byte	4                               ## DW_AT_decl_file
	.byte	34                              ## DW_AT_decl_line
	.byte	3                               ## Abbrev [3] 0xd4:0x9 DW_TAG_member
	.byte	10                              ## DW_AT_name
	.long	231                             ## DW_AT_type
	.byte	4                               ## DW_AT_decl_file
	.byte	36                              ## DW_AT_decl_line
	.byte	0                               ## DW_AT_data_member_location
	.byte	3                               ## Abbrev [3] 0xdd:0x9 DW_TAG_member
	.byte	13                              ## DW_AT_name
	.long	243                             ## DW_AT_type
	.byte	4                               ## DW_AT_decl_file
	.byte	37                              ## DW_AT_decl_line
	.byte	8                               ## DW_AT_data_member_location
	.byte	0                               ## End Of Children Mark
	.byte	10                              ## Abbrev [10] 0xe7:0x8 DW_TAG_typedef
	.long	239                             ## DW_AT_type
	.byte	12                              ## DW_AT_name
	.byte	3                               ## DW_AT_decl_file
	.byte	143                             ## DW_AT_decl_line
	.byte	8                               ## Abbrev [8] 0xef:0x4 DW_TAG_base_type
	.byte	11                              ## DW_AT_name
	.byte	5                               ## DW_AT_encoding
	.byte	8                               ## DW_AT_byte_size
	.byte	10                              ## Abbrev [10] 0xf3:0x8 DW_TAG_typedef
	.long	251                             ## DW_AT_type
	.byte	15                              ## DW_AT_name
	.byte	5                               ## DW_AT_decl_file
	.byte	86                              ## DW_AT_decl_line
	.byte	10                              ## Abbrev [10] 0xfb:0x8 DW_TAG_typedef
	.long	202                             ## DW_AT_type
	.byte	14                              ## DW_AT_name
	.byte	3                               ## DW_AT_decl_file
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## Abbrev [11] 0x103:0x5 DW_TAG_pointer_type
	.long	36                              ## DW_AT_type
	.byte	12                              ## Abbrev [12] 0x108:0x1d DW_TAG_subprogram
	.byte	0                               ## DW_AT_low_pc
.set Lset6, Lfunc_end0-Lfunc_begin0     ## DW_AT_high_pc
	.long	Lset6
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	283                             ## DW_AT_object_pointer
	.byte	1                               ## DW_AT_decl_file
	.byte	21                              ## DW_AT_decl_line
	.byte	32                              ## DW_AT_linkage_name
	.long	87                              ## DW_AT_specification
	.byte	13                              ## Abbrev [13] 0x11b:0x9 DW_TAG_formal_parameter
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	120
	.byte	36                              ## DW_AT_name
	.long	548                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	12                              ## Abbrev [12] 0x125:0x1d DW_TAG_subprogram
	.byte	1                               ## DW_AT_low_pc
.set Lset7, Lfunc_end1-Lfunc_begin1     ## DW_AT_high_pc
	.long	Lset7
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	312                             ## DW_AT_object_pointer
	.byte	1                               ## DW_AT_decl_file
	.byte	21                              ## DW_AT_decl_line
	.byte	33                              ## DW_AT_linkage_name
	.long	87                              ## DW_AT_specification
	.byte	13                              ## Abbrev [13] 0x138:0x9 DW_TAG_formal_parameter
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	120
	.byte	36                              ## DW_AT_name
	.long	548                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	12                              ## Abbrev [12] 0x142:0x1d DW_TAG_subprogram
	.byte	2                               ## DW_AT_low_pc
.set Lset8, Lfunc_end2-Lfunc_begin2     ## DW_AT_high_pc
	.long	Lset8
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	341                             ## DW_AT_object_pointer
	.byte	1                               ## DW_AT_decl_file
	.byte	42                              ## DW_AT_decl_line
	.byte	34                              ## DW_AT_linkage_name
	.long	98                              ## DW_AT_specification
	.byte	13                              ## Abbrev [13] 0x155:0x9 DW_TAG_formal_parameter
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	120
	.byte	36                              ## DW_AT_name
	.long	548                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	12                              ## Abbrev [12] 0x15f:0x1d DW_TAG_subprogram
	.byte	3                               ## DW_AT_low_pc
.set Lset9, Lfunc_end3-Lfunc_begin3     ## DW_AT_high_pc
	.long	Lset9
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	370                             ## DW_AT_object_pointer
	.byte	1                               ## DW_AT_decl_file
	.byte	42                              ## DW_AT_decl_line
	.byte	35                              ## DW_AT_linkage_name
	.long	98                              ## DW_AT_specification
	.byte	13                              ## Abbrev [13] 0x172:0x9 DW_TAG_formal_parameter
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	120
	.byte	36                              ## DW_AT_name
	.long	548                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	14                              ## Abbrev [14] 0x17c:0x1c DW_TAG_subprogram
	.byte	4                               ## DW_AT_low_pc
.set Lset10, Lfunc_end4-Lfunc_begin4    ## DW_AT_high_pc
	.long	Lset10
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	398                             ## DW_AT_object_pointer
	.byte	1                               ## DW_AT_decl_file
	.byte	52                              ## DW_AT_decl_line
	.long	109                             ## DW_AT_specification
	.byte	13                              ## Abbrev [13] 0x18e:0x9 DW_TAG_formal_parameter
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	120
	.byte	36                              ## DW_AT_name
	.long	548                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	14                              ## Abbrev [14] 0x198:0x1c DW_TAG_subprogram
	.byte	5                               ## DW_AT_low_pc
.set Lset11, Lfunc_end5-Lfunc_begin5    ## DW_AT_high_pc
	.long	Lset11
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	426                             ## DW_AT_object_pointer
	.byte	1                               ## DW_AT_decl_file
	.byte	68                              ## DW_AT_decl_line
	.long	121                             ## DW_AT_specification
	.byte	13                              ## Abbrev [13] 0x1aa:0x9 DW_TAG_formal_parameter
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	120
	.byte	36                              ## DW_AT_name
	.long	548                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	14                              ## Abbrev [14] 0x1b4:0x1c DW_TAG_subprogram
	.byte	6                               ## DW_AT_low_pc
.set Lset12, Lfunc_end6-Lfunc_begin6    ## DW_AT_high_pc
	.long	Lset12
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	454                             ## DW_AT_object_pointer
	.byte	1                               ## DW_AT_decl_file
	.byte	85                              ## DW_AT_decl_line
	.long	181                             ## DW_AT_specification
	.byte	13                              ## Abbrev [13] 0x1c6:0x9 DW_TAG_formal_parameter
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	120
	.byte	36                              ## DW_AT_name
	.long	548                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	14                              ## Abbrev [14] 0x1d0:0x1c DW_TAG_subprogram
	.byte	7                               ## DW_AT_low_pc
.set Lset13, Lfunc_end7-Lfunc_begin7    ## DW_AT_high_pc
	.long	Lset13
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	482                             ## DW_AT_object_pointer
	.byte	1                               ## DW_AT_decl_file
	.byte	109                             ## DW_AT_decl_line
	.long	165                             ## DW_AT_specification
	.byte	13                              ## Abbrev [13] 0x1e2:0x9 DW_TAG_formal_parameter
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	120
	.byte	36                              ## DW_AT_name
	.long	548                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	14                              ## Abbrev [14] 0x1ec:0x1c DW_TAG_subprogram
	.byte	8                               ## DW_AT_low_pc
.set Lset14, Lfunc_end8-Lfunc_begin8    ## DW_AT_high_pc
	.long	Lset14
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	510                             ## DW_AT_object_pointer
	.byte	1                               ## DW_AT_decl_file
	.byte	119                             ## DW_AT_decl_line
	.long	149                             ## DW_AT_specification
	.byte	13                              ## Abbrev [13] 0x1fe:0x9 DW_TAG_formal_parameter
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	120
	.byte	36                              ## DW_AT_name
	.long	548                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	14                              ## Abbrev [14] 0x208:0x1c DW_TAG_subprogram
	.byte	9                               ## DW_AT_low_pc
.set Lset15, Lfunc_end9-Lfunc_begin9    ## DW_AT_high_pc
	.long	Lset15
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	538                             ## DW_AT_object_pointer
	.byte	1                               ## DW_AT_decl_file
	.byte	129                             ## DW_AT_decl_line
	.long	133                             ## DW_AT_specification
	.byte	13                              ## Abbrev [13] 0x21a:0x9 DW_TAG_formal_parameter
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	120
	.byte	36                              ## DW_AT_name
	.long	548                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	11                              ## Abbrev [11] 0x224:0x5 DW_TAG_pointer_type
	.long	36                              ## DW_AT_type
	.byte	0                               ## End Of Children Mark
Ldebug_info_end0:
	.section	__DWARF,__debug_str_offs,regular,debug
Lsection_str_off:
	.long	152                             ## Length of String Offsets Set
	.short	5
	.short	0
Lstr_offsets_base0:
	.section	__DWARF,__debug_str,regular,debug
Linfo_string:
	.asciz	"Apple clang version 17.0.0 (clang-1700.3.19.1)" ## string offset=0
	.asciz	"Timer.cpp"                     ## string offset=47
	.asciz	"/"                             ## string offset=57
	.asciz	"/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization/cmake-build-debug" ## string offset=59
	.asciz	"Timer"                         ## string offset=192
	.asciz	"startTimeInMicroSec"           ## string offset=198
	.asciz	"double"                        ## string offset=218
	.asciz	"endTimeInMicroSec"             ## string offset=225
	.asciz	"stopped"                       ## string offset=243
	.asciz	"int"                           ## string offset=251
	.asciz	"startCount"                    ## string offset=255
	.asciz	"timeval"                       ## string offset=266
	.asciz	"tv_sec"                        ## string offset=274
	.asciz	"__darwin_time_t"               ## string offset=281
	.asciz	"long"                          ## string offset=297
	.asciz	"tv_usec"                       ## string offset=302
	.asciz	"__darwin_suseconds_t"          ## string offset=310
	.asciz	"__int32_t"                     ## string offset=331
	.asciz	"endCount"                      ## string offset=341
	.asciz	"~Timer"                        ## string offset=350
	.asciz	"_ZN5Timer5startEv"             ## string offset=357
	.asciz	"start"                         ## string offset=375
	.asciz	"_ZN5Timer4stopEv"              ## string offset=381
	.asciz	"stop"                          ## string offset=398
	.asciz	"_ZN5Timer14getElapsedTimeEv"   ## string offset=403
	.asciz	"getElapsedTime"                ## string offset=431
	.asciz	"_ZN5Timer19getElapsedTimeInSecEv" ## string offset=446
	.asciz	"getElapsedTimeInSec"           ## string offset=479
	.asciz	"_ZN5Timer24getElapsedTimeInMilliSecEv" ## string offset=499
	.asciz	"getElapsedTimeInMilliSec"      ## string offset=537
	.asciz	"_ZN5Timer24getElapsedTimeInMicroSecEv" ## string offset=562
	.asciz	"getElapsedTimeInMicroSec"      ## string offset=600
	.asciz	"_ZN5TimerC2Ev"                 ## string offset=625
	.asciz	"_ZN5TimerC1Ev"                 ## string offset=639
	.asciz	"_ZN5TimerD2Ev"                 ## string offset=653
	.asciz	"_ZN5TimerD1Ev"                 ## string offset=667
	.asciz	"this"                          ## string offset=681
	.section	__DWARF,__debug_str_offs,regular,debug
	.long	0
	.long	47
	.long	57
	.long	59
	.long	198
	.long	218
	.long	225
	.long	243
	.long	251
	.long	255
	.long	274
	.long	297
	.long	281
	.long	302
	.long	331
	.long	310
	.long	266
	.long	341
	.long	192
	.long	350
	.long	357
	.long	375
	.long	381
	.long	398
	.long	403
	.long	431
	.long	446
	.long	479
	.long	499
	.long	537
	.long	562
	.long	600
	.long	625
	.long	639
	.long	653
	.long	667
	.long	681
	.section	__DWARF,__debug_addr,regular,debug
Lsection_info0:
.set Lset16, Ldebug_addr_end0-Ldebug_addr_start0 ## Length of contribution
	.long	Lset16
Ldebug_addr_start0:
	.short	5                               ## DWARF version number
	.byte	8                               ## Address size
	.byte	0                               ## Segment selector size
Laddr_table_base0:
	.quad	Lfunc_begin0
	.quad	Lfunc_begin1
	.quad	Lfunc_begin2
	.quad	Lfunc_begin3
	.quad	Lfunc_begin4
	.quad	Lfunc_begin5
	.quad	Lfunc_begin6
	.quad	Lfunc_begin7
	.quad	Lfunc_begin8
	.quad	Lfunc_begin9
Ldebug_addr_end0:
	.section	__DWARF,__debug_names,regular,debug
Ldebug_names_begin:
.set Lset17, Lnames_end0-Lnames_start0  ## Header: unit length
	.long	Lset17
Lnames_start0:
	.short	5                               ## Header: version
	.short	0                               ## Header: padding
	.long	1                               ## Header: compilation unit count
	.long	0                               ## Header: local type unit count
	.long	0                               ## Header: foreign type unit count
	.long	12                              ## Header: bucket count
	.long	25                              ## Header: name count
.set Lset18, Lnames_abbrev_end0-Lnames_abbrev_start0 ## Header: abbreviation table size
	.long	Lset18
	.long	8                               ## Header: augmentation string size
	.ascii	"LLVM0700"                      ## Header: augmentation string
.set Lset19, Lcu_begin0-Lsection_info   ## Compilation unit 0
	.long	Lset19
	.long	1                               ## Bucket 0
	.long	3                               ## Bucket 1
	.long	5                               ## Bucket 2
	.long	8                               ## Bucket 3
	.long	11                              ## Bucket 4
	.long	13                              ## Bucket 5
	.long	14                              ## Bucket 6
	.long	16                              ## Bucket 7
	.long	18                              ## Bucket 8
	.long	20                              ## Bucket 9
	.long	22                              ## Bucket 10
	.long	24                              ## Bucket 11
	.long	320097312                       ## Hash in Bucket 0
	.long	1294271460                      ## Hash in Bucket 0
	.long	-1022442159                     ## Hash in Bucket 1
	.long	-243996567                      ## Hash in Bucket 1
	.long	275614598                       ## Hash in Bucket 2
	.long	306366014                       ## Hash in Bucket 2
	.long	-1152108686                     ## Hash in Bucket 2
	.long	2090736459                      ## Hash in Bucket 3
	.long	-503405833                      ## Hash in Bucket 3
	.long	-328721329                      ## Hash in Bucket 3
	.long	909610852                       ## Hash in Bucket 4
	.long	-113419488                      ## Hash in Bucket 4
	.long	-1752945767                     ## Hash in Bucket 5
	.long	1561878438                      ## Hash in Bucket 6
	.long	1950534918                      ## Hash in Bucket 6
	.long	274811347                       ## Hash in Bucket 7
	.long	-1022405133                     ## Hash in Bucket 7
	.long	193495088                       ## Hash in Bucket 8
	.long	621809660                       ## Hash in Bucket 8
	.long	2090479413                      ## Hash in Bucket 9
	.long	-1308701839                     ## Hash in Bucket 9
	.long	-1022441070                     ## Hash in Bucket 10
	.long	-1022406222                     ## Hash in Bucket 10
	.long	651253403                       ## Hash in Bucket 11
	.long	1972495511                      ## Hash in Bucket 11
	.long	357                             ## String in Bucket 0: _ZN5Timer5startEv
	.long	479                             ## String in Bucket 0: getElapsedTimeInSec
	.long	639                             ## String in Bucket 1: _ZN5TimerC1Ev
	.long	281                             ## String in Bucket 1: __darwin_time_t
	.long	192                             ## String in Bucket 2: Timer
	.long	600                             ## String in Bucket 2: getElapsedTimeInMicroSec
	.long	431                             ## String in Bucket 2: getElapsedTime
	.long	398                             ## String in Bucket 3: stop
	.long	266                             ## String in Bucket 3: timeval
	.long	403                             ## String in Bucket 3: _ZN5Timer14getElapsedTimeEv
	.long	350                             ## String in Bucket 4: ~Timer
	.long	218                             ## String in Bucket 4: double
	.long	499                             ## String in Bucket 5: _ZN5Timer24getElapsedTimeInMilliSecEv
	.long	446                             ## String in Bucket 6: _ZN5Timer19getElapsedTimeInSecEv
	.long	331                             ## String in Bucket 6: __int32_t
	.long	375                             ## String in Bucket 7: start
	.long	653                             ## String in Bucket 7: _ZN5TimerD2Ev
	.long	251                             ## String in Bucket 8: int
	.long	562                             ## String in Bucket 8: _ZN5Timer24getElapsedTimeInMicroSecEv
	.long	297                             ## String in Bucket 9: long
	.long	310                             ## String in Bucket 9: __darwin_suseconds_t
	.long	625                             ## String in Bucket 10: _ZN5TimerC2Ev
	.long	667                             ## String in Bucket 10: _ZN5TimerD1Ev
	.long	537                             ## String in Bucket 11: getElapsedTimeInMilliSec
	.long	381                             ## String in Bucket 11: _ZN5Timer4stopEv
.set Lset20, Lnames14-Lnames_entries0   ## Offset in Bucket 0
	.long	Lset20
.set Lset21, Lnames21-Lnames_entries0   ## Offset in Bucket 0
	.long	Lset21
.set Lset22, Lnames9-Lnames_entries0    ## Offset in Bucket 1
	.long	Lset22
.set Lset23, Lnames4-Lnames_entries0    ## Offset in Bucket 1
	.long	Lset23
.set Lset24, Lnames0-Lnames_entries0    ## Offset in Bucket 2
	.long	Lset24
.set Lset25, Lnames17-Lnames_entries0   ## Offset in Bucket 2
	.long	Lset25
.set Lset26, Lnames23-Lnames_entries0   ## Offset in Bucket 2
	.long	Lset26
.set Lset27, Lnames15-Lnames_entries0   ## Offset in Bucket 3
	.long	Lset27
.set Lset28, Lnames3-Lnames_entries0    ## Offset in Bucket 3
	.long	Lset28
.set Lset29, Lnames24-Lnames_entries0   ## Offset in Bucket 3
	.long	Lset29
.set Lset30, Lnames10-Lnames_entries0   ## Offset in Bucket 4
	.long	Lset30
.set Lset31, Lnames1-Lnames_entries0    ## Offset in Bucket 4
	.long	Lset31
.set Lset32, Lnames20-Lnames_entries0   ## Offset in Bucket 5
	.long	Lset32
.set Lset33, Lnames22-Lnames_entries0   ## Offset in Bucket 6
	.long	Lset33
.set Lset34, Lnames7-Lnames_entries0    ## Offset in Bucket 6
	.long	Lset34
.set Lset35, Lnames13-Lnames_entries0   ## Offset in Bucket 7
	.long	Lset35
.set Lset36, Lnames11-Lnames_entries0   ## Offset in Bucket 7
	.long	Lset36
.set Lset37, Lnames2-Lnames_entries0    ## Offset in Bucket 8
	.long	Lset37
.set Lset38, Lnames18-Lnames_entries0   ## Offset in Bucket 8
	.long	Lset38
.set Lset39, Lnames5-Lnames_entries0    ## Offset in Bucket 9
	.long	Lset39
.set Lset40, Lnames6-Lnames_entries0    ## Offset in Bucket 9
	.long	Lset40
.set Lset41, Lnames8-Lnames_entries0    ## Offset in Bucket 10
	.long	Lset41
.set Lset42, Lnames12-Lnames_entries0   ## Offset in Bucket 10
	.long	Lset42
.set Lset43, Lnames19-Lnames_entries0   ## Offset in Bucket 11
	.long	Lset43
.set Lset44, Lnames16-Lnames_entries0   ## Offset in Bucket 11
	.long	Lset44
Lnames_abbrev_start0:
	.byte	1                               ## Abbrev code
	.byte	46                              ## DW_TAG_subprogram
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	2                               ## Abbrev code
	.byte	22                              ## DW_TAG_typedef
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	3                               ## Abbrev code
	.byte	2                               ## DW_TAG_class_type
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	4                               ## Abbrev code
	.byte	19                              ## DW_TAG_structure_type
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	5                               ## Abbrev code
	.byte	36                              ## DW_TAG_base_type
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev list
Lnames_abbrev_end0:
Lnames_entries0:
Lnames14:
L15:
	.byte	1                               ## Abbreviation code
	.long	380                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5Timer5startEv
Lnames21:
L12:
	.byte	1                               ## Abbreviation code
	.long	492                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: getElapsedTimeInSec
Lnames9:
L1:
	.byte	1                               ## Abbreviation code
	.long	293                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5TimerC1Ev
Lnames4:
L7:
	.byte	2                               ## Abbreviation code
	.long	231                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: __darwin_time_t
Lnames0:
L2:
	.byte	3                               ## Abbreviation code
	.long	36                              ## DW_IDX_die_offset
L8:                                     ## DW_IDX_parent
	.byte	1                               ## Abbreviation code
	.long	264                             ## DW_IDX_die_offset
	.byte	1                               ## DW_IDX_parent
                                        ## Abbreviation code
	.long	293                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: Timer
Lnames17:
L5:
	.byte	1                               ## Abbreviation code
	.long	436                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: getElapsedTimeInMicroSec
Lnames23:
L0:
	.byte	1                               ## Abbreviation code
	.long	520                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: getElapsedTime
Lnames15:
L14:
	.byte	1                               ## Abbreviation code
	.long	408                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: stop
Lnames3:
L9:
	.byte	4                               ## Abbreviation code
	.long	206                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: timeval
Lnames24:
	.byte	1                               ## Abbreviation code
	.long	520                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5Timer14getElapsedTimeEv
Lnames10:
L10:
	.byte	1                               ## Abbreviation code
	.long	322                             ## DW_IDX_die_offset
L4:                                     ## DW_IDX_parent
	.byte	1                               ## Abbreviation code
	.long	351                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: ~Timer
Lnames1:
L11:
	.byte	5                               ## Abbreviation code
	.long	198                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: double
Lnames20:
L6:
	.byte	1                               ## Abbreviation code
	.long	464                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5Timer24getElapsedTimeInMilliSecEv
Lnames22:
	.byte	1                               ## Abbreviation code
	.long	492                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5Timer19getElapsedTimeInSecEv
Lnames7:
L17:
	.byte	2                               ## Abbreviation code
	.long	251                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: __int32_t
Lnames13:
	.byte	1                               ## Abbreviation code
	.long	380                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: start
Lnames11:
	.byte	1                               ## Abbreviation code
	.long	322                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5TimerD2Ev
Lnames2:
L3:
	.byte	5                               ## Abbreviation code
	.long	202                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: int
Lnames18:
	.byte	1                               ## Abbreviation code
	.long	436                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5Timer24getElapsedTimeInMicroSecEv
Lnames5:
L13:
	.byte	5                               ## Abbreviation code
	.long	239                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: long
Lnames6:
L16:
	.byte	2                               ## Abbreviation code
	.long	243                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: __darwin_suseconds_t
Lnames8:
	.byte	1                               ## Abbreviation code
	.long	264                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5TimerC2Ev
Lnames12:
	.byte	1                               ## Abbreviation code
	.long	351                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5TimerD1Ev
Lnames19:
	.byte	1                               ## Abbreviation code
	.long	464                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: getElapsedTimeInMilliSec
Lnames16:
	.byte	1                               ## Abbreviation code
	.long	408                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5Timer4stopEv
	.p2align	2, 0x0
Lnames_end0:
.subsections_via_symbols
	.section	__DWARF,__debug_line,regular,debug
Lsection_line:
Lline_table_start0:
