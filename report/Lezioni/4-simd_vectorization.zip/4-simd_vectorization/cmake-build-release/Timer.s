	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 15, 0	sdk_version 26, 0
	.globl	__ZN5TimerC2Ev                  ## -- Begin function _ZN5TimerC2Ev
	.p2align	4, 0x90
__ZN5TimerC2Ev:                         ## @_ZN5TimerC2Ev
Lfunc_begin0:
	.file	0 "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization/cmake-build-release" "Timer.cpp" md5 0x5390ff1dfa3710af1265e70f3ab7deab
	.file	1 "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization" "Timer.cpp"
	.loc	1 22 0                          ## Timer.cpp:22:0
	.cfi_startproc
## %bb.0:
	##DEBUG_VALUE: Timer:this <- $rdi
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
Ltmp0:
	.loc	1 28 44 prologue_end            ## Timer.cpp:28:44
	movl	$0, 32(%rdi)
	.loc	1 28 23 is_stmt 0               ## Timer.cpp:28:23
	movq	$0, 24(%rdi)
	.loc	1 29 40 is_stmt 1               ## Timer.cpp:29:40
	movl	$0, 48(%rdi)
	.loc	1 29 21 is_stmt 0               ## Timer.cpp:29:21
	movq	$0, 40(%rdi)
	.loc	1 33 25 is_stmt 1               ## Timer.cpp:33:25
	xorps	%xmm0, %xmm0
	movups	%xmm0, (%rdi)
	movl	$0, 16(%rdi)
Ltmp1:
	.loc	1 35 1 epilogue_begin           ## Timer.cpp:35:1
	popq	%rbp
	retq
Ltmp2:
Lfunc_end0:
	.cfi_endproc
	.file	2 "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization" "Timer.h"
	.file	3 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/i386" "_types.h"
	.file	4 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys/_types" "_timeval.h"
	.file	5 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys" "_types.h"
                                        ## -- End function
	.globl	__ZN5TimerC1Ev                  ## -- Begin function _ZN5TimerC1Ev
	.p2align	4, 0x90
__ZN5TimerC1Ev:                         ## @_ZN5TimerC1Ev
Lfunc_begin1:
	.loc	1 22 0                          ## Timer.cpp:22:0
	.cfi_startproc
## %bb.0:
	##DEBUG_VALUE: Timer:this <- $rdi
	##DEBUG_VALUE: Timer:this <- $rdi
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
Ltmp3:
	.loc	1 28 44 prologue_end            ## Timer.cpp:28:44
	movl	$0, 32(%rdi)
	.loc	1 28 23 is_stmt 0               ## Timer.cpp:28:23
	movq	$0, 24(%rdi)
	.loc	1 29 40 is_stmt 1               ## Timer.cpp:29:40
	movl	$0, 48(%rdi)
	.loc	1 29 21 is_stmt 0               ## Timer.cpp:29:21
	movq	$0, 40(%rdi)
	.loc	1 33 25 is_stmt 1               ## Timer.cpp:33:25
	xorps	%xmm0, %xmm0
	movups	%xmm0, (%rdi)
	movl	$0, 16(%rdi)
Ltmp4:
	.loc	1 35 1 epilogue_begin           ## Timer.cpp:35:1
	popq	%rbp
	retq
Ltmp5:
Lfunc_end1:
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN5TimerD2Ev                  ## -- Begin function _ZN5TimerD2Ev
	.p2align	4, 0x90
__ZN5TimerD2Ev:                         ## @_ZN5TimerD2Ev
Lfunc_begin2:
	.loc	1 43 0                          ## Timer.cpp:43:0
	.cfi_startproc
## %bb.0:
	##DEBUG_VALUE: ~Timer:this <- $rdi
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
Ltmp6:
	.loc	1 44 1 prologue_end epilogue_begin ## Timer.cpp:44:1
	popq	%rbp
	retq
Ltmp7:
Lfunc_end2:
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN5TimerD1Ev                  ## -- Begin function _ZN5TimerD1Ev
	.p2align	4, 0x90
__ZN5TimerD1Ev:                         ## @_ZN5TimerD1Ev
Lfunc_begin3:
	.loc	1 43 0                          ## Timer.cpp:43:0
	.cfi_startproc
## %bb.0:
	##DEBUG_VALUE: ~Timer:this <- $rdi
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
Ltmp8:
	.loc	1 44 1 prologue_end epilogue_begin ## Timer.cpp:44:1
	popq	%rbp
	retq
Ltmp9:
Lfunc_end3:
	.cfi_endproc
                                        ## -- End function
	.globl	__ZN5Timer5startEv              ## -- Begin function _ZN5Timer5startEv
	.p2align	4, 0x90
__ZN5Timer5startEv:                     ## @_ZN5Timer5startEv
Lfunc_begin4:
	.loc	1 53 0                          ## Timer.cpp:53:0
	.cfi_startproc
## %bb.0:
	##DEBUG_VALUE: start:this <- $rdi
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
Ltmp10:
	.loc	1 54 13 prologue_end            ## Timer.cpp:54:13
	movl	$0, 16(%rdi)
	.loc	1 58 19                         ## Timer.cpp:58:19
	addq	$24, %rdi
Ltmp11:
	##DEBUG_VALUE: start:this <- [DW_OP_LLVM_entry_value 1] $rdi
	.loc	1 58 5 is_stmt 0                ## Timer.cpp:58:5
	xorl	%esi, %esi
	.loc	1 58 5 epilogue_begin           ## Timer.cpp:58:5
	popq	%rbp
Ltmp12:
	jmp	_gettimeofday                   ## TAILCALL
Ltmp13:
Lfunc_end4:
	.cfi_endproc
	.file	6 "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sys" "time.h"
                                        ## -- End function
	.globl	__ZN5Timer4stopEv               ## -- Begin function _ZN5Timer4stopEv
	.p2align	4, 0x90
__ZN5Timer4stopEv:                      ## @_ZN5Timer4stopEv
Lfunc_begin5:
	.loc	1 69 0 is_stmt 1                ## Timer.cpp:69:0
	.cfi_startproc
## %bb.0:
	##DEBUG_VALUE: stop:this <- $rdi
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
Ltmp14:
	.loc	1 70 13 prologue_end            ## Timer.cpp:70:13
	movl	$1, 16(%rdi)
	.loc	1 75 19                         ## Timer.cpp:75:19
	addq	$40, %rdi
Ltmp15:
	##DEBUG_VALUE: stop:this <- [DW_OP_LLVM_entry_value 1] $rdi
	.loc	1 75 5 is_stmt 0                ## Timer.cpp:75:5
	xorl	%esi, %esi
	.loc	1 75 5 epilogue_begin           ## Timer.cpp:75:5
	popq	%rbp
Ltmp16:
	jmp	_gettimeofday                   ## TAILCALL
Ltmp17:
Lfunc_end5:
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ## -- Begin function _ZN5Timer24getElapsedTimeInMicroSecEv
LCPI6_0:
	.quad	0x412e848000000000              ## double 1.0E+6
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN5Timer24getElapsedTimeInMicroSecEv
	.p2align	4, 0x90
__ZN5Timer24getElapsedTimeInMicroSecEv: ## @_ZN5Timer24getElapsedTimeInMicroSecEv
Lfunc_begin6:
	.loc	1 86 0 is_stmt 1                ## Timer.cpp:86:0
	.cfi_startproc
## %bb.0:
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rdi
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -24
	movq	%rdi, %rbx
Ltmp18:
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rbx
	.loc	1 94 9 prologue_end             ## Timer.cpp:94:9
	cmpl	$0, 16(%rdi)
Ltmp19:
	.loc	1 94 8 is_stmt 0                ## Timer.cpp:94:8
	jne	LBB6_2
Ltmp20:
## %bb.1:
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rbx
	.loc	1 95 23 is_stmt 1               ## Timer.cpp:95:23
	leaq	40(%rbx), %rdi
	.loc	1 95 9 is_stmt 0                ## Timer.cpp:95:9
	xorl	%esi, %esi
	callq	_gettimeofday
Ltmp21:
LBB6_2:
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rbx
	.loc	1 97 28 is_stmt 1               ## Timer.cpp:97:28
	cvtsi2sdq	24(%rbx), %xmm1
	.loc	1 97 61 is_stmt 0               ## Timer.cpp:97:61
	cvtsi2sdl	32(%rbx), %xmm0
	movsd	LCPI6_0(%rip), %xmm2            ## xmm2 = [1.0E+6,0.0E+0]
	.loc	1 97 59                         ## Timer.cpp:97:59
	mulsd	%xmm2, %xmm1
	addsd	%xmm0, %xmm1
	.loc	1 97 25                         ## Timer.cpp:97:25
	movsd	%xmm1, (%rbx)
	.loc	1 98 26 is_stmt 1               ## Timer.cpp:98:26
	xorps	%xmm0, %xmm0
	cvtsi2sdq	40(%rbx), %xmm0
	.loc	1 98 57 is_stmt 0               ## Timer.cpp:98:57
	cvtsi2sdl	48(%rbx), %xmm3
	.loc	1 98 55                         ## Timer.cpp:98:55
	mulsd	%xmm2, %xmm0
	addsd	%xmm3, %xmm0
	.loc	1 98 23                         ## Timer.cpp:98:23
	movsd	%xmm0, 8(%rbx)
	.loc	1 101 30 is_stmt 1              ## Timer.cpp:101:30
	subsd	%xmm1, %xmm0
	.loc	1 101 5 epilogue_begin is_stmt 0 ## Timer.cpp:101:5
	addq	$8, %rsp
	popq	%rbx
Ltmp22:
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- [DW_OP_LLVM_entry_value 1] $rdi
	popq	%rbp
	retq
Ltmp23:
Lfunc_end6:
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ## -- Begin function _ZN5Timer24getElapsedTimeInMilliSecEv
LCPI7_0:
	.quad	0x412e848000000000              ## double 1.0E+6
LCPI7_1:
	.quad	0x3f50624dd2f1a9fc              ## double 0.001
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN5Timer24getElapsedTimeInMilliSecEv
	.p2align	4, 0x90
__ZN5Timer24getElapsedTimeInMilliSecEv: ## @_ZN5Timer24getElapsedTimeInMilliSecEv
Lfunc_begin7:
	.loc	1 110 0 is_stmt 1               ## Timer.cpp:110:0
	.cfi_startproc
## %bb.0:
	##DEBUG_VALUE: getElapsedTimeInMilliSec:this <- $rdi
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rdi
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -24
	movq	%rdi, %rbx
Ltmp24:
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rbx
	##DEBUG_VALUE: getElapsedTimeInMilliSec:this <- $rbx
	.loc	1 94 9 prologue_end             ## Timer.cpp:94:9
	cmpl	$0, 16(%rdi)
Ltmp25:
	.loc	1 94 8 is_stmt 0                ## Timer.cpp:94:8
	jne	LBB7_2
Ltmp26:
## %bb.1:
	##DEBUG_VALUE: getElapsedTimeInMilliSec:this <- $rbx
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rbx
	.loc	1 95 23 is_stmt 1               ## Timer.cpp:95:23
	leaq	40(%rbx), %rdi
	.loc	1 95 9 is_stmt 0                ## Timer.cpp:95:9
	xorl	%esi, %esi
	callq	_gettimeofday
Ltmp27:
LBB7_2:                                 ## %_ZN5Timer24getElapsedTimeInMicroSecEv.exit
	##DEBUG_VALUE: getElapsedTimeInMilliSec:this <- $rbx
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rbx
	.loc	1 97 28 is_stmt 1               ## Timer.cpp:97:28
	cvtsi2sdq	24(%rbx), %xmm1
	.loc	1 97 61 is_stmt 0               ## Timer.cpp:97:61
	cvtsi2sdl	32(%rbx), %xmm0
	movsd	LCPI7_0(%rip), %xmm2            ## xmm2 = [1.0E+6,0.0E+0]
	.loc	1 97 59                         ## Timer.cpp:97:59
	mulsd	%xmm2, %xmm1
	addsd	%xmm0, %xmm1
	.loc	1 97 25                         ## Timer.cpp:97:25
	movsd	%xmm1, (%rbx)
	.loc	1 98 26 is_stmt 1               ## Timer.cpp:98:26
	xorps	%xmm0, %xmm0
	cvtsi2sdq	40(%rbx), %xmm0
	.loc	1 98 57 is_stmt 0               ## Timer.cpp:98:57
	cvtsi2sdl	48(%rbx), %xmm3
	.loc	1 98 55                         ## Timer.cpp:98:55
	mulsd	%xmm2, %xmm0
	addsd	%xmm3, %xmm0
	.loc	1 98 23                         ## Timer.cpp:98:23
	movsd	%xmm0, 8(%rbx)
	.loc	1 101 30 is_stmt 1              ## Timer.cpp:101:30
	subsd	%xmm1, %xmm0
Ltmp28:
	.loc	1 111 45                        ## Timer.cpp:111:45
	mulsd	LCPI7_1(%rip), %xmm0
	.loc	1 111 5 epilogue_begin is_stmt 0 ## Timer.cpp:111:5
	addq	$8, %rsp
	popq	%rbx
Ltmp29:
	##DEBUG_VALUE: getElapsedTimeInMilliSec:this <- [DW_OP_LLVM_entry_value 1] $rdi
	popq	%rbp
	retq
Ltmp30:
Lfunc_end7:
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ## -- Begin function _ZN5Timer19getElapsedTimeInSecEv
LCPI8_0:
	.quad	0x412e848000000000              ## double 1.0E+6
LCPI8_1:
	.quad	0x3eb0c6f7a0b5ed8d              ## double 9.9999999999999995E-7
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN5Timer19getElapsedTimeInSecEv
	.p2align	4, 0x90
__ZN5Timer19getElapsedTimeInSecEv:      ## @_ZN5Timer19getElapsedTimeInSecEv
Lfunc_begin8:
	.loc	1 120 0 is_stmt 1               ## Timer.cpp:120:0
	.cfi_startproc
## %bb.0:
	##DEBUG_VALUE: getElapsedTimeInSec:this <- $rdi
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rdi
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -24
	movq	%rdi, %rbx
Ltmp31:
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rbx
	##DEBUG_VALUE: getElapsedTimeInSec:this <- $rbx
	.loc	1 94 9 prologue_end             ## Timer.cpp:94:9
	cmpl	$0, 16(%rdi)
Ltmp32:
	.loc	1 94 8 is_stmt 0                ## Timer.cpp:94:8
	jne	LBB8_2
Ltmp33:
## %bb.1:
	##DEBUG_VALUE: getElapsedTimeInSec:this <- $rbx
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rbx
	.loc	1 95 23 is_stmt 1               ## Timer.cpp:95:23
	leaq	40(%rbx), %rdi
	.loc	1 95 9 is_stmt 0                ## Timer.cpp:95:9
	xorl	%esi, %esi
	callq	_gettimeofday
Ltmp34:
LBB8_2:                                 ## %_ZN5Timer24getElapsedTimeInMicroSecEv.exit
	##DEBUG_VALUE: getElapsedTimeInSec:this <- $rbx
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rbx
	.loc	1 97 28 is_stmt 1               ## Timer.cpp:97:28
	cvtsi2sdq	24(%rbx), %xmm1
	.loc	1 97 61 is_stmt 0               ## Timer.cpp:97:61
	cvtsi2sdl	32(%rbx), %xmm0
	movsd	LCPI8_0(%rip), %xmm2            ## xmm2 = [1.0E+6,0.0E+0]
	.loc	1 97 59                         ## Timer.cpp:97:59
	mulsd	%xmm2, %xmm1
	addsd	%xmm0, %xmm1
	.loc	1 97 25                         ## Timer.cpp:97:25
	movsd	%xmm1, (%rbx)
	.loc	1 98 26 is_stmt 1               ## Timer.cpp:98:26
	xorps	%xmm0, %xmm0
	cvtsi2sdq	40(%rbx), %xmm0
	.loc	1 98 57 is_stmt 0               ## Timer.cpp:98:57
	cvtsi2sdl	48(%rbx), %xmm3
	.loc	1 98 55                         ## Timer.cpp:98:55
	mulsd	%xmm2, %xmm0
	addsd	%xmm3, %xmm0
	.loc	1 98 23                         ## Timer.cpp:98:23
	movsd	%xmm0, 8(%rbx)
	.loc	1 101 30 is_stmt 1              ## Timer.cpp:101:30
	subsd	%xmm1, %xmm0
Ltmp35:
	.loc	1 121 45                        ## Timer.cpp:121:45
	mulsd	LCPI8_1(%rip), %xmm0
	.loc	1 121 5 epilogue_begin is_stmt 0 ## Timer.cpp:121:5
	addq	$8, %rsp
	popq	%rbx
Ltmp36:
	##DEBUG_VALUE: getElapsedTimeInSec:this <- [DW_OP_LLVM_entry_value 1] $rdi
	popq	%rbp
	retq
Ltmp37:
Lfunc_end8:
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ## -- Begin function _ZN5Timer14getElapsedTimeEv
LCPI9_0:
	.quad	0x412e848000000000              ## double 1.0E+6
LCPI9_1:
	.quad	0x3eb0c6f7a0b5ed8d              ## double 9.9999999999999995E-7
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__ZN5Timer14getElapsedTimeEv
	.p2align	4, 0x90
__ZN5Timer14getElapsedTimeEv:           ## @_ZN5Timer14getElapsedTimeEv
Lfunc_begin9:
	.loc	1 130 0 is_stmt 1               ## Timer.cpp:130:0
	.cfi_startproc
## %bb.0:
	##DEBUG_VALUE: getElapsedTime:this <- $rdi
	##DEBUG_VALUE: getElapsedTimeInSec:this <- $rdi
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rdi
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -24
	movq	%rdi, %rbx
Ltmp38:
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rbx
	##DEBUG_VALUE: getElapsedTimeInSec:this <- $rbx
	##DEBUG_VALUE: getElapsedTime:this <- $rbx
	.loc	1 94 9 prologue_end             ## Timer.cpp:94:9
	cmpl	$0, 16(%rdi)
Ltmp39:
	.loc	1 94 8 is_stmt 0                ## Timer.cpp:94:8
	jne	LBB9_2
Ltmp40:
## %bb.1:
	##DEBUG_VALUE: getElapsedTime:this <- $rbx
	##DEBUG_VALUE: getElapsedTimeInSec:this <- $rbx
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rbx
	.loc	1 95 23 is_stmt 1               ## Timer.cpp:95:23
	leaq	40(%rbx), %rdi
	.loc	1 95 9 is_stmt 0                ## Timer.cpp:95:9
	xorl	%esi, %esi
	callq	_gettimeofday
Ltmp41:
LBB9_2:                                 ## %_ZN5Timer19getElapsedTimeInSecEv.exit
	##DEBUG_VALUE: getElapsedTime:this <- $rbx
	##DEBUG_VALUE: getElapsedTimeInSec:this <- $rbx
	##DEBUG_VALUE: getElapsedTimeInMicroSec:this <- $rbx
	.loc	1 97 28 is_stmt 1               ## Timer.cpp:97:28
	cvtsi2sdq	24(%rbx), %xmm1
	.loc	1 97 61 is_stmt 0               ## Timer.cpp:97:61
	cvtsi2sdl	32(%rbx), %xmm0
	movsd	LCPI9_0(%rip), %xmm2            ## xmm2 = [1.0E+6,0.0E+0]
	.loc	1 97 59                         ## Timer.cpp:97:59
	mulsd	%xmm2, %xmm1
	addsd	%xmm0, %xmm1
	.loc	1 97 25                         ## Timer.cpp:97:25
	movsd	%xmm1, (%rbx)
	.loc	1 98 26 is_stmt 1               ## Timer.cpp:98:26
	xorps	%xmm0, %xmm0
	cvtsi2sdq	40(%rbx), %xmm0
	.loc	1 98 57 is_stmt 0               ## Timer.cpp:98:57
	cvtsi2sdl	48(%rbx), %xmm3
	.loc	1 98 55                         ## Timer.cpp:98:55
	mulsd	%xmm2, %xmm0
	addsd	%xmm3, %xmm0
	.loc	1 98 23                         ## Timer.cpp:98:23
	movsd	%xmm0, 8(%rbx)
	.loc	1 101 30 is_stmt 1              ## Timer.cpp:101:30
	subsd	%xmm1, %xmm0
Ltmp42:
	.loc	1 121 45                        ## Timer.cpp:121:45
	mulsd	LCPI9_1(%rip), %xmm0
Ltmp43:
	.loc	1 131 5 epilogue_begin          ## Timer.cpp:131:5
	addq	$8, %rsp
	popq	%rbx
Ltmp44:
	##DEBUG_VALUE: getElapsedTime:this <- [DW_OP_LLVM_entry_value 1] $rdi
	popq	%rbp
	retq
Ltmp45:
Lfunc_end9:
	.cfi_endproc
                                        ## -- End function
	.section	__DWARF,__debug_loclists,regular,debug
Lsection_debug_loc0:
.set Lset0, Ldebug_list_header_end0-Ldebug_list_header_start0 ## Length
	.long	Lset0
Ldebug_list_header_start0:
	.short	5                               ## Version
	.byte	8                               ## Address size
	.byte	0                               ## Segment selector size
	.long	6                               ## Offset entry count
Lloclists_table_base0:
.set Lset1, Ldebug_loc0-Lloclists_table_base0
	.long	Lset1
.set Lset2, Ldebug_loc1-Lloclists_table_base0
	.long	Lset2
.set Lset3, Ldebug_loc2-Lloclists_table_base0
	.long	Lset3
.set Lset4, Ldebug_loc3-Lloclists_table_base0
	.long	Lset4
.set Lset5, Ldebug_loc4-Lloclists_table_base0
	.long	Lset5
.set Lset6, Ldebug_loc5-Lloclists_table_base0
	.long	Lset6
Ldebug_loc0:
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Lfunc_begin4-Lfunc_begin0      ##   starting offset
	.uleb128 Ltmp11-Lfunc_begin0            ##   ending offset
	.byte	1                               ## Loc expr size
	.byte	85                              ## DW_OP_reg5
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Ltmp11-Lfunc_begin0            ##   starting offset
	.uleb128 Lfunc_end4-Lfunc_begin0        ##   ending offset
	.byte	4                               ## Loc expr size
	.byte	163                             ## DW_OP_entry_value
	.byte	1                               ## 1
	.byte	85                              ## DW_OP_reg5
	.byte	159                             ## DW_OP_stack_value
	.byte	0                               ## DW_LLE_end_of_list
Ldebug_loc1:
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Lfunc_begin5-Lfunc_begin0      ##   starting offset
	.uleb128 Ltmp15-Lfunc_begin0            ##   ending offset
	.byte	1                               ## Loc expr size
	.byte	85                              ## DW_OP_reg5
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Ltmp15-Lfunc_begin0            ##   starting offset
	.uleb128 Lfunc_end5-Lfunc_begin0        ##   ending offset
	.byte	4                               ## Loc expr size
	.byte	163                             ## DW_OP_entry_value
	.byte	1                               ## 1
	.byte	85                              ## DW_OP_reg5
	.byte	159                             ## DW_OP_stack_value
	.byte	0                               ## DW_LLE_end_of_list
Ldebug_loc2:
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Lfunc_begin6-Lfunc_begin0      ##   starting offset
	.uleb128 Ltmp18-Lfunc_begin0            ##   ending offset
	.byte	1                               ## Loc expr size
	.byte	85                              ## DW_OP_reg5
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Ltmp18-Lfunc_begin0            ##   starting offset
	.uleb128 Ltmp22-Lfunc_begin0            ##   ending offset
	.byte	1                               ## Loc expr size
	.byte	83                              ## DW_OP_reg3
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Ltmp22-Lfunc_begin0            ##   starting offset
	.uleb128 Lfunc_end6-Lfunc_begin0        ##   ending offset
	.byte	4                               ## Loc expr size
	.byte	163                             ## DW_OP_entry_value
	.byte	1                               ## 1
	.byte	85                              ## DW_OP_reg5
	.byte	159                             ## DW_OP_stack_value
	.byte	0                               ## DW_LLE_end_of_list
Ldebug_loc3:
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Lfunc_begin7-Lfunc_begin0      ##   starting offset
	.uleb128 Ltmp24-Lfunc_begin0            ##   ending offset
	.byte	1                               ## Loc expr size
	.byte	85                              ## DW_OP_reg5
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Ltmp24-Lfunc_begin0            ##   starting offset
	.uleb128 Ltmp29-Lfunc_begin0            ##   ending offset
	.byte	1                               ## Loc expr size
	.byte	83                              ## DW_OP_reg3
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Ltmp29-Lfunc_begin0            ##   starting offset
	.uleb128 Lfunc_end7-Lfunc_begin0        ##   ending offset
	.byte	4                               ## Loc expr size
	.byte	163                             ## DW_OP_entry_value
	.byte	1                               ## 1
	.byte	85                              ## DW_OP_reg5
	.byte	159                             ## DW_OP_stack_value
	.byte	0                               ## DW_LLE_end_of_list
Ldebug_loc4:
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Lfunc_begin8-Lfunc_begin0      ##   starting offset
	.uleb128 Ltmp31-Lfunc_begin0            ##   ending offset
	.byte	1                               ## Loc expr size
	.byte	85                              ## DW_OP_reg5
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Ltmp31-Lfunc_begin0            ##   starting offset
	.uleb128 Ltmp36-Lfunc_begin0            ##   ending offset
	.byte	1                               ## Loc expr size
	.byte	83                              ## DW_OP_reg3
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Ltmp36-Lfunc_begin0            ##   starting offset
	.uleb128 Lfunc_end8-Lfunc_begin0        ##   ending offset
	.byte	4                               ## Loc expr size
	.byte	163                             ## DW_OP_entry_value
	.byte	1                               ## 1
	.byte	85                              ## DW_OP_reg5
	.byte	159                             ## DW_OP_stack_value
	.byte	0                               ## DW_LLE_end_of_list
Ldebug_loc5:
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Lfunc_begin9-Lfunc_begin0      ##   starting offset
	.uleb128 Ltmp38-Lfunc_begin0            ##   ending offset
	.byte	1                               ## Loc expr size
	.byte	85                              ## DW_OP_reg5
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Ltmp38-Lfunc_begin0            ##   starting offset
	.uleb128 Ltmp44-Lfunc_begin0            ##   ending offset
	.byte	1                               ## Loc expr size
	.byte	83                              ## DW_OP_reg3
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Ltmp44-Lfunc_begin0            ##   starting offset
	.uleb128 Lfunc_end9-Lfunc_begin0        ##   ending offset
	.byte	4                               ## Loc expr size
	.byte	163                             ## DW_OP_entry_value
	.byte	1                               ## 1
	.byte	85                              ## DW_OP_reg5
	.byte	159                             ## DW_OP_stack_value
	.byte	0                               ## DW_LLE_end_of_list
Ldebug_list_header_end0:
	.section	__DWARF,__debug_abbrev,regular,debug
Lsection_abbrev:
	.byte	1                               ## Abbreviation Code
	.byte	17                              ## DW_TAG_compile_unit
	.byte	1                               ## DW_CHILDREN_yes
	.byte	37                              ## DW_AT_producer
	.byte	37                              ## DW_FORM_strx1
	.byte	19                              ## DW_AT_language
	.byte	5                               ## DW_FORM_data2
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.ascii	"\202|"                         ## DW_AT_LLVM_sysroot
	.byte	37                              ## DW_FORM_strx1
	.byte	114                             ## DW_AT_str_offsets_base
	.byte	23                              ## DW_FORM_sec_offset
	.byte	16                              ## DW_AT_stmt_list
	.byte	23                              ## DW_FORM_sec_offset
	.byte	27                              ## DW_AT_comp_dir
	.byte	37                              ## DW_FORM_strx1
	.ascii	"\341\177"                      ## DW_AT_APPLE_optimized
	.byte	25                              ## DW_FORM_flag_present
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	115                             ## DW_AT_addr_base
	.byte	23                              ## DW_FORM_sec_offset
	.ascii	"\214\001"                      ## DW_AT_loclists_base
	.byte	23                              ## DW_FORM_sec_offset
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	2                               ## Abbreviation Code
	.byte	2                               ## DW_TAG_class_type
	.byte	1                               ## DW_CHILDREN_yes
	.byte	54                              ## DW_AT_calling_convention
	.byte	11                              ## DW_FORM_data1
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	11                              ## DW_AT_byte_size
	.byte	11                              ## DW_FORM_data1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	3                               ## Abbreviation Code
	.byte	13                              ## DW_TAG_member
	.byte	0                               ## DW_CHILDREN_no
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	56                              ## DW_AT_data_member_location
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	4                               ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	60                              ## DW_AT_declaration
	.byte	25                              ## DW_FORM_flag_present
	.byte	63                              ## DW_AT_external
	.byte	25                              ## DW_FORM_flag_present
	.ascii	"\341\177"                      ## DW_AT_APPLE_optimized
	.byte	25                              ## DW_FORM_flag_present
	.byte	50                              ## DW_AT_accessibility
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	5                               ## Abbreviation Code
	.byte	5                               ## DW_TAG_formal_parameter
	.byte	0                               ## DW_CHILDREN_no
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	52                              ## DW_AT_artificial
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	6                               ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	110                             ## DW_AT_linkage_name
	.byte	37                              ## DW_FORM_strx1
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	60                              ## DW_AT_declaration
	.byte	25                              ## DW_FORM_flag_present
	.byte	63                              ## DW_AT_external
	.byte	25                              ## DW_FORM_flag_present
	.ascii	"\341\177"                      ## DW_AT_APPLE_optimized
	.byte	25                              ## DW_FORM_flag_present
	.byte	50                              ## DW_AT_accessibility
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	7                               ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	110                             ## DW_AT_linkage_name
	.byte	37                              ## DW_FORM_strx1
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	60                              ## DW_AT_declaration
	.byte	25                              ## DW_FORM_flag_present
	.byte	63                              ## DW_AT_external
	.byte	25                              ## DW_FORM_flag_present
	.ascii	"\341\177"                      ## DW_AT_APPLE_optimized
	.byte	25                              ## DW_FORM_flag_present
	.byte	50                              ## DW_AT_accessibility
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	8                               ## Abbreviation Code
	.byte	36                              ## DW_TAG_base_type
	.byte	0                               ## DW_CHILDREN_no
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	62                              ## DW_AT_encoding
	.byte	11                              ## DW_FORM_data1
	.byte	11                              ## DW_AT_byte_size
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	9                               ## Abbreviation Code
	.byte	19                              ## DW_TAG_structure_type
	.byte	1                               ## DW_CHILDREN_yes
	.byte	54                              ## DW_AT_calling_convention
	.byte	11                              ## DW_FORM_data1
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	11                              ## DW_AT_byte_size
	.byte	11                              ## DW_FORM_data1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	10                              ## Abbreviation Code
	.byte	22                              ## DW_TAG_typedef
	.byte	0                               ## DW_CHILDREN_no
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	11                              ## Abbreviation Code
	.byte	15                              ## DW_TAG_pointer_type
	.byte	0                               ## DW_CHILDREN_no
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	12                              ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	64                              ## DW_AT_frame_base
	.byte	24                              ## DW_FORM_exprloc
	.byte	100                             ## DW_AT_object_pointer
	.byte	19                              ## DW_FORM_ref4
	.byte	122                             ## DW_AT_call_all_calls
	.byte	25                              ## DW_FORM_flag_present
	.byte	49                              ## DW_AT_abstract_origin
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	13                              ## Abbreviation Code
	.byte	5                               ## DW_TAG_formal_parameter
	.byte	0                               ## DW_CHILDREN_no
	.byte	2                               ## DW_AT_location
	.byte	24                              ## DW_FORM_exprloc
	.byte	49                              ## DW_AT_abstract_origin
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	14                              ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	110                             ## DW_AT_linkage_name
	.byte	37                              ## DW_FORM_strx1
	.byte	71                              ## DW_AT_specification
	.byte	19                              ## DW_FORM_ref4
	.byte	32                              ## DW_AT_inline
	.byte	33                              ## DW_FORM_implicit_const
	.byte	1
	.byte	100                             ## DW_AT_object_pointer
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	15                              ## Abbreviation Code
	.byte	5                               ## DW_TAG_formal_parameter
	.byte	0                               ## DW_CHILDREN_no
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	52                              ## DW_AT_artificial
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	16                              ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	64                              ## DW_AT_frame_base
	.byte	24                              ## DW_FORM_exprloc
	.byte	100                             ## DW_AT_object_pointer
	.byte	19                              ## DW_FORM_ref4
	.byte	122                             ## DW_AT_call_all_calls
	.byte	25                              ## DW_FORM_flag_present
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	110                             ## DW_AT_linkage_name
	.byte	37                              ## DW_FORM_strx1
	.byte	71                              ## DW_AT_specification
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	17                              ## Abbreviation Code
	.byte	5                               ## DW_TAG_formal_parameter
	.byte	0                               ## DW_CHILDREN_no
	.byte	2                               ## DW_AT_location
	.byte	24                              ## DW_FORM_exprloc
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	52                              ## DW_AT_artificial
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	18                              ## Abbreviation Code
	.byte	29                              ## DW_TAG_inlined_subroutine
	.byte	1                               ## DW_CHILDREN_yes
	.byte	49                              ## DW_AT_abstract_origin
	.byte	19                              ## DW_FORM_ref4
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	88                              ## DW_AT_call_file
	.byte	11                              ## DW_FORM_data1
	.byte	89                              ## DW_AT_call_line
	.byte	11                              ## DW_FORM_data1
	.byte	87                              ## DW_AT_call_column
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	19                              ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	64                              ## DW_AT_frame_base
	.byte	24                              ## DW_FORM_exprloc
	.byte	100                             ## DW_AT_object_pointer
	.byte	19                              ## DW_FORM_ref4
	.byte	122                             ## DW_AT_call_all_calls
	.byte	25                              ## DW_FORM_flag_present
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	71                              ## DW_AT_specification
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	20                              ## Abbreviation Code
	.byte	5                               ## DW_TAG_formal_parameter
	.byte	0                               ## DW_CHILDREN_no
	.byte	2                               ## DW_AT_location
	.byte	34                              ## DW_FORM_loclistx
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	52                              ## DW_AT_artificial
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	21                              ## Abbreviation Code
	.byte	72                              ## DW_TAG_call_site
	.byte	1                               ## DW_CHILDREN_yes
	.byte	127                             ## DW_AT_call_origin
	.byte	19                              ## DW_FORM_ref4
	.ascii	"\202\001"                      ## DW_AT_call_tail_call
	.byte	25                              ## DW_FORM_flag_present
	.ascii	"\201\001"                      ## DW_AT_call_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	22                              ## Abbreviation Code
	.byte	73                              ## DW_TAG_call_site_parameter
	.byte	0                               ## DW_CHILDREN_no
	.byte	2                               ## DW_AT_location
	.byte	24                              ## DW_FORM_exprloc
	.byte	126                             ## DW_AT_call_value
	.byte	24                              ## DW_FORM_exprloc
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	23                              ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	60                              ## DW_AT_declaration
	.byte	25                              ## DW_FORM_flag_present
	.byte	63                              ## DW_AT_external
	.byte	25                              ## DW_FORM_flag_present
	.ascii	"\341\177"                      ## DW_AT_APPLE_optimized
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	24                              ## Abbreviation Code
	.byte	5                               ## DW_TAG_formal_parameter
	.byte	0                               ## DW_CHILDREN_no
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	25                              ## Abbreviation Code
	.byte	15                              ## DW_TAG_pointer_type
	.byte	0                               ## DW_CHILDREN_no
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	26                              ## Abbreviation Code
	.byte	5                               ## DW_TAG_formal_parameter
	.byte	0                               ## DW_CHILDREN_no
	.byte	2                               ## DW_AT_location
	.byte	34                              ## DW_FORM_loclistx
	.byte	49                              ## DW_AT_abstract_origin
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	27                              ## Abbreviation Code
	.byte	72                              ## DW_TAG_call_site
	.byte	1                               ## DW_CHILDREN_yes
	.byte	127                             ## DW_AT_call_origin
	.byte	19                              ## DW_FORM_ref4
	.byte	125                             ## DW_AT_call_return_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	28                              ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	71                              ## DW_AT_specification
	.byte	19                              ## DW_FORM_ref4
	.byte	32                              ## DW_AT_inline
	.byte	33                              ## DW_FORM_implicit_const
	.byte	1
	.byte	100                             ## DW_AT_object_pointer
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	0                               ## EOM(3)
	.section	__DWARF,__debug_info,regular,debug
Lsection_info:
Lcu_begin0:
.set Lset7, Ldebug_info_end0-Ldebug_info_start0 ## Length of Unit
	.long	Lset7
Ldebug_info_start0:
	.short	5                               ## DWARF version number
	.byte	1                               ## DWARF Unit Type
	.byte	8                               ## Address Size (in bytes)
.set Lset8, Lsection_abbrev-Lsection_abbrev ## Offset Into Abbrev. Section
	.long	Lset8
	.byte	1                               ## Abbrev [1] 0xc:0x321 DW_TAG_compile_unit
	.byte	0                               ## DW_AT_producer
	.short	26                              ## DW_AT_language
	.byte	1                               ## DW_AT_name
	.byte	2                               ## DW_AT_LLVM_sysroot
.set Lset9, Lstr_offsets_base0-Lsection_str_off ## DW_AT_str_offsets_base
	.long	Lset9
.set Lset10, Lline_table_start0-Lsection_line ## DW_AT_stmt_list
	.long	Lset10
	.byte	3                               ## DW_AT_comp_dir
                                        ## DW_AT_APPLE_optimized
	.byte	0                               ## DW_AT_low_pc
.set Lset11, Lfunc_end9-Lfunc_begin0    ## DW_AT_high_pc
	.long	Lset11
.set Lset12, Laddr_table_base0-Lsection_info0 ## DW_AT_addr_base
	.long	Lset12
.set Lset13, Lloclists_table_base0-Lsection_debug_loc0 ## DW_AT_loclists_base
	.long	Lset13
	.byte	2                               ## Abbrev [2] 0x28:0xa2 DW_TAG_class_type
	.byte	4                               ## DW_AT_calling_convention
	.byte	18                              ## DW_AT_name
	.byte	56                              ## DW_AT_byte_size
	.byte	2                               ## DW_AT_decl_file
	.byte	25                              ## DW_AT_decl_line
	.byte	3                               ## Abbrev [3] 0x2e:0x9 DW_TAG_member
	.byte	4                               ## DW_AT_name
	.long	202                             ## DW_AT_type
	.byte	2                               ## DW_AT_decl_file
	.byte	43                              ## DW_AT_decl_line
	.byte	0                               ## DW_AT_data_member_location
	.byte	3                               ## Abbrev [3] 0x37:0x9 DW_TAG_member
	.byte	6                               ## DW_AT_name
	.long	202                             ## DW_AT_type
	.byte	2                               ## DW_AT_decl_file
	.byte	44                              ## DW_AT_decl_line
	.byte	8                               ## DW_AT_data_member_location
	.byte	3                               ## Abbrev [3] 0x40:0x9 DW_TAG_member
	.byte	7                               ## DW_AT_name
	.long	206                             ## DW_AT_type
	.byte	2                               ## DW_AT_decl_file
	.byte	45                              ## DW_AT_decl_line
	.byte	16                              ## DW_AT_data_member_location
	.byte	3                               ## Abbrev [3] 0x49:0x9 DW_TAG_member
	.byte	9                               ## DW_AT_name
	.long	210                             ## DW_AT_type
	.byte	2                               ## DW_AT_decl_file
	.byte	51                              ## DW_AT_decl_line
	.byte	24                              ## DW_AT_data_member_location
	.byte	3                               ## Abbrev [3] 0x52:0x9 DW_TAG_member
	.byte	17                              ## DW_AT_name
	.long	210                             ## DW_AT_type
	.byte	2                               ## DW_AT_decl_file
	.byte	52                              ## DW_AT_decl_line
	.byte	40                              ## DW_AT_data_member_location
	.byte	4                               ## Abbrev [4] 0x5b:0xb DW_TAG_subprogram
	.byte	18                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	28                              ## DW_AT_decl_line
                                        ## DW_AT_declaration
                                        ## DW_AT_external
                                        ## DW_AT_APPLE_optimized
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0x60:0x5 DW_TAG_formal_parameter
	.long	263                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	4                               ## Abbrev [4] 0x66:0xb DW_TAG_subprogram
	.byte	19                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	29                              ## DW_AT_decl_line
                                        ## DW_AT_declaration
                                        ## DW_AT_external
                                        ## DW_AT_APPLE_optimized
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0x6b:0x5 DW_TAG_formal_parameter
	.long	263                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	6                               ## Abbrev [6] 0x71:0xc DW_TAG_subprogram
	.byte	20                              ## DW_AT_linkage_name
	.byte	21                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	31                              ## DW_AT_decl_line
                                        ## DW_AT_declaration
                                        ## DW_AT_external
                                        ## DW_AT_APPLE_optimized
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0x77:0x5 DW_TAG_formal_parameter
	.long	263                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	6                               ## Abbrev [6] 0x7d:0xc DW_TAG_subprogram
	.byte	22                              ## DW_AT_linkage_name
	.byte	23                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	32                              ## DW_AT_decl_line
                                        ## DW_AT_declaration
                                        ## DW_AT_external
                                        ## DW_AT_APPLE_optimized
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0x83:0x5 DW_TAG_formal_parameter
	.long	263                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	7                               ## Abbrev [7] 0x89:0x10 DW_TAG_subprogram
	.byte	24                              ## DW_AT_linkage_name
	.byte	25                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	33                              ## DW_AT_decl_line
	.long	202                             ## DW_AT_type
                                        ## DW_AT_declaration
                                        ## DW_AT_external
                                        ## DW_AT_APPLE_optimized
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0x93:0x5 DW_TAG_formal_parameter
	.long	263                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	7                               ## Abbrev [7] 0x99:0x10 DW_TAG_subprogram
	.byte	26                              ## DW_AT_linkage_name
	.byte	27                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	34                              ## DW_AT_decl_line
	.long	202                             ## DW_AT_type
                                        ## DW_AT_declaration
                                        ## DW_AT_external
                                        ## DW_AT_APPLE_optimized
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0xa3:0x5 DW_TAG_formal_parameter
	.long	263                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	7                               ## Abbrev [7] 0xa9:0x10 DW_TAG_subprogram
	.byte	28                              ## DW_AT_linkage_name
	.byte	29                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	35                              ## DW_AT_decl_line
	.long	202                             ## DW_AT_type
                                        ## DW_AT_declaration
                                        ## DW_AT_external
                                        ## DW_AT_APPLE_optimized
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0xb3:0x5 DW_TAG_formal_parameter
	.long	263                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	7                               ## Abbrev [7] 0xb9:0x10 DW_TAG_subprogram
	.byte	30                              ## DW_AT_linkage_name
	.byte	31                              ## DW_AT_name
	.byte	2                               ## DW_AT_decl_file
	.byte	36                              ## DW_AT_decl_line
	.long	202                             ## DW_AT_type
                                        ## DW_AT_declaration
                                        ## DW_AT_external
                                        ## DW_AT_APPLE_optimized
	.byte	1                               ## DW_AT_accessibility
                                        ## DW_ACCESS_public
	.byte	5                               ## Abbrev [5] 0xc3:0x5 DW_TAG_formal_parameter
	.long	263                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	0                               ## End Of Children Mark
	.byte	8                               ## Abbrev [8] 0xca:0x4 DW_TAG_base_type
	.byte	5                               ## DW_AT_name
	.byte	4                               ## DW_AT_encoding
	.byte	8                               ## DW_AT_byte_size
	.byte	8                               ## Abbrev [8] 0xce:0x4 DW_TAG_base_type
	.byte	8                               ## DW_AT_name
	.byte	5                               ## DW_AT_encoding
	.byte	4                               ## DW_AT_byte_size
	.byte	9                               ## Abbrev [9] 0xd2:0x19 DW_TAG_structure_type
	.byte	5                               ## DW_AT_calling_convention
	.byte	16                              ## DW_AT_name
	.byte	16                              ## DW_AT_byte_size
	.byte	4                               ## DW_AT_decl_file
	.byte	34                              ## DW_AT_decl_line
	.byte	3                               ## Abbrev [3] 0xd8:0x9 DW_TAG_member
	.byte	10                              ## DW_AT_name
	.long	235                             ## DW_AT_type
	.byte	4                               ## DW_AT_decl_file
	.byte	36                              ## DW_AT_decl_line
	.byte	0                               ## DW_AT_data_member_location
	.byte	3                               ## Abbrev [3] 0xe1:0x9 DW_TAG_member
	.byte	13                              ## DW_AT_name
	.long	247                             ## DW_AT_type
	.byte	4                               ## DW_AT_decl_file
	.byte	37                              ## DW_AT_decl_line
	.byte	8                               ## DW_AT_data_member_location
	.byte	0                               ## End Of Children Mark
	.byte	10                              ## Abbrev [10] 0xeb:0x8 DW_TAG_typedef
	.long	243                             ## DW_AT_type
	.byte	12                              ## DW_AT_name
	.byte	3                               ## DW_AT_decl_file
	.byte	143                             ## DW_AT_decl_line
	.byte	8                               ## Abbrev [8] 0xf3:0x4 DW_TAG_base_type
	.byte	11                              ## DW_AT_name
	.byte	5                               ## DW_AT_encoding
	.byte	8                               ## DW_AT_byte_size
	.byte	10                              ## Abbrev [10] 0xf7:0x8 DW_TAG_typedef
	.long	255                             ## DW_AT_type
	.byte	15                              ## DW_AT_name
	.byte	5                               ## DW_AT_decl_file
	.byte	86                              ## DW_AT_decl_line
	.byte	10                              ## Abbrev [10] 0xff:0x8 DW_TAG_typedef
	.long	206                             ## DW_AT_type
	.byte	14                              ## DW_AT_name
	.byte	3                               ## DW_AT_decl_file
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## Abbrev [11] 0x107:0x5 DW_TAG_pointer_type
	.long	40                              ## DW_AT_type
	.byte	12                              ## Abbrev [12] 0x10c:0x18 DW_TAG_subprogram
	.byte	0                               ## DW_AT_low_pc
.set Lset14, Lfunc_end0-Lfunc_begin0    ## DW_AT_high_pc
	.long	Lset14
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	284                             ## DW_AT_object_pointer
                                        ## DW_AT_call_all_calls
	.long	292                             ## DW_AT_abstract_origin
	.byte	13                              ## Abbrev [13] 0x11c:0x7 DW_TAG_formal_parameter
	.byte	1                               ## DW_AT_location
	.byte	85
	.long	304                             ## DW_AT_abstract_origin
	.byte	0                               ## End Of Children Mark
	.byte	14                              ## Abbrev [14] 0x124:0x13 DW_TAG_subprogram
	.byte	1                               ## DW_AT_decl_file
	.byte	21                              ## DW_AT_decl_line
	.byte	32                              ## DW_AT_linkage_name
	.long	91                              ## DW_AT_specification
                                        ## DW_AT_inline
	.long	304                             ## DW_AT_object_pointer
	.byte	15                              ## Abbrev [15] 0x130:0x6 DW_TAG_formal_parameter
	.byte	33                              ## DW_AT_name
	.long	311                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	11                              ## Abbrev [11] 0x137:0x5 DW_TAG_pointer_type
	.long	40                              ## DW_AT_type
	.byte	16                              ## Abbrev [16] 0x13c:0x31 DW_TAG_subprogram
	.byte	1                               ## DW_AT_low_pc
.set Lset15, Lfunc_end1-Lfunc_begin1    ## DW_AT_high_pc
	.long	Lset15
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	335                             ## DW_AT_object_pointer
                                        ## DW_AT_call_all_calls
	.byte	1                               ## DW_AT_decl_file
	.byte	21                              ## DW_AT_decl_line
	.byte	35                              ## DW_AT_linkage_name
	.long	91                              ## DW_AT_specification
	.byte	17                              ## Abbrev [17] 0x14f:0x8 DW_TAG_formal_parameter
	.byte	1                               ## DW_AT_location
	.byte	85
	.byte	33                              ## DW_AT_name
	.long	311                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	18                              ## Abbrev [18] 0x157:0x15 DW_TAG_inlined_subroutine
	.long	292                             ## DW_AT_abstract_origin
	.byte	2                               ## DW_AT_low_pc
.set Lset16, Ltmp4-Ltmp3                ## DW_AT_high_pc
	.long	Lset16
	.byte	1                               ## DW_AT_call_file
	.byte	22                              ## DW_AT_call_line
	.byte	1                               ## DW_AT_call_column
	.byte	13                              ## Abbrev [13] 0x164:0x7 DW_TAG_formal_parameter
	.byte	1                               ## DW_AT_location
	.byte	85
	.long	304                             ## DW_AT_abstract_origin
	.byte	0                               ## End Of Children Mark
	.byte	0                               ## End Of Children Mark
	.byte	16                              ## Abbrev [16] 0x16d:0x1c DW_TAG_subprogram
	.byte	3                               ## DW_AT_low_pc
.set Lset17, Lfunc_end2-Lfunc_begin2    ## DW_AT_high_pc
	.long	Lset17
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	384                             ## DW_AT_object_pointer
                                        ## DW_AT_call_all_calls
	.byte	1                               ## DW_AT_decl_file
	.byte	42                              ## DW_AT_decl_line
	.byte	36                              ## DW_AT_linkage_name
	.long	102                             ## DW_AT_specification
	.byte	17                              ## Abbrev [17] 0x180:0x8 DW_TAG_formal_parameter
	.byte	1                               ## DW_AT_location
	.byte	85
	.byte	33                              ## DW_AT_name
	.long	311                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	16                              ## Abbrev [16] 0x189:0x1c DW_TAG_subprogram
	.byte	4                               ## DW_AT_low_pc
.set Lset18, Lfunc_end3-Lfunc_begin3    ## DW_AT_high_pc
	.long	Lset18
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	412                             ## DW_AT_object_pointer
                                        ## DW_AT_call_all_calls
	.byte	1                               ## DW_AT_decl_file
	.byte	42                              ## DW_AT_decl_line
	.byte	37                              ## DW_AT_linkage_name
	.long	102                             ## DW_AT_specification
	.byte	17                              ## Abbrev [17] 0x19c:0x8 DW_TAG_formal_parameter
	.byte	1                               ## DW_AT_location
	.byte	85
	.byte	33                              ## DW_AT_name
	.long	311                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	19                              ## Abbrev [19] 0x1a5:0x26 DW_TAG_subprogram
	.byte	5                               ## DW_AT_low_pc
.set Lset19, Lfunc_end4-Lfunc_begin4    ## DW_AT_high_pc
	.long	Lset19
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	439                             ## DW_AT_object_pointer
                                        ## DW_AT_call_all_calls
	.byte	1                               ## DW_AT_decl_file
	.byte	52                              ## DW_AT_decl_line
	.long	113                             ## DW_AT_specification
	.byte	20                              ## Abbrev [20] 0x1b7:0x7 DW_TAG_formal_parameter
	.byte	0                               ## DW_AT_location
	.byte	33                              ## DW_AT_name
	.long	311                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	21                              ## Abbrev [21] 0x1be:0xc DW_TAG_call_site
	.long	459                             ## DW_AT_call_origin
                                        ## DW_AT_call_tail_call
	.byte	6                               ## DW_AT_call_pc
	.byte	22                              ## Abbrev [22] 0x1c4:0x5 DW_TAG_call_site_parameter
	.byte	1                               ## DW_AT_location
	.byte	84
	.byte	1                               ## DW_AT_call_value
	.byte	48
	.byte	0                               ## End Of Children Mark
	.byte	0                               ## End Of Children Mark
	.byte	23                              ## Abbrev [23] 0x1cb:0x13 DW_TAG_subprogram
	.byte	34                              ## DW_AT_name
	.byte	6                               ## DW_AT_decl_file
	.byte	198                             ## DW_AT_decl_line
	.long	206                             ## DW_AT_type
                                        ## DW_AT_declaration
                                        ## DW_AT_external
                                        ## DW_AT_APPLE_optimized
	.byte	24                              ## Abbrev [24] 0x1d3:0x5 DW_TAG_formal_parameter
	.long	478                             ## DW_AT_type
	.byte	24                              ## Abbrev [24] 0x1d8:0x5 DW_TAG_formal_parameter
	.long	483                             ## DW_AT_type
	.byte	0                               ## End Of Children Mark
	.byte	11                              ## Abbrev [11] 0x1de:0x5 DW_TAG_pointer_type
	.long	210                             ## DW_AT_type
	.byte	25                              ## Abbrev [25] 0x1e3:0x1 DW_TAG_pointer_type
	.byte	19                              ## Abbrev [19] 0x1e4:0x26 DW_TAG_subprogram
	.byte	7                               ## DW_AT_low_pc
.set Lset20, Lfunc_end5-Lfunc_begin5    ## DW_AT_high_pc
	.long	Lset20
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	502                             ## DW_AT_object_pointer
                                        ## DW_AT_call_all_calls
	.byte	1                               ## DW_AT_decl_file
	.byte	68                              ## DW_AT_decl_line
	.long	125                             ## DW_AT_specification
	.byte	20                              ## Abbrev [20] 0x1f6:0x7 DW_TAG_formal_parameter
	.byte	1                               ## DW_AT_location
	.byte	33                              ## DW_AT_name
	.long	311                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	21                              ## Abbrev [21] 0x1fd:0xc DW_TAG_call_site
	.long	459                             ## DW_AT_call_origin
                                        ## DW_AT_call_tail_call
	.byte	8                               ## DW_AT_call_pc
	.byte	22                              ## Abbrev [22] 0x203:0x5 DW_TAG_call_site_parameter
	.byte	1                               ## DW_AT_location
	.byte	84
	.byte	1                               ## DW_AT_call_value
	.byte	48
	.byte	0                               ## End Of Children Mark
	.byte	0                               ## End Of Children Mark
	.byte	12                              ## Abbrev [12] 0x20a:0x29 DW_TAG_subprogram
	.byte	9                               ## DW_AT_low_pc
.set Lset21, Lfunc_end6-Lfunc_begin6    ## DW_AT_high_pc
	.long	Lset21
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	538                             ## DW_AT_object_pointer
                                        ## DW_AT_call_all_calls
	.long	563                             ## DW_AT_abstract_origin
	.byte	26                              ## Abbrev [26] 0x21a:0x6 DW_TAG_formal_parameter
	.byte	2                               ## DW_AT_location
	.long	574                             ## DW_AT_abstract_origin
	.byte	27                              ## Abbrev [27] 0x220:0x12 DW_TAG_call_site
	.long	459                             ## DW_AT_call_origin
	.byte	10                              ## DW_AT_call_return_pc
	.byte	22                              ## Abbrev [22] 0x226:0x5 DW_TAG_call_site_parameter
	.byte	1                               ## DW_AT_location
	.byte	84
	.byte	1                               ## DW_AT_call_value
	.byte	48
	.byte	22                              ## Abbrev [22] 0x22b:0x6 DW_TAG_call_site_parameter
	.byte	1                               ## DW_AT_location
	.byte	85
	.byte	2                               ## DW_AT_call_value
	.byte	115
	.byte	40
	.byte	0                               ## End Of Children Mark
	.byte	0                               ## End Of Children Mark
	.byte	28                              ## Abbrev [28] 0x233:0x12 DW_TAG_subprogram
	.byte	1                               ## DW_AT_decl_file
	.byte	85                              ## DW_AT_decl_line
	.long	185                             ## DW_AT_specification
                                        ## DW_AT_inline
	.long	574                             ## DW_AT_object_pointer
	.byte	15                              ## Abbrev [15] 0x23e:0x6 DW_TAG_formal_parameter
	.byte	33                              ## DW_AT_name
	.long	311                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	19                              ## Abbrev [19] 0x245:0x41 DW_TAG_subprogram
	.byte	11                              ## DW_AT_low_pc
.set Lset22, Lfunc_end7-Lfunc_begin7    ## DW_AT_high_pc
	.long	Lset22
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	599                             ## DW_AT_object_pointer
                                        ## DW_AT_call_all_calls
	.byte	1                               ## DW_AT_decl_file
	.byte	109                             ## DW_AT_decl_line
	.long	169                             ## DW_AT_specification
	.byte	20                              ## Abbrev [20] 0x257:0x7 DW_TAG_formal_parameter
	.byte	3                               ## DW_AT_location
	.byte	33                              ## DW_AT_name
	.long	311                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	18                              ## Abbrev [18] 0x25e:0x15 DW_TAG_inlined_subroutine
	.long	563                             ## DW_AT_abstract_origin
	.byte	12                              ## DW_AT_low_pc
.set Lset23, Ltmp28-Ltmp24              ## DW_AT_high_pc
	.long	Lset23
	.byte	1                               ## DW_AT_call_file
	.byte	111                             ## DW_AT_call_line
	.byte	18                              ## DW_AT_call_column
	.byte	13                              ## Abbrev [13] 0x26b:0x7 DW_TAG_formal_parameter
	.byte	1                               ## DW_AT_location
	.byte	83
	.long	574                             ## DW_AT_abstract_origin
	.byte	0                               ## End Of Children Mark
	.byte	27                              ## Abbrev [27] 0x273:0x12 DW_TAG_call_site
	.long	459                             ## DW_AT_call_origin
	.byte	13                              ## DW_AT_call_return_pc
	.byte	22                              ## Abbrev [22] 0x279:0x5 DW_TAG_call_site_parameter
	.byte	1                               ## DW_AT_location
	.byte	84
	.byte	1                               ## DW_AT_call_value
	.byte	48
	.byte	22                              ## Abbrev [22] 0x27e:0x6 DW_TAG_call_site_parameter
	.byte	1                               ## DW_AT_location
	.byte	85
	.byte	2                               ## DW_AT_call_value
	.byte	115
	.byte	40
	.byte	0                               ## End Of Children Mark
	.byte	0                               ## End Of Children Mark
	.byte	12                              ## Abbrev [12] 0x286:0x3e DW_TAG_subprogram
	.byte	14                              ## DW_AT_low_pc
.set Lset24, Lfunc_end8-Lfunc_begin8    ## DW_AT_high_pc
	.long	Lset24
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	662                             ## DW_AT_object_pointer
                                        ## DW_AT_call_all_calls
	.long	708                             ## DW_AT_abstract_origin
	.byte	26                              ## Abbrev [26] 0x296:0x6 DW_TAG_formal_parameter
	.byte	4                               ## DW_AT_location
	.long	719                             ## DW_AT_abstract_origin
	.byte	18                              ## Abbrev [18] 0x29c:0x15 DW_TAG_inlined_subroutine
	.long	563                             ## DW_AT_abstract_origin
	.byte	15                              ## DW_AT_low_pc
.set Lset25, Ltmp35-Ltmp31              ## DW_AT_high_pc
	.long	Lset25
	.byte	1                               ## DW_AT_call_file
	.byte	121                             ## DW_AT_call_line
	.byte	18                              ## DW_AT_call_column
	.byte	13                              ## Abbrev [13] 0x2a9:0x7 DW_TAG_formal_parameter
	.byte	1                               ## DW_AT_location
	.byte	83
	.long	574                             ## DW_AT_abstract_origin
	.byte	0                               ## End Of Children Mark
	.byte	27                              ## Abbrev [27] 0x2b1:0x12 DW_TAG_call_site
	.long	459                             ## DW_AT_call_origin
	.byte	16                              ## DW_AT_call_return_pc
	.byte	22                              ## Abbrev [22] 0x2b7:0x5 DW_TAG_call_site_parameter
	.byte	1                               ## DW_AT_location
	.byte	84
	.byte	1                               ## DW_AT_call_value
	.byte	48
	.byte	22                              ## Abbrev [22] 0x2bc:0x6 DW_TAG_call_site_parameter
	.byte	1                               ## DW_AT_location
	.byte	85
	.byte	2                               ## DW_AT_call_value
	.byte	115
	.byte	40
	.byte	0                               ## End Of Children Mark
	.byte	0                               ## End Of Children Mark
	.byte	28                              ## Abbrev [28] 0x2c4:0x12 DW_TAG_subprogram
	.byte	1                               ## DW_AT_decl_file
	.byte	119                             ## DW_AT_decl_line
	.long	153                             ## DW_AT_specification
                                        ## DW_AT_inline
	.long	719                             ## DW_AT_object_pointer
	.byte	15                              ## Abbrev [15] 0x2cf:0x6 DW_TAG_formal_parameter
	.byte	33                              ## DW_AT_name
	.long	311                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	0                               ## End Of Children Mark
	.byte	19                              ## Abbrev [19] 0x2d6:0x56 DW_TAG_subprogram
	.byte	17                              ## DW_AT_low_pc
.set Lset26, Lfunc_end9-Lfunc_begin9    ## DW_AT_high_pc
	.long	Lset26
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.long	744                             ## DW_AT_object_pointer
                                        ## DW_AT_call_all_calls
	.byte	1                               ## DW_AT_decl_file
	.byte	129                             ## DW_AT_decl_line
	.long	137                             ## DW_AT_specification
	.byte	20                              ## Abbrev [20] 0x2e8:0x7 DW_TAG_formal_parameter
	.byte	5                               ## DW_AT_location
	.byte	33                              ## DW_AT_name
	.long	311                             ## DW_AT_type
                                        ## DW_AT_artificial
	.byte	18                              ## Abbrev [18] 0x2ef:0x2a DW_TAG_inlined_subroutine
	.long	708                             ## DW_AT_abstract_origin
	.byte	18                              ## DW_AT_low_pc
.set Lset27, Ltmp43-Ltmp38              ## DW_AT_high_pc
	.long	Lset27
	.byte	1                               ## DW_AT_call_file
	.byte	131                             ## DW_AT_call_line
	.byte	18                              ## DW_AT_call_column
	.byte	13                              ## Abbrev [13] 0x2fc:0x7 DW_TAG_formal_parameter
	.byte	1                               ## DW_AT_location
	.byte	83
	.long	719                             ## DW_AT_abstract_origin
	.byte	18                              ## Abbrev [18] 0x303:0x15 DW_TAG_inlined_subroutine
	.long	563                             ## DW_AT_abstract_origin
	.byte	18                              ## DW_AT_low_pc
.set Lset28, Ltmp42-Ltmp38              ## DW_AT_high_pc
	.long	Lset28
	.byte	1                               ## DW_AT_call_file
	.byte	121                             ## DW_AT_call_line
	.byte	18                              ## DW_AT_call_column
	.byte	13                              ## Abbrev [13] 0x310:0x7 DW_TAG_formal_parameter
	.byte	1                               ## DW_AT_location
	.byte	83
	.long	574                             ## DW_AT_abstract_origin
	.byte	0                               ## End Of Children Mark
	.byte	0                               ## End Of Children Mark
	.byte	27                              ## Abbrev [27] 0x319:0x12 DW_TAG_call_site
	.long	459                             ## DW_AT_call_origin
	.byte	19                              ## DW_AT_call_return_pc
	.byte	22                              ## Abbrev [22] 0x31f:0x5 DW_TAG_call_site_parameter
	.byte	1                               ## DW_AT_location
	.byte	84
	.byte	1                               ## DW_AT_call_value
	.byte	48
	.byte	22                              ## Abbrev [22] 0x324:0x6 DW_TAG_call_site_parameter
	.byte	1                               ## DW_AT_location
	.byte	85
	.byte	2                               ## DW_AT_call_value
	.byte	115
	.byte	40
	.byte	0                               ## End Of Children Mark
	.byte	0                               ## End Of Children Mark
	.byte	0                               ## End Of Children Mark
Ldebug_info_end0:
	.section	__DWARF,__debug_str_offs,regular,debug
Lsection_str_off:
	.long	156                             ## Length of String Offsets Set
	.short	5
	.short	0
Lstr_offsets_base0:
	.section	__DWARF,__debug_str,regular,debug
Linfo_string:
	.asciz	"Apple clang version 17.0.0 (clang-1700.3.19.1)" ## string offset=0
	.asciz	"Timer.cpp"                     ## string offset=47
	.asciz	"/"                             ## string offset=57
	.asciz	"/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization/cmake-build-release" ## string offset=59
	.asciz	"Timer"                         ## string offset=194
	.asciz	"startTimeInMicroSec"           ## string offset=200
	.asciz	"double"                        ## string offset=220
	.asciz	"endTimeInMicroSec"             ## string offset=227
	.asciz	"stopped"                       ## string offset=245
	.asciz	"int"                           ## string offset=253
	.asciz	"startCount"                    ## string offset=257
	.asciz	"timeval"                       ## string offset=268
	.asciz	"tv_sec"                        ## string offset=276
	.asciz	"__darwin_time_t"               ## string offset=283
	.asciz	"long"                          ## string offset=299
	.asciz	"tv_usec"                       ## string offset=304
	.asciz	"__darwin_suseconds_t"          ## string offset=312
	.asciz	"__int32_t"                     ## string offset=333
	.asciz	"endCount"                      ## string offset=343
	.asciz	"~Timer"                        ## string offset=352
	.asciz	"_ZN5Timer5startEv"             ## string offset=359
	.asciz	"start"                         ## string offset=377
	.asciz	"_ZN5Timer4stopEv"              ## string offset=383
	.asciz	"stop"                          ## string offset=400
	.asciz	"_ZN5Timer14getElapsedTimeEv"   ## string offset=405
	.asciz	"getElapsedTime"                ## string offset=433
	.asciz	"_ZN5Timer19getElapsedTimeInSecEv" ## string offset=448
	.asciz	"getElapsedTimeInSec"           ## string offset=481
	.asciz	"_ZN5Timer24getElapsedTimeInMilliSecEv" ## string offset=501
	.asciz	"getElapsedTimeInMilliSec"      ## string offset=539
	.asciz	"_ZN5Timer24getElapsedTimeInMicroSecEv" ## string offset=564
	.asciz	"getElapsedTimeInMicroSec"      ## string offset=602
	.asciz	"_ZN5TimerC2Ev"                 ## string offset=627
	.asciz	"this"                          ## string offset=641
	.asciz	"_ZN5TimerC1Ev"                 ## string offset=646
	.asciz	"_ZN5TimerD2Ev"                 ## string offset=660
	.asciz	"_ZN5TimerD1Ev"                 ## string offset=674
	.asciz	"gettimeofday"                  ## string offset=688
	.section	__DWARF,__debug_str_offs,regular,debug
	.long	0
	.long	47
	.long	57
	.long	59
	.long	200
	.long	220
	.long	227
	.long	245
	.long	253
	.long	257
	.long	276
	.long	299
	.long	283
	.long	304
	.long	333
	.long	312
	.long	268
	.long	343
	.long	194
	.long	352
	.long	359
	.long	377
	.long	383
	.long	400
	.long	405
	.long	433
	.long	448
	.long	481
	.long	501
	.long	539
	.long	564
	.long	602
	.long	627
	.long	641
	.long	688
	.long	646
	.long	660
	.long	674
	.section	__DWARF,__debug_addr,regular,debug
Lsection_info0:
.set Lset29, Ldebug_addr_end0-Ldebug_addr_start0 ## Length of contribution
	.long	Lset29
Ldebug_addr_start0:
	.short	5                               ## DWARF version number
	.byte	8                               ## Address size
	.byte	0                               ## Segment selector size
Laddr_table_base0:
	.quad	Lfunc_begin0
	.quad	Lfunc_begin1
	.quad	Ltmp3
	.quad	Lfunc_begin2
	.quad	Lfunc_begin3
	.quad	Lfunc_begin4
	.quad	Ltmp12
	.quad	Lfunc_begin5
	.quad	Ltmp16
	.quad	Lfunc_begin6
	.quad	Ltmp21
	.quad	Lfunc_begin7
	.quad	Ltmp24
	.quad	Ltmp27
	.quad	Lfunc_begin8
	.quad	Ltmp31
	.quad	Ltmp34
	.quad	Lfunc_begin9
	.quad	Ltmp38
	.quad	Ltmp41
Ldebug_addr_end0:
	.section	__DWARF,__debug_names,regular,debug
Ldebug_names_begin:
.set Lset30, Lnames_end0-Lnames_start0  ## Header: unit length
	.long	Lset30
Lnames_start0:
	.short	5                               ## Header: version
	.short	0                               ## Header: padding
	.long	1                               ## Header: compilation unit count
	.long	0                               ## Header: local type unit count
	.long	0                               ## Header: foreign type unit count
	.long	12                              ## Header: bucket count
	.long	25                              ## Header: name count
.set Lset31, Lnames_abbrev_end0-Lnames_abbrev_start0 ## Header: abbreviation table size
	.long	Lset31
	.long	8                               ## Header: augmentation string size
	.ascii	"LLVM0700"                      ## Header: augmentation string
.set Lset32, Lcu_begin0-Lsection_info   ## Compilation unit 0
	.long	Lset32
	.long	1                               ## Bucket 0
	.long	3                               ## Bucket 1
	.long	5                               ## Bucket 2
	.long	8                               ## Bucket 3
	.long	11                              ## Bucket 4
	.long	13                              ## Bucket 5
	.long	14                              ## Bucket 6
	.long	16                              ## Bucket 7
	.long	18                              ## Bucket 8
	.long	20                              ## Bucket 9
	.long	22                              ## Bucket 10
	.long	24                              ## Bucket 11
	.long	320097312                       ## Hash in Bucket 0
	.long	1294271460                      ## Hash in Bucket 0
	.long	-1022442159                     ## Hash in Bucket 1
	.long	-243996567                      ## Hash in Bucket 1
	.long	275614598                       ## Hash in Bucket 2
	.long	306366014                       ## Hash in Bucket 2
	.long	-1152108686                     ## Hash in Bucket 2
	.long	2090736459                      ## Hash in Bucket 3
	.long	-503405833                      ## Hash in Bucket 3
	.long	-328721329                      ## Hash in Bucket 3
	.long	909610852                       ## Hash in Bucket 4
	.long	-113419488                      ## Hash in Bucket 4
	.long	-1752945767                     ## Hash in Bucket 5
	.long	1561878438                      ## Hash in Bucket 6
	.long	1950534918                      ## Hash in Bucket 6
	.long	274811347                       ## Hash in Bucket 7
	.long	-1022405133                     ## Hash in Bucket 7
	.long	193495088                       ## Hash in Bucket 8
	.long	621809660                       ## Hash in Bucket 8
	.long	2090479413                      ## Hash in Bucket 9
	.long	-1308701839                     ## Hash in Bucket 9
	.long	-1022441070                     ## Hash in Bucket 10
	.long	-1022406222                     ## Hash in Bucket 10
	.long	651253403                       ## Hash in Bucket 11
	.long	1972495511                      ## Hash in Bucket 11
	.long	359                             ## String in Bucket 0: _ZN5Timer5startEv
	.long	481                             ## String in Bucket 0: getElapsedTimeInSec
	.long	646                             ## String in Bucket 1: _ZN5TimerC1Ev
	.long	283                             ## String in Bucket 1: __darwin_time_t
	.long	194                             ## String in Bucket 2: Timer
	.long	602                             ## String in Bucket 2: getElapsedTimeInMicroSec
	.long	433                             ## String in Bucket 2: getElapsedTime
	.long	400                             ## String in Bucket 3: stop
	.long	268                             ## String in Bucket 3: timeval
	.long	405                             ## String in Bucket 3: _ZN5Timer14getElapsedTimeEv
	.long	352                             ## String in Bucket 4: ~Timer
	.long	220                             ## String in Bucket 4: double
	.long	501                             ## String in Bucket 5: _ZN5Timer24getElapsedTimeInMilliSecEv
	.long	448                             ## String in Bucket 6: _ZN5Timer19getElapsedTimeInSecEv
	.long	333                             ## String in Bucket 6: __int32_t
	.long	377                             ## String in Bucket 7: start
	.long	660                             ## String in Bucket 7: _ZN5TimerD2Ev
	.long	253                             ## String in Bucket 8: int
	.long	564                             ## String in Bucket 8: _ZN5Timer24getElapsedTimeInMicroSecEv
	.long	299                             ## String in Bucket 9: long
	.long	312                             ## String in Bucket 9: __darwin_suseconds_t
	.long	627                             ## String in Bucket 10: _ZN5TimerC2Ev
	.long	674                             ## String in Bucket 10: _ZN5TimerD1Ev
	.long	539                             ## String in Bucket 11: getElapsedTimeInMilliSec
	.long	383                             ## String in Bucket 11: _ZN5Timer4stopEv
.set Lset33, Lnames14-Lnames_entries0   ## Offset in Bucket 0
	.long	Lset33
.set Lset34, Lnames21-Lnames_entries0   ## Offset in Bucket 0
	.long	Lset34
.set Lset35, Lnames9-Lnames_entries0    ## Offset in Bucket 1
	.long	Lset35
.set Lset36, Lnames4-Lnames_entries0    ## Offset in Bucket 1
	.long	Lset36
.set Lset37, Lnames0-Lnames_entries0    ## Offset in Bucket 2
	.long	Lset37
.set Lset38, Lnames17-Lnames_entries0   ## Offset in Bucket 2
	.long	Lset38
.set Lset39, Lnames23-Lnames_entries0   ## Offset in Bucket 2
	.long	Lset39
.set Lset40, Lnames15-Lnames_entries0   ## Offset in Bucket 3
	.long	Lset40
.set Lset41, Lnames3-Lnames_entries0    ## Offset in Bucket 3
	.long	Lset41
.set Lset42, Lnames24-Lnames_entries0   ## Offset in Bucket 3
	.long	Lset42
.set Lset43, Lnames10-Lnames_entries0   ## Offset in Bucket 4
	.long	Lset43
.set Lset44, Lnames1-Lnames_entries0    ## Offset in Bucket 4
	.long	Lset44
.set Lset45, Lnames20-Lnames_entries0   ## Offset in Bucket 5
	.long	Lset45
.set Lset46, Lnames22-Lnames_entries0   ## Offset in Bucket 6
	.long	Lset46
.set Lset47, Lnames7-Lnames_entries0    ## Offset in Bucket 6
	.long	Lset47
.set Lset48, Lnames13-Lnames_entries0   ## Offset in Bucket 7
	.long	Lset48
.set Lset49, Lnames11-Lnames_entries0   ## Offset in Bucket 7
	.long	Lset49
.set Lset50, Lnames2-Lnames_entries0    ## Offset in Bucket 8
	.long	Lset50
.set Lset51, Lnames18-Lnames_entries0   ## Offset in Bucket 8
	.long	Lset51
.set Lset52, Lnames5-Lnames_entries0    ## Offset in Bucket 9
	.long	Lset52
.set Lset53, Lnames6-Lnames_entries0    ## Offset in Bucket 9
	.long	Lset53
.set Lset54, Lnames8-Lnames_entries0    ## Offset in Bucket 10
	.long	Lset54
.set Lset55, Lnames12-Lnames_entries0   ## Offset in Bucket 10
	.long	Lset55
.set Lset56, Lnames19-Lnames_entries0   ## Offset in Bucket 11
	.long	Lset56
.set Lset57, Lnames16-Lnames_entries0   ## Offset in Bucket 11
	.long	Lset57
Lnames_abbrev_start0:
	.byte	1                               ## Abbrev code
	.byte	46                              ## DW_TAG_subprogram
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	2                               ## Abbrev code
	.byte	29                              ## DW_TAG_inlined_subroutine
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	3                               ## Abbrev code
	.byte	22                              ## DW_TAG_typedef
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	4                               ## Abbrev code
	.byte	2                               ## DW_TAG_class_type
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	5                               ## Abbrev code
	.byte	19                              ## DW_TAG_structure_type
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	6                               ## Abbrev code
	.byte	36                              ## DW_TAG_base_type
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev list
Lnames_abbrev_end0:
Lnames_entries0:
Lnames14:
L12:
	.byte	1                               ## Abbreviation code
	.long	421                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5Timer5startEv
Lnames21:
L2:
	.byte	1                               ## Abbreviation code
	.long	646                             ## DW_IDX_die_offset
L8:                                     ## DW_IDX_parent
	.byte	2                               ## Abbreviation code
	.long	751                             ## DW_IDX_die_offset
.set Lset58, L13-Lnames_entries0        ## DW_IDX_parent
	.long	Lset58
	.byte	0                               ## End of list: getElapsedTimeInSec
Lnames9:
L5:
	.byte	1                               ## Abbreviation code
	.long	316                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5TimerC1Ev
Lnames4:
L21:
	.byte	3                               ## Abbreviation code
	.long	235                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: __darwin_time_t
Lnames0:
L0:
	.byte	4                               ## Abbreviation code
	.long	40                              ## DW_IDX_die_offset
L1:                                     ## DW_IDX_parent
	.byte	1                               ## Abbreviation code
	.long	268                             ## DW_IDX_die_offset
	.byte	1                               ## DW_IDX_parent
                                        ## Abbreviation code
	.long	316                             ## DW_IDX_die_offset
L22:                                    ## DW_IDX_parent
	.byte	2                               ## Abbreviation code
	.long	343                             ## DW_IDX_die_offset
.set Lset59, L5-Lnames_entries0         ## DW_IDX_parent
	.long	Lset59
	.byte	0                               ## End of list: Timer
Lnames17:
L19:
	.byte	1                               ## Abbreviation code
	.long	522                             ## DW_IDX_die_offset
L14:                                    ## DW_IDX_parent
	.byte	2                               ## Abbreviation code
	.long	606                             ## DW_IDX_die_offset
.set Lset60, L9-Lnames_entries0         ## DW_IDX_parent
	.long	Lset60
L15:
	.byte	2                               ## Abbreviation code
	.long	668                             ## DW_IDX_die_offset
.set Lset61, L2-Lnames_entries0         ## DW_IDX_parent
	.long	Lset61
L6:
	.byte	2                               ## Abbreviation code
	.long	771                             ## DW_IDX_die_offset
.set Lset62, L8-Lnames_entries0         ## DW_IDX_parent
	.long	Lset62
	.byte	0                               ## End of list: getElapsedTimeInMicroSec
Lnames23:
L13:
	.byte	1                               ## Abbreviation code
	.long	726                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: getElapsedTime
Lnames15:
L10:
	.byte	1                               ## Abbreviation code
	.long	484                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: stop
Lnames3:
L16:
	.byte	5                               ## Abbreviation code
	.long	210                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: timeval
Lnames24:
	.byte	1                               ## Abbreviation code
	.long	726                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5Timer14getElapsedTimeEv
Lnames10:
L18:
	.byte	1                               ## Abbreviation code
	.long	365                             ## DW_IDX_die_offset
L11:                                    ## DW_IDX_parent
	.byte	1                               ## Abbreviation code
	.long	393                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: ~Timer
Lnames1:
L4:
	.byte	6                               ## Abbreviation code
	.long	202                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: double
Lnames20:
L9:
	.byte	1                               ## Abbreviation code
	.long	581                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5Timer24getElapsedTimeInMilliSecEv
Lnames22:
	.byte	1                               ## Abbreviation code
	.long	646                             ## DW_IDX_die_offset
	.byte	2                               ## DW_IDX_parent
                                        ## Abbreviation code
	.long	751                             ## DW_IDX_die_offset
.set Lset63, L13-Lnames_entries0        ## DW_IDX_parent
	.long	Lset63
	.byte	0                               ## End of list: _ZN5Timer19getElapsedTimeInSecEv
Lnames7:
L3:
	.byte	3                               ## Abbreviation code
	.long	255                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: __int32_t
Lnames13:
	.byte	1                               ## Abbreviation code
	.long	421                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: start
Lnames11:
	.byte	1                               ## Abbreviation code
	.long	365                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5TimerD2Ev
Lnames2:
L17:
	.byte	6                               ## Abbreviation code
	.long	206                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: int
Lnames18:
	.byte	1                               ## Abbreviation code
	.long	522                             ## DW_IDX_die_offset
	.byte	2                               ## DW_IDX_parent
                                        ## Abbreviation code
	.long	606                             ## DW_IDX_die_offset
.set Lset64, L9-Lnames_entries0         ## DW_IDX_parent
	.long	Lset64
	.byte	2                               ## Abbreviation code
	.long	668                             ## DW_IDX_die_offset
.set Lset65, L2-Lnames_entries0         ## DW_IDX_parent
	.long	Lset65
	.byte	2                               ## Abbreviation code
	.long	771                             ## DW_IDX_die_offset
.set Lset66, L8-Lnames_entries0         ## DW_IDX_parent
	.long	Lset66
	.byte	0                               ## End of list: _ZN5Timer24getElapsedTimeInMicroSecEv
Lnames5:
L20:
	.byte	6                               ## Abbreviation code
	.long	243                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: long
Lnames6:
L7:
	.byte	3                               ## Abbreviation code
	.long	247                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: __darwin_suseconds_t
Lnames8:
	.byte	1                               ## Abbreviation code
	.long	268                             ## DW_IDX_die_offset
	.byte	2                               ## DW_IDX_parent
                                        ## Abbreviation code
	.long	343                             ## DW_IDX_die_offset
.set Lset67, L5-Lnames_entries0         ## DW_IDX_parent
	.long	Lset67
	.byte	0                               ## End of list: _ZN5TimerC2Ev
Lnames12:
	.byte	1                               ## Abbreviation code
	.long	393                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5TimerD1Ev
Lnames19:
	.byte	1                               ## Abbreviation code
	.long	581                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: getElapsedTimeInMilliSec
Lnames16:
	.byte	1                               ## Abbreviation code
	.long	484                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: _ZN5Timer4stopEv
	.p2align	2, 0x0
Lnames_end0:
.subsections_via_symbols
	.section	__DWARF,__debug_line,regular,debug
Lsection_line:
Lline_table_start0:
