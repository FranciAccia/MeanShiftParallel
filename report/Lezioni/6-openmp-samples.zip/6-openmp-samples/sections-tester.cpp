#include <omp.h>
#include <cstdio>
#include <unistd.h>

int main(void) {

#pragma omp parallel num_threads(3)
    {
        // try (de)activating nowait
#pragma omp sections nowait
        {

#pragma omp section
            {
                printf("Section 1 - thread id = %d, started.\n", omp_get_thread_num());
                sleep(rand() % 3);
                printf("Section 1 - thread id = %d, completed.\n", omp_get_thread_num());
            }

#pragma omp section
            {
                printf("Section 2 - thread id = %d, started.\n", omp_get_thread_num());
                sleep(rand() % 5);
                printf("Section 2 - thread id = %d, completed.\n", omp_get_thread_num());
            }

#pragma omp section
            {
                printf("Section 3 - thread id = %d, started.\n", omp_get_thread_num());
                sleep(rand() % 3);
                printf("Section 3 - thread id = %d, completed.\n", omp_get_thread_num());
            }

#pragma omp section
            {
                printf("Section 4 - thread id = %d, started.\n", omp_get_thread_num());
                sleep(rand() % 5);
                printf("Section 4 - thread id = %d, completed.\n", omp_get_thread_num());
            }
        } // without nowait all the threads will stop here (implicit barrier) before executing the following

        // with nowait as soon as a thread finishes it executes the following instruction
        printf("Thread %d out of section\n", omp_get_thread_num());
    }

return 0;
}