# Empty dependencies file for sse_popcnt.
# This may be replaced when dependencies are built.
