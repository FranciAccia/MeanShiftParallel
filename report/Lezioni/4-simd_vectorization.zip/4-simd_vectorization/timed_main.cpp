#include <iostream>
#include "Timer.h"

using namespace std;

// XXX test this code in debug and release mode. Check how sum time changes

int main() {
    int sum = 0;
    int n = 10000;
    int *a = new int[n];
    Timer timer;
    // initialize
    timer.start();
    for (int i = 0; i < n; ++i) {
        a[i] = 1;
    }
    timer.stop();
    std::cout << "time to initialize: " << timer.getElapsedTimeInMicroSec() << " us \n";
    // sum
    timer.start();
    for (int i = 0; i < n; ++i) {
        sum += a[i];
    }
    timer.stop();
    std::cout << "time to sum: " << timer.getElapsedTimeInMicroSec() << " us \n";
    std::cout << sum << std::endl;
    return sum;
}