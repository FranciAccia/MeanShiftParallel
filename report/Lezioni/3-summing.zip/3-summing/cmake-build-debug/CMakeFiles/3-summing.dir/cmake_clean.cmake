file(REMOVE_RECURSE
  "3-summing"
  "3-summing.pdb"
  "CMakeFiles/3-summing.dir/main.cpp.o"
  "CMakeFiles/3-summing.dir/main.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/3-summing.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
