file(REMOVE_RECURSE
  "7c_profiling"
  "7c_profiling.pdb"
  "CMakeFiles/7c_profiling.dir/main.cpp.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/7c_profiling.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
