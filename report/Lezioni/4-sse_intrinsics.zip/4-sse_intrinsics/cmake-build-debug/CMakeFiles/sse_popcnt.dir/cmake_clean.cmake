file(REMOVE_RECURSE
  "CMakeFiles/sse_popcnt.dir/Timer.cpp.o"
  "CMakeFiles/sse_popcnt.dir/Timer.cpp.o.d"
  "CMakeFiles/sse_popcnt.dir/popcnt.cpp.o"
  "CMakeFiles/sse_popcnt.dir/popcnt.cpp.o.d"
  "sse_popcnt"
  "sse_popcnt.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/sse_popcnt.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
