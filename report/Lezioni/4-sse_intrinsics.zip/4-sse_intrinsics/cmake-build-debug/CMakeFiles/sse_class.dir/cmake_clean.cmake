file(REMOVE_RECURSE
  "CMakeFiles/sse_class.dir/Timer.cpp.o"
  "CMakeFiles/sse_class.dir/Timer.cpp.o.d"
  "CMakeFiles/sse_class.dir/sse_class.cpp.o"
  "CMakeFiles/sse_class.dir/sse_class.cpp.o.d"
  "sse_class"
  "sse_class.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/sse_class.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
