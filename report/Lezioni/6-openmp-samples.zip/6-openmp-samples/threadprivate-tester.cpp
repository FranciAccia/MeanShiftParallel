#include <cstdio>
#include "omp.h"

int main() {
    static int x = 100;
    static int* y;
#pragma omp threadprivate(x, y)
    y = new int[10];
    y[0] = -1;
    printf("Check the address of x and y in main thread and in thread 0 !\n\n");
    // print also the address of x
    printf("Main thread: x (at %p) = %d - y[0] (at %p): %d\n\n", (void*)&x, x, (void*)y, y[0]);

#pragma omp parallel copyin(x)
    {
        y = new int[10];
        x += omp_get_thread_num() + 1;  // Each thread has its own copy of 'x' with intialized value
        y[0] = omp_get_thread_num() + 1;
        printf("Thread %d: x (at %p) = %d - y[0] (at %p) = %d\n", omp_get_thread_num(), (void*)&x, x,  (void*)y, y[0]);
    }

    printf("Master thread: x (at %p) = %d - y[0] (at %p) = %d\n\n", (void*)&x, x,  (void*)y, y[0]);


#pragma omp parallel
{
    // 'x' and 'y' are preserved across parallel regions for each thread.
    printf("Thread %d after second region: x (at %p) = %d - y[0] (at %p) = %d\n", omp_get_thread_num(), (void*)&x, x,  (void*)y, y[0]);
}

    printf("Master thread %d: x (at %p) = %d - y[0] (at %p) = %d\n", omp_get_thread_num(), (void*)&x, x,  (void*)y, y[0]);

    return 0;
}