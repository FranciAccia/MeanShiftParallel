file(REMOVE_RECURSE
  "CMakeFiles/omp_msglk.dir/omp_msglk.cpp.o"
  "CMakeFiles/omp_msglk.dir/queue_lk.cpp.o"
  "omp_msglk"
  "omp_msglk.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/omp_msglk.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
