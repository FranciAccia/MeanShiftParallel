/*
 * MEMORY PREFETCHING DEMONSTRATION
 * Compile: g++ -O2 -o prefetch_demo prefetch_demo.cpp
 * Shows how access patterns affect hardware prefetcher effectiveness
 * 
 * IMPORTANT: All tests access the SAME NUMBER of elements for fair comparison
 */

#include <iostream>
#include <vector>
#include <chrono>
#include <random>
#include <algorithm>
#include <cassert>

// M2 has very large caches and aggressive prefetcher
// Need larger data to exceed cache and defeat prefetcher
const int SIZE = 256 * 1024 * 1024;  // 256M elements (~1GB)
const int NUM_ACCESSES = SIZE / 16;   // All tests will access this many elements

// Sequential access - prefetcher works great
double benchmark_sequential(const std::vector<int>& data) {
    auto start = std::chrono::high_resolution_clock::now();
    
    long long sum = 0;
    // Access every 16th element sequentially
    for (int i = 0; i < NUM_ACCESSES; i++) {
        sum += data[i * 16];
    }
    
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    
    // Prevent optimization
    if (sum == 0) std::cout << "";  // to avoid optimizing out the computation
    
    return duration.count();
}

// Strided access - prefetcher can still work if stride is regular
double benchmark_strided(const std::vector<int>& data, int stride) {
    auto start = std::chrono::high_resolution_clock::now();
    
    long long sum = 0;
    // Access with larger stride - still predictable
    for (int i = 0; i < NUM_ACCESSES; i++) {
        sum += data[size_t(i * stride) % SIZE];  // XXX without size_t cast we have sign overflow
    }
    
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    
    if (sum == 0) std::cout << "";  // to avoid optimizing out the computation
    
    return duration.count();
}

// Random access - prefetcher fails completely
double benchmark_random(const std::vector<int>& data, const std::vector<int>& indices) {
    auto start = std::chrono::high_resolution_clock::now();
    
    long long sum = 0;
    // Access same number of elements but in random order
    for (int i = 0; i < NUM_ACCESSES; i++) {
        sum += data[indices[i]];
    }
    
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    
    if (sum == 0) std::cout << "";  // to avoid optimizing out the computation
    
    return duration.count();
}

// Pointer chasing - worst case for prefetcher
struct Node {
    int value;
    int next_index;
};

double benchmark_pointer_chase(const std::vector<Node>& data, int start_index) {
    auto start = std::chrono::high_resolution_clock::now();
    
    long long sum = 0;
    int index = start_index;
    
    // Chase pointers NUM_ACCESSES times
    for (int i = 0; i < NUM_ACCESSES; i++) {
        sum += data[index].value;
        index = data[index].next_index;
    }
    
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    
    if (sum == 0) std::cout << "";  // to avoid optimizing out the computation
    
    return duration.count();
}

int main() {
    std::cout << "Hardware Prefetcher Effectiveness Demo\n";
    std::cout << "=======================================\n\n";
    
    // Allocate and initialize data
    std::cout << "Initializing " << (SIZE * sizeof(int) / (1024*1024)) << " MB of data...\n";
    std::cout << "Each test accesses " << NUM_ACCESSES << " elements for fair comparison\n\n";
    std::vector<int> data(SIZE);
    for (int i = 0; i < SIZE; i++) {
        data[i] = i;
    }
    
    // Test 1: Sequential access (with stride to match others)
    std::cout << "Test 1: Sequential Access (predictable pattern)\n";
    double seq_time = benchmark_sequential(data);
    std::cout << "  Time: " << seq_time << " ms\n";
    std::cout << "  ✓ Hardware prefetcher works optimally\n";
    
    // Test 2: Strided access with larger stride
    std::cout << "\nTest 2: Strided Access (regular stride, still predictable)\n";
    double stride_time = benchmark_strided(data, 256);
    std::cout << "  Time: " << stride_time << " ms\n";
    std::cout << "  Ratio vs sequential: " << stride_time / seq_time << "x\n";
    std::cout << "  ✓ Prefetcher can detect regular strides\n";
    
    // Test 3: Random access
    std::cout << "\nTest 3: Random Access (completely unpredictable)\n";
    std::vector<int> random_indices(NUM_ACCESSES);
    
    // Generate truly random indices spread across entire array
    std::random_device rd;
    std::mt19937 g(rd());
    std::uniform_int_distribution<> dist(0, SIZE - 1);
    
    for (int i = 0; i < NUM_ACCESSES; i++) {
        random_indices[i] = dist(g);
    }
    
    double random_time = benchmark_random(data, random_indices);
    std::cout << "  Time: " << random_time << " ms\n";
    std::cout << "  Ratio vs sequential: " << random_time / seq_time << "x\n";
    std::cout << "  !️  Prefetcher cannot predict random access!\n";
    
    // Test 4: Pointer chasing
    std::cout << "\nTest 4: Pointer Chasing (each access depends on previous)\n";
    std::vector<Node> nodes(NUM_ACCESSES);
    
    // Create a shuffled chain
    std::vector<int> chain_indices(nodes.size());
    for (size_t i = 0; i < chain_indices.size(); i++) {
        chain_indices[i] = i;
    }
    auto last_shuffled = chain_indices.end();
    double percent_to_shuffle = 0.8; // Shuffle 80% of the chain
    for (int i = 0; i < int(NUM_ACCESSES*(1-percent_to_shuffle)); i++) {
        last_shuffled--;
    }
    std::shuffle(chain_indices.begin(), last_shuffled, g);
    std::cout << "  % shuffled nodes: " << (percent_to_shuffle * 100) << "%\n";
    
    for (size_t i = 0; i < nodes.size(); i++) {
        nodes[i].value = i;
        nodes[i].next_index = chain_indices[(i + 1) % nodes.size()];
    }
    
    double chase_time = benchmark_pointer_chase(nodes, 0);
    std::cout << "  Time: " << chase_time << " ms\n";
    std::cout << "  Ratio vs sequential: " << chase_time / seq_time << "x\n";
    std::cout << "  !  Each access depends on previous - cannot prefetch!\n";
    
    // Summary
    std::cout << "\n=== Performance Summary ===\n";
    std::cout << "Sequential:      " << seq_time << " ms (baseline)\n";
    std::cout << "Strided:         " << stride_time << " ms (" 
              << (stride_time/seq_time) << "x)\n";
    std::cout << "Random:          " << random_time << " ms (" 
              << (random_time/seq_time) << "x)\n";
    std::cout << "Pointer chasing: " << chase_time << " ms (" 
              << (chase_time/seq_time) << "x)\n";
    
    std::cout << "\n=== Key Takeaways ===\n";
    std::cout << "1. Sequential access: Prefetcher brings next cache lines automatically\n";
    std::cout << "2. Strided access: Prefetcher detects pattern after few iterations\n";
    std::cout << "3. Random access: Prefetcher is ineffective - every access is a cache miss\n";
    std::cout << "4. Pointer chasing: Cannot prefetch - each access depends on previous\n";
    std::cout << "5. Algorithm design should favor sequential access patterns!\n";
    
    // Architecture-specific notes
    #if defined(__APPLE__) && (defined(__aarch64__) || defined(__arm64__))
    std::cout << "\n=== Apple Silicon Note ===\n";
    std::cout << "M1/M2/M3 have extremely sophisticated prefetchers and large caches.\n";
    std::cout << "Results may be less dramatic than on x86, but principles remain the same!\n";
    std::cout << "On typical x86: random access can be 10-20x slower.\n";
    std::cout << "On Apple Silicon: 2-10x slower, but still significant.\n";
    #endif
    
    return 0;
}

/*
 * TYPICAL RESULTS on M2/Apple Silicon:
 * - M2 has HUGE caches (16MB+ SLC) and aggressive prefetcher
 * - Sequential: ~20-40 ms (excellent prefetching)
 * - Strided:    ~50-100 ms (fewer accesses, still prefetched)
 * - Random:     ~200-1200 ms (3-5x slower! - cache misses everywhere)
 * - Pointer chasing: Similar to random (dependent loads)
 * 
 * On x86 Intel/AMD with smaller caches:
 * - Differences are even more dramatic (10-20x)
 * 
 * This shows why data structure layout and access patterns matter so much!
 * 
 * Note for M2/M3: Apple Silicon has incredibly sophisticated prefetchers,
 * so you need very large datasets and truly random access to see the effect.
 */