# Empty compiler generated dependencies file for bad-flush_producer_consumer.
# This may be replaced when dependencies are built.
