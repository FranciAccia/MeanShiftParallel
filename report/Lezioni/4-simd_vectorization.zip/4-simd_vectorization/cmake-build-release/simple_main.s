	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 15, 0	sdk_version 26, 0
	.globl	_main                           ## -- Begin function main
	.p2align	4, 0x90
_main:                                  ## @main
Lfunc_begin0:
	.file	0 "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization/cmake-build-release" "simple_main.cpp" md5 0xced0d2df0a6172462b81b81efad66839
	.file	1 "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization" "simple_main.cpp"
	.loc	1 1 0                           ## simple_main.cpp:1:0
	.cfi_startproc
## %bb.0:                               ## %.preheader.preheader
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
Ltmp0:
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
Ltmp1:
	##DEBUG_VALUE: main:n <- 10000
	.loc	1 3 14 prologue_end             ## simple_main.cpp:3:14
	movl	$40000, %edi                    ## imm = 0x9C40
	callq	__Znam
Ltmp2:
	movq	%rax, %rbx
Ltmp3:
	##DEBUG_VALUE: i <- 0
	##DEBUG_VALUE: main:a <- $rbx
	.loc	1 7 14                          ## simple_main.cpp:7:14
	leaq	L_.memset_pattern(%rip), %rsi
	movl	$40000, %edx                    ## imm = 0x9C40
	movq	%rax, %rdi
	callq	_memset_pattern16
Ltmp4:
	.loc	1 0 14 is_stmt 0                ## simple_main.cpp:0:14
	pxor	%xmm0, %xmm0
	xorl	%eax, %eax
Ltmp5:
	##DEBUG_VALUE: i <- undef
	.p2align	4, 0x90
LBB0_1:                                 ## %vector.body
                                        ## =>This Inner Loop Header: Depth=1
	##DEBUG_VALUE: main:a <- $rbx
	##DEBUG_VALUE: main:n <- 10000
	.loc	1 12 16 is_stmt 1               ## simple_main.cpp:12:16
	movdqu	(%rbx,%rax,4), %xmm1
	.loc	1 12 13 is_stmt 0               ## simple_main.cpp:12:13
	paddd	%xmm1, %xmm0
Ltmp6:
	.loc	1 11 28 is_stmt 1               ## simple_main.cpp:11:28
	addq	$4, %rax
	cmpq	$10000, %rax                    ## imm = 0x2710
	jne	LBB0_1
Ltmp7:
## %bb.2:                               ## %middle.block
	##DEBUG_VALUE: main:a <- $rbx
	##DEBUG_VALUE: main:n <- 10000
	.loc	1 11 5 is_stmt 0                ## simple_main.cpp:11:5
	pshufd	$238, %xmm0, %xmm1              ## xmm1 = xmm0[2,3,2,3]
	paddd	%xmm0, %xmm1
	pshufd	$85, %xmm1, %xmm0               ## xmm0 = xmm1[1,1,1,1]
	paddd	%xmm1, %xmm0
	movd	%xmm0, %r14d
Ltmp8:
	.loc	1 14 5 is_stmt 1                ## simple_main.cpp:14:5
	movq	%rbx, %rdi
	callq	__ZdaPv
Ltmp9:
	.loc	1 15 5                          ## simple_main.cpp:15:5
	movl	%r14d, %eax
	.loc	1 15 5 epilogue_begin is_stmt 0 ## simple_main.cpp:15:5
	popq	%rbx
Ltmp10:
	popq	%r14
	popq	%rbp
	retq
Ltmp11:
Lfunc_end0:
	.cfi_endproc
                                        ## -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ## @.memset_pattern
L_.memset_pattern:
	.long	1                               ## 0x1
	.long	1                               ## 0x1
	.long	1                               ## 0x1
	.long	1                               ## 0x1

	.section	__DWARF,__debug_loclists,regular,debug
Lsection_debug_loc0:
.set Lset0, Ldebug_list_header_end0-Ldebug_list_header_start0 ## Length
	.long	Lset0
Ldebug_list_header_start0:
	.short	5                               ## Version
	.byte	8                               ## Address size
	.byte	0                               ## Segment selector size
	.long	2                               ## Offset entry count
Lloclists_table_base0:
.set Lset1, Ldebug_loc0-Lloclists_table_base0
	.long	Lset1
.set Lset2, Ldebug_loc1-Lloclists_table_base0
	.long	Lset2
Ldebug_loc0:
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Ltmp3-Lfunc_begin0             ##   starting offset
	.uleb128 Ltmp5-Lfunc_begin0             ##   ending offset
	.byte	3                               ## Loc expr size
	.byte	17                              ## DW_OP_consts
	.byte	0                               ## 0
	.byte	159                             ## DW_OP_stack_value
	.byte	0                               ## DW_LLE_end_of_list
Ldebug_loc1:
	.byte	4                               ## DW_LLE_offset_pair
	.uleb128 Ltmp3-Lfunc_begin0             ##   starting offset
	.uleb128 Ltmp10-Lfunc_begin0            ##   ending offset
	.byte	1                               ## Loc expr size
	.byte	83                              ## DW_OP_reg3
	.byte	0                               ## DW_LLE_end_of_list
Ldebug_list_header_end0:
	.section	__DWARF,__debug_abbrev,regular,debug
Lsection_abbrev:
	.byte	1                               ## Abbreviation Code
	.byte	17                              ## DW_TAG_compile_unit
	.byte	1                               ## DW_CHILDREN_yes
	.byte	37                              ## DW_AT_producer
	.byte	37                              ## DW_FORM_strx1
	.byte	19                              ## DW_AT_language
	.byte	5                               ## DW_FORM_data2
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.ascii	"\202|"                         ## DW_AT_LLVM_sysroot
	.byte	37                              ## DW_FORM_strx1
	.byte	114                             ## DW_AT_str_offsets_base
	.byte	23                              ## DW_FORM_sec_offset
	.byte	16                              ## DW_AT_stmt_list
	.byte	23                              ## DW_FORM_sec_offset
	.byte	27                              ## DW_AT_comp_dir
	.byte	37                              ## DW_FORM_strx1
	.ascii	"\341\177"                      ## DW_AT_APPLE_optimized
	.byte	25                              ## DW_FORM_flag_present
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	115                             ## DW_AT_addr_base
	.byte	23                              ## DW_FORM_sec_offset
	.ascii	"\214\001"                      ## DW_AT_loclists_base
	.byte	23                              ## DW_FORM_sec_offset
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	2                               ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	64                              ## DW_AT_frame_base
	.byte	24                              ## DW_FORM_exprloc
	.byte	122                             ## DW_AT_call_all_calls
	.byte	25                              ## DW_FORM_flag_present
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	63                              ## DW_AT_external
	.byte	25                              ## DW_FORM_flag_present
	.ascii	"\341\177"                      ## DW_AT_APPLE_optimized
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	3                               ## Abbreviation Code
	.byte	52                              ## DW_TAG_variable
	.byte	0                               ## DW_CHILDREN_no
	.byte	28                              ## DW_AT_const_value
	.byte	13                              ## DW_FORM_sdata
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	4                               ## Abbreviation Code
	.byte	52                              ## DW_TAG_variable
	.byte	0                               ## DW_CHILDREN_no
	.byte	2                               ## DW_AT_location
	.byte	34                              ## DW_FORM_loclistx
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	5                               ## Abbreviation Code
	.byte	52                              ## DW_TAG_variable
	.byte	0                               ## DW_CHILDREN_no
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	6                               ## Abbreviation Code
	.byte	11                              ## DW_TAG_lexical_block
	.byte	1                               ## DW_CHILDREN_yes
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	7                               ## Abbreviation Code
	.byte	36                              ## DW_TAG_base_type
	.byte	0                               ## DW_CHILDREN_no
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	62                              ## DW_AT_encoding
	.byte	11                              ## DW_FORM_data1
	.byte	11                              ## DW_AT_byte_size
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	8                               ## Abbreviation Code
	.byte	15                              ## DW_TAG_pointer_type
	.byte	0                               ## DW_CHILDREN_no
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	0                               ## EOM(3)
	.section	__DWARF,__debug_info,regular,debug
Lsection_info:
Lcu_begin0:
.set Lset3, Ldebug_info_end0-Ldebug_info_start0 ## Length of Unit
	.long	Lset3
Ldebug_info_start0:
	.short	5                               ## DWARF version number
	.byte	1                               ## DWARF Unit Type
	.byte	8                               ## Address Size (in bytes)
.set Lset4, Lsection_abbrev-Lsection_abbrev ## Offset Into Abbrev. Section
	.long	Lset4
	.byte	1                               ## Abbrev [1] 0xc:0x71 DW_TAG_compile_unit
	.byte	0                               ## DW_AT_producer
	.short	26                              ## DW_AT_language
	.byte	1                               ## DW_AT_name
	.byte	2                               ## DW_AT_LLVM_sysroot
.set Lset5, Lstr_offsets_base0-Lsection_str_off ## DW_AT_str_offsets_base
	.long	Lset5
.set Lset6, Lline_table_start0-Lsection_line ## DW_AT_stmt_list
	.long	Lset6
	.byte	3                               ## DW_AT_comp_dir
                                        ## DW_AT_APPLE_optimized
	.byte	0                               ## DW_AT_low_pc
.set Lset7, Lfunc_end0-Lfunc_begin0     ## DW_AT_high_pc
	.long	Lset7
.set Lset8, Laddr_table_base0-Lsection_info0 ## DW_AT_addr_base
	.long	Lset8
.set Lset9, Lloclists_table_base0-Lsection_debug_loc0 ## DW_AT_loclists_base
	.long	Lset9
	.byte	2                               ## Abbrev [2] 0x28:0x4b DW_TAG_subprogram
	.byte	0                               ## DW_AT_low_pc
.set Lset10, Lfunc_end0-Lfunc_begin0    ## DW_AT_high_pc
	.long	Lset10
	.byte	1                               ## DW_AT_frame_base
	.byte	86
                                        ## DW_AT_call_all_calls
	.byte	4                               ## DW_AT_name
	.byte	1                               ## DW_AT_decl_file
	.byte	1                               ## DW_AT_decl_line
	.long	115                             ## DW_AT_type
                                        ## DW_AT_external
                                        ## DW_AT_APPLE_optimized
	.byte	3                               ## Abbrev [3] 0x37:0xb DW_TAG_variable
	.asciz	"\220\316"                      ## DW_AT_const_value
	.byte	6                               ## DW_AT_name
	.byte	1                               ## DW_AT_decl_file
	.byte	2                               ## DW_AT_decl_line
	.long	115                             ## DW_AT_type
	.byte	4                               ## Abbrev [4] 0x42:0x9 DW_TAG_variable
	.byte	1                               ## DW_AT_location
	.byte	8                               ## DW_AT_name
	.byte	1                               ## DW_AT_decl_file
	.byte	3                               ## DW_AT_decl_line
	.long	119                             ## DW_AT_type
	.byte	5                               ## Abbrev [5] 0x4b:0x8 DW_TAG_variable
	.byte	9                               ## DW_AT_name
	.byte	1                               ## DW_AT_decl_file
	.byte	10                              ## DW_AT_decl_line
	.long	115                             ## DW_AT_type
	.byte	6                               ## Abbrev [6] 0x53:0x10 DW_TAG_lexical_block
	.byte	1                               ## DW_AT_low_pc
.set Lset11, Ltmp5-Ltmp3                ## DW_AT_high_pc
	.long	Lset11
	.byte	4                               ## Abbrev [4] 0x59:0x9 DW_TAG_variable
	.byte	0                               ## DW_AT_location
	.byte	7                               ## DW_AT_name
	.byte	1                               ## DW_AT_decl_file
	.byte	6                               ## DW_AT_decl_line
	.long	115                             ## DW_AT_type
	.byte	0                               ## End Of Children Mark
	.byte	6                               ## Abbrev [6] 0x63:0xf DW_TAG_lexical_block
	.byte	2                               ## DW_AT_low_pc
.set Lset12, Ltmp8-Ltmp5                ## DW_AT_high_pc
	.long	Lset12
	.byte	5                               ## Abbrev [5] 0x69:0x8 DW_TAG_variable
	.byte	7                               ## DW_AT_name
	.byte	1                               ## DW_AT_decl_file
	.byte	11                              ## DW_AT_decl_line
	.long	115                             ## DW_AT_type
	.byte	0                               ## End Of Children Mark
	.byte	0                               ## End Of Children Mark
	.byte	7                               ## Abbrev [7] 0x73:0x4 DW_TAG_base_type
	.byte	5                               ## DW_AT_name
	.byte	5                               ## DW_AT_encoding
	.byte	4                               ## DW_AT_byte_size
	.byte	8                               ## Abbrev [8] 0x77:0x5 DW_TAG_pointer_type
	.long	115                             ## DW_AT_type
	.byte	0                               ## End Of Children Mark
Ldebug_info_end0:
	.section	__DWARF,__debug_str_offs,regular,debug
Lsection_str_off:
	.long	44                              ## Length of String Offsets Set
	.short	5
	.short	0
Lstr_offsets_base0:
	.section	__DWARF,__debug_str,regular,debug
Linfo_string:
	.asciz	"Apple clang version 17.0.0 (clang-1700.3.19.1)" ## string offset=0
	.asciz	"simple_main.cpp"               ## string offset=47
	.asciz	"/"                             ## string offset=63
	.asciz	"/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization/cmake-build-release" ## string offset=65
	.asciz	"main"                          ## string offset=200
	.asciz	"int"                           ## string offset=205
	.asciz	"n"                             ## string offset=209
	.asciz	"i"                             ## string offset=211
	.asciz	"a"                             ## string offset=213
	.asciz	"sum"                           ## string offset=215
	.section	__DWARF,__debug_str_offs,regular,debug
	.long	0
	.long	47
	.long	63
	.long	65
	.long	200
	.long	205
	.long	209
	.long	211
	.long	213
	.long	215
	.section	__DWARF,__debug_addr,regular,debug
Lsection_info0:
.set Lset13, Ldebug_addr_end0-Ldebug_addr_start0 ## Length of contribution
	.long	Lset13
Ldebug_addr_start0:
	.short	5                               ## DWARF version number
	.byte	8                               ## Address size
	.byte	0                               ## Segment selector size
Laddr_table_base0:
	.quad	Lfunc_begin0
	.quad	Ltmp3
	.quad	Ltmp5
Ldebug_addr_end0:
	.section	__DWARF,__debug_names,regular,debug
Ldebug_names_begin:
.set Lset14, Lnames_end0-Lnames_start0  ## Header: unit length
	.long	Lset14
Lnames_start0:
	.short	5                               ## Header: version
	.short	0                               ## Header: padding
	.long	1                               ## Header: compilation unit count
	.long	0                               ## Header: local type unit count
	.long	0                               ## Header: foreign type unit count
	.long	2                               ## Header: bucket count
	.long	2                               ## Header: name count
.set Lset15, Lnames_abbrev_end0-Lnames_abbrev_start0 ## Header: abbreviation table size
	.long	Lset15
	.long	8                               ## Header: augmentation string size
	.ascii	"LLVM0700"                      ## Header: augmentation string
.set Lset16, Lcu_begin0-Lsection_info   ## Compilation unit 0
	.long	Lset16
	.long	1                               ## Bucket 0
	.long	0                               ## Bucket 1
	.long	193495088                       ## Hash in Bucket 0
	.long	2090499946                      ## Hash in Bucket 0
	.long	205                             ## String in Bucket 0: int
	.long	200                             ## String in Bucket 0: main
.set Lset17, Lnames1-Lnames_entries0    ## Offset in Bucket 0
	.long	Lset17
.set Lset18, Lnames0-Lnames_entries0    ## Offset in Bucket 0
	.long	Lset18
Lnames_abbrev_start0:
	.byte	1                               ## Abbrev code
	.byte	36                              ## DW_TAG_base_type
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	2                               ## Abbrev code
	.byte	46                              ## DW_TAG_subprogram
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev list
Lnames_abbrev_end0:
Lnames_entries0:
Lnames1:
L1:
	.byte	1                               ## Abbreviation code
	.long	115                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: int
Lnames0:
L0:
	.byte	2                               ## Abbreviation code
	.long	40                              ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: main
	.p2align	2, 0x0
Lnames_end0:
.subsections_via_symbols
	.section	__DWARF,__debug_line,regular,debug
Lsection_line:
Lline_table_start0:
