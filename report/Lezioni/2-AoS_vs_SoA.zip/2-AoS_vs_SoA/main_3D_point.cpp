#include <iostream>
#include <iomanip>
#include <string>
#include <chrono>
#include <vector>
#include <numeric>

using namespace std;
using namespace chrono;

const int NUM_ELEMENTS = 300'000'000;  // with less elements the AoS may be faster in Release mode

//
// Array of structures approach
//
struct Point {
    Point(int x, int y, int z) : x(x), y(y), z(z) {}

    int x;
    int y;
    int z;
};

struct Particle {
    Particle(Point pos, Point vel, int id) : position(pos.x, pos.y, pos.z), velocity(vel.x, vel.y, vel.z), id(id) {}

    Point position;
    Point velocity;
    int id;
};

void addParticle(std::vector<Particle> &v, Particle &&p) {
    v.push_back(std::move(p));
}

int update_positions(std::vector<Particle> &particles) {
    int num_processed = 0;
    for (auto &p: particles) {
        p.position.x += p.velocity.x;
        p.position.y += p.velocity.y;
        p.position.z += p.velocity.z;  // try commenting out z update in AoS and SoA
        num_processed++;
    }
    return num_processed;
}

int count_ids(const std::vector<Particle> &particles, int id) {
    int count = 0;
    for (const auto &p: particles) {
        if (p.id == id)
            count++;
    }
    return count;
}


//
// Structure of arrays approach
//
struct Particles {
    int numParticles = 0;
    std::vector<int> xPos;
    std::vector<int> yPos;
    std::vector<int> zPos;
    std::vector<int> xVelocity;
    std::vector<int> yVelocity;
    std::vector<int> zVelocity;
    std::vector<int> id;

    void addParticle(int x, int y, int z, int xv, int yv, int zv, int id) {
        xPos.push_back(x);
        yPos.push_back(y);
        zPos.push_back(z);
        xVelocity.push_back(xv);
        yVelocity.push_back(yv);
        zVelocity.push_back(zv);
        this->id.push_back(id);
        numParticles++;
    }

    int update_positions() {
        int num_processed = 0;
        // check the difference between these loops
        // for (int i = 0; i < numParticles; i++) {
        //     xPos[i] += xVelocity[i];
        //     yPos[i] += yVelocity[i];
        //     zPos[i] += zVelocity[i];  // try commenting out z update in AoS and SoA
        //     num_processed++;
        // }
        // it should be easier to vectorize these loops
        for (int i = 0; i < numParticles; i++) {
            xPos[i] += xVelocity[i];
            num_processed++;
        }
        for (int i = 0; i < numParticles; i++) yPos[i] += yVelocity[i];
        for (int i = 0; i < numParticles; i++) zPos[i] += zVelocity[i];
        return num_processed;
    }

    int count_ids(int id) const {
        int count = 0;
        for (int i = 0; i < numParticles; i++) {
            if (this->id[i] == id)
                count++;
        }
        return count;
    }
};


int main() {
    vector<Particle> v1;
    v1.reserve(NUM_ELEMENTS);
    for (int i = 0; i < NUM_ELEMENTS; ++i)
        addParticle(v1, Particle(Point(rand() % 0xFFFF, rand() % 0xFFFF, rand() % 0xFFFF),
                                 Point(rand() % 0xFFFF, rand() % 0xFFFF, rand() % 0xFFFF), rand() % 0xFFFF));

    // AoS
    auto start_time = high_resolution_clock::now();
    // use sum to avoid elimination of function calls due to compiler optimization
    auto sum = update_positions(v1);
    sum += count_ids(v1, 0);
    auto end_time = high_resolution_clock::now();
    auto aos_time = duration_cast<microseconds>(end_time - start_time).count() / 1000.f;
    cout << fixed << setprecision(3);
    cout << "AoS duration " << aos_time << " ms" << endl;
    v1.clear();
    v1.shrink_to_fit();

    // SoA
    Particles p;
    p.xPos.reserve(NUM_ELEMENTS);
    p.yPos.reserve(NUM_ELEMENTS);
    p.zPos.reserve(NUM_ELEMENTS);
    p.xVelocity.reserve(NUM_ELEMENTS);
    p.yVelocity.reserve(NUM_ELEMENTS);
    p.zVelocity.reserve(NUM_ELEMENTS);
    p.id.reserve(NUM_ELEMENTS);
    for (int i = 0; i < NUM_ELEMENTS; ++i)
        p.addParticle(rand() % 0xFFFF, rand() % 0xFFFF, rand() % 0xFFFF, rand() % 0xFFFF, rand() % 0xFFFF,
                      rand() % 0xFFFF, rand() % 0xFFFF);

    start_time = high_resolution_clock::now();
    sum += p.update_positions();
    sum += p.count_ids(0);
    end_time = high_resolution_clock::now();
    auto soa_time = duration_cast<microseconds>(end_time - start_time).count() / 1000.f;
    cout << "SoA duration " << soa_time << " ms" << endl;

    cout << "Speedup SoA vs. AoS: " << float(aos_time) / soa_time << endl;
    return sum;  // to avoid elimination of function calls due to compiler optimization
}