# Empty dependencies file for counter_better_lock_cache.
# This may be replaced when dependencies are built.
