#include <omp.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>

#include "utilities.h"
#include "ConcurrentQueue.h"

using namespace std;

int main() {
    ConcurrentQueue<int> sharedQueue;
    int i = 3;
    int v;
    sharedQueue.enqueue(i);
    sharedQueue.dequeue(v);
    cout << "Hello, World - i: " << i << " - v: " << v << endl;

    std::string filename = (searchFiles()).front();
    std::ifstream infile(filename);
    std::string line;

    while (std::getline(infile, line)) {
        for_each(line.begin(), line.end(), convertUpperLower());
        std::cout << line << std::endl;
    }


    return 0;
}