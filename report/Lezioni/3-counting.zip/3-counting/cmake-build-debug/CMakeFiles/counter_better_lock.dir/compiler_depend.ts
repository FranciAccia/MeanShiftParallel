# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for counter_better_lock.
