file(REMOVE_RECURSE
  "CMakeFiles/counter_lock.dir/counter_lock.cpp.o"
  "CMakeFiles/counter_lock.dir/counter_lock.cpp.o.d"
  "counter_lock"
  "counter_lock.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/counter_lock.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
