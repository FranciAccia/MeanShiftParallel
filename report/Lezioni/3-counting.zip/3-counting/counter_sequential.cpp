#include <stdio.h>
#include <sys/time.h>

#include "params.h"

// XXX better to run in Debug all the programs, so to discount threads overhead.
// XXX anyway better_lock implementation is faster also in case of Release version

int counter = 0;
int buffer[BUFFER_SIZE];

void prepareBuffer() {
    for (long i = 0; i < BUFFER_SIZE; ++i) {
        buffer[i] = i % 10;
    }
}

void* countEven(void* data) {
    int* thread_id = (int*) data;
    int length_per_thread = BUFFER_SIZE;
    int start = *thread_id * length_per_thread;
    for (int i = start; i < start + length_per_thread; i++) {
        if (buffer[i] % 2) {
            counter++;
            buffer[i] += 2;
        } else {
            buffer[i] *= 2;
        }
    }
    return NULL;
}

void* count3orig(void* data) {
    int* thread_id = (int*) data;
    int length_per_thread = BUFFER_SIZE;
    int start = *thread_id * length_per_thread;
    for (int i = start; i < start + length_per_thread; i++) {
        if (buffer[i] == 3) {
            counter++;
        }
    }
    return NULL;
}

int main() {
    prepareBuffer();
    int id[1];

    timeval t1, t2;
    gettimeofday(&t1, NULL);
    for (int times=0; times < REPETITIONS; times++) {
        id[0] = 0;
        count3orig( (void*) id);
    }
    gettimeofday(&t2, NULL);
    double elapsedTimeMs = (t2.tv_sec - t1.tv_sec) * 1000.0;      // sec to ms
    elapsedTimeMs += (t2.tv_usec - t1.tv_usec) / 1000.0;   // us to ms
    printf("Time taken: %f milliseconds\n", elapsedTimeMs);
    printf("3 Counter: %d\n", counter);

    gettimeofday(&t1, NULL);
    for (int times=0; times < REPETITIONS; times++) {
        id[0] = 0;
        countEven((void*) id);
    }
    gettimeofday(&t2, NULL);
    elapsedTimeMs = (t2.tv_sec - t1.tv_sec) * 1000.0;      // sec to ms
    elapsedTimeMs += (t2.tv_usec - t1.tv_usec) / 1000.0;   // us to ms
    printf("Time taken: %f milliseconds\n", elapsedTimeMs);
    printf("Counter: %d\n", counter);
}