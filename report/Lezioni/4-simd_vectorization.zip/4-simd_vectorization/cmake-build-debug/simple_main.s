	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 15, 0	sdk_version 26, 0
	.globl	_main                           ## -- Begin function main
	.p2align	4, 0x90
_main:                                  ## @main
Lfunc_begin0:
	.file	0 "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization/cmake-build-debug" "simple_main.cpp" md5 0x586c536935e1bc0ff9dd6ffb300f9e52
	.file	1 "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization" "simple_main.cpp"
	.loc	1 1 0                           ## simple_main.cpp:1:0
	.cfi_startproc
## %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$48, %rsp
	movl	$0, -4(%rbp)
Ltmp0:
	.loc	1 2 9 prologue_end              ## simple_main.cpp:2:9
	movl	$10000, -8(%rbp)                ## imm = 0x2710
	.loc	1 3 14                          ## simple_main.cpp:3:14
	movslq	-8(%rbp), %rax
	movl	$4, %ecx
	mulq	%rcx
	movq	%rax, %rdi
	seto	%cl
	movq	$-1, %rax
	testb	$1, %cl
	cmovneq	%rax, %rdi
	callq	__Znam
	.loc	1 3 10 is_stmt 0                ## simple_main.cpp:3:10
	movq	%rax, -16(%rbp)
Ltmp1:
	.loc	1 6 14 is_stmt 1                ## simple_main.cpp:6:14
	movl	$0, -20(%rbp)
LBB0_1:                                 ## =>This Inner Loop Header: Depth=1
Ltmp2:
	.loc	1 6 21 is_stmt 0                ## simple_main.cpp:6:21
	movl	-20(%rbp), %eax
	.loc	1 6 23                          ## simple_main.cpp:6:23
	cmpl	-8(%rbp), %eax
Ltmp3:
	.loc	1 6 5                           ## simple_main.cpp:6:5
	jge	LBB0_4
## %bb.2:                               ##   in Loop: Header=BB0_1 Depth=1
Ltmp4:
	.loc	1 7 9 is_stmt 1                 ## simple_main.cpp:7:9
	movq	-16(%rbp), %rax
	movslq	-20(%rbp), %rcx
	.loc	1 7 14 is_stmt 0                ## simple_main.cpp:7:14
	movl	$1, (%rax,%rcx,4)
Ltmp5:
## %bb.3:                               ##   in Loop: Header=BB0_1 Depth=1
	.loc	1 6 28 is_stmt 1                ## simple_main.cpp:6:28
	movl	-20(%rbp), %eax
	addl	$1, %eax
	movl	%eax, -20(%rbp)
	.loc	1 6 5 is_stmt 0                 ## simple_main.cpp:6:5
	jmp	LBB0_1
Ltmp6:
LBB0_4:
	.loc	1 10 9 is_stmt 1                ## simple_main.cpp:10:9
	movl	$0, -24(%rbp)
Ltmp7:
	.loc	1 11 14                         ## simple_main.cpp:11:14
	movl	$0, -28(%rbp)
LBB0_5:                                 ## =>This Inner Loop Header: Depth=1
Ltmp8:
	.loc	1 11 21 is_stmt 0               ## simple_main.cpp:11:21
	movl	-28(%rbp), %eax
	.loc	1 11 23                         ## simple_main.cpp:11:23
	cmpl	-8(%rbp), %eax
Ltmp9:
	.loc	1 11 5                          ## simple_main.cpp:11:5
	jge	LBB0_8
## %bb.6:                               ##   in Loop: Header=BB0_5 Depth=1
Ltmp10:
	.loc	1 12 16 is_stmt 1               ## simple_main.cpp:12:16
	movq	-16(%rbp), %rax
	movslq	-28(%rbp), %rcx
	movl	(%rax,%rcx,4), %eax
	.loc	1 12 13 is_stmt 0               ## simple_main.cpp:12:13
	addl	-24(%rbp), %eax
	movl	%eax, -24(%rbp)
Ltmp11:
## %bb.7:                               ##   in Loop: Header=BB0_5 Depth=1
	.loc	1 11 28 is_stmt 1               ## simple_main.cpp:11:28
	movl	-28(%rbp), %eax
	addl	$1, %eax
	movl	%eax, -28(%rbp)
	.loc	1 11 5 is_stmt 0                ## simple_main.cpp:11:5
	jmp	LBB0_5
Ltmp12:
LBB0_8:
	.loc	1 14 14 is_stmt 1               ## simple_main.cpp:14:14
	movq	-16(%rbp), %rax
	movq	%rax, -40(%rbp)                 ## 8-byte Spill
	.loc	1 14 5 is_stmt 0                ## simple_main.cpp:14:5
	cmpq	$0, %rax
	je	LBB0_10
## %bb.9:
	.loc	1 0 5                           ## simple_main.cpp:0:5
	movq	-40(%rbp), %rdi                 ## 8-byte Reload
	.loc	1 14 5                          ## simple_main.cpp:14:5
	callq	__ZdaPv
LBB0_10:
	.loc	1 15 12 is_stmt 1               ## simple_main.cpp:15:12
	movl	-24(%rbp), %eax
	.loc	1 15 5 epilogue_begin is_stmt 0 ## simple_main.cpp:15:5
	addq	$48, %rsp
	popq	%rbp
	retq
Ltmp13:
Lfunc_end0:
	.cfi_endproc
                                        ## -- End function
	.section	__DWARF,__debug_abbrev,regular,debug
Lsection_abbrev:
	.byte	1                               ## Abbreviation Code
	.byte	17                              ## DW_TAG_compile_unit
	.byte	1                               ## DW_CHILDREN_yes
	.byte	37                              ## DW_AT_producer
	.byte	37                              ## DW_FORM_strx1
	.byte	19                              ## DW_AT_language
	.byte	5                               ## DW_FORM_data2
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.ascii	"\202|"                         ## DW_AT_LLVM_sysroot
	.byte	37                              ## DW_FORM_strx1
	.byte	114                             ## DW_AT_str_offsets_base
	.byte	23                              ## DW_FORM_sec_offset
	.byte	16                              ## DW_AT_stmt_list
	.byte	23                              ## DW_FORM_sec_offset
	.byte	27                              ## DW_AT_comp_dir
	.byte	37                              ## DW_FORM_strx1
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	115                             ## DW_AT_addr_base
	.byte	23                              ## DW_FORM_sec_offset
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	2                               ## Abbreviation Code
	.byte	46                              ## DW_TAG_subprogram
	.byte	1                               ## DW_CHILDREN_yes
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	64                              ## DW_AT_frame_base
	.byte	24                              ## DW_FORM_exprloc
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	63                              ## DW_AT_external
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	3                               ## Abbreviation Code
	.byte	52                              ## DW_TAG_variable
	.byte	0                               ## DW_CHILDREN_no
	.byte	2                               ## DW_AT_location
	.byte	24                              ## DW_FORM_exprloc
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	58                              ## DW_AT_decl_file
	.byte	11                              ## DW_FORM_data1
	.byte	59                              ## DW_AT_decl_line
	.byte	11                              ## DW_FORM_data1
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	4                               ## Abbreviation Code
	.byte	11                              ## DW_TAG_lexical_block
	.byte	1                               ## DW_CHILDREN_yes
	.byte	17                              ## DW_AT_low_pc
	.byte	27                              ## DW_FORM_addrx
	.byte	18                              ## DW_AT_high_pc
	.byte	6                               ## DW_FORM_data4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	5                               ## Abbreviation Code
	.byte	36                              ## DW_TAG_base_type
	.byte	0                               ## DW_CHILDREN_no
	.byte	3                               ## DW_AT_name
	.byte	37                              ## DW_FORM_strx1
	.byte	62                              ## DW_AT_encoding
	.byte	11                              ## DW_FORM_data1
	.byte	11                              ## DW_AT_byte_size
	.byte	11                              ## DW_FORM_data1
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	6                               ## Abbreviation Code
	.byte	15                              ## DW_TAG_pointer_type
	.byte	0                               ## DW_CHILDREN_no
	.byte	73                              ## DW_AT_type
	.byte	19                              ## DW_FORM_ref4
	.byte	0                               ## EOM(1)
	.byte	0                               ## EOM(2)
	.byte	0                               ## EOM(3)
	.section	__DWARF,__debug_info,regular,debug
Lsection_info:
Lcu_begin0:
.set Lset0, Ldebug_info_end0-Ldebug_info_start0 ## Length of Unit
	.long	Lset0
Ldebug_info_start0:
	.short	5                               ## DWARF version number
	.byte	1                               ## DWARF Unit Type
	.byte	8                               ## Address Size (in bytes)
.set Lset1, Lsection_abbrev-Lsection_abbrev ## Offset Into Abbrev. Section
	.long	Lset1
	.byte	1                               ## Abbrev [1] 0xc:0x77 DW_TAG_compile_unit
	.byte	0                               ## DW_AT_producer
	.short	26                              ## DW_AT_language
	.byte	1                               ## DW_AT_name
	.byte	2                               ## DW_AT_LLVM_sysroot
.set Lset2, Lstr_offsets_base0-Lsection_str_off ## DW_AT_str_offsets_base
	.long	Lset2
.set Lset3, Lline_table_start0-Lsection_line ## DW_AT_stmt_list
	.long	Lset3
	.byte	3                               ## DW_AT_comp_dir
	.byte	0                               ## DW_AT_low_pc
.set Lset4, Lfunc_end0-Lfunc_begin0     ## DW_AT_high_pc
	.long	Lset4
.set Lset5, Laddr_table_base0-Lsection_info0 ## DW_AT_addr_base
	.long	Lset5
	.byte	2                               ## Abbrev [2] 0x24:0x55 DW_TAG_subprogram
	.byte	0                               ## DW_AT_low_pc
.set Lset6, Lfunc_end0-Lfunc_begin0     ## DW_AT_high_pc
	.long	Lset6
	.byte	1                               ## DW_AT_frame_base
	.byte	86
	.byte	4                               ## DW_AT_name
	.byte	1                               ## DW_AT_decl_file
	.byte	1                               ## DW_AT_decl_line
	.long	121                             ## DW_AT_type
                                        ## DW_AT_external
	.byte	3                               ## Abbrev [3] 0x33:0xb DW_TAG_variable
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	120
	.byte	6                               ## DW_AT_name
	.byte	1                               ## DW_AT_decl_file
	.byte	2                               ## DW_AT_decl_line
	.long	121                             ## DW_AT_type
	.byte	3                               ## Abbrev [3] 0x3e:0xb DW_TAG_variable
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	112
	.byte	7                               ## DW_AT_name
	.byte	1                               ## DW_AT_decl_file
	.byte	3                               ## DW_AT_decl_line
	.long	125                             ## DW_AT_type
	.byte	3                               ## Abbrev [3] 0x49:0xb DW_TAG_variable
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	104
	.byte	9                               ## DW_AT_name
	.byte	1                               ## DW_AT_decl_file
	.byte	10                              ## DW_AT_decl_line
	.long	121                             ## DW_AT_type
	.byte	4                               ## Abbrev [4] 0x54:0x12 DW_TAG_lexical_block
	.byte	1                               ## DW_AT_low_pc
.set Lset7, Ltmp6-Ltmp1                 ## DW_AT_high_pc
	.long	Lset7
	.byte	3                               ## Abbrev [3] 0x5a:0xb DW_TAG_variable
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	108
	.byte	8                               ## DW_AT_name
	.byte	1                               ## DW_AT_decl_file
	.byte	6                               ## DW_AT_decl_line
	.long	121                             ## DW_AT_type
	.byte	0                               ## End Of Children Mark
	.byte	4                               ## Abbrev [4] 0x66:0x12 DW_TAG_lexical_block
	.byte	2                               ## DW_AT_low_pc
.set Lset8, Ltmp12-Ltmp7                ## DW_AT_high_pc
	.long	Lset8
	.byte	3                               ## Abbrev [3] 0x6c:0xb DW_TAG_variable
	.byte	2                               ## DW_AT_location
	.byte	145
	.byte	100
	.byte	8                               ## DW_AT_name
	.byte	1                               ## DW_AT_decl_file
	.byte	11                              ## DW_AT_decl_line
	.long	121                             ## DW_AT_type
	.byte	0                               ## End Of Children Mark
	.byte	0                               ## End Of Children Mark
	.byte	5                               ## Abbrev [5] 0x79:0x4 DW_TAG_base_type
	.byte	5                               ## DW_AT_name
	.byte	5                               ## DW_AT_encoding
	.byte	4                               ## DW_AT_byte_size
	.byte	6                               ## Abbrev [6] 0x7d:0x5 DW_TAG_pointer_type
	.long	121                             ## DW_AT_type
	.byte	0                               ## End Of Children Mark
Ldebug_info_end0:
	.section	__DWARF,__debug_str_offs,regular,debug
Lsection_str_off:
	.long	44                              ## Length of String Offsets Set
	.short	5
	.short	0
Lstr_offsets_base0:
	.section	__DWARF,__debug_str,regular,debug
Linfo_string:
	.asciz	"Apple clang version 17.0.0 (clang-1700.3.19.1)" ## string offset=0
	.asciz	"simple_main.cpp"               ## string offset=47
	.asciz	"/"                             ## string offset=63
	.asciz	"/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-simd_vectorization/cmake-build-debug" ## string offset=65
	.asciz	"main"                          ## string offset=198
	.asciz	"int"                           ## string offset=203
	.asciz	"n"                             ## string offset=207
	.asciz	"a"                             ## string offset=209
	.asciz	"i"                             ## string offset=211
	.asciz	"sum"                           ## string offset=213
	.section	__DWARF,__debug_str_offs,regular,debug
	.long	0
	.long	47
	.long	63
	.long	65
	.long	198
	.long	203
	.long	207
	.long	209
	.long	211
	.long	213
	.section	__DWARF,__debug_addr,regular,debug
Lsection_info0:
.set Lset9, Ldebug_addr_end0-Ldebug_addr_start0 ## Length of contribution
	.long	Lset9
Ldebug_addr_start0:
	.short	5                               ## DWARF version number
	.byte	8                               ## Address size
	.byte	0                               ## Segment selector size
Laddr_table_base0:
	.quad	Lfunc_begin0
	.quad	Ltmp1
	.quad	Ltmp7
Ldebug_addr_end0:
	.section	__DWARF,__debug_names,regular,debug
Ldebug_names_begin:
.set Lset10, Lnames_end0-Lnames_start0  ## Header: unit length
	.long	Lset10
Lnames_start0:
	.short	5                               ## Header: version
	.short	0                               ## Header: padding
	.long	1                               ## Header: compilation unit count
	.long	0                               ## Header: local type unit count
	.long	0                               ## Header: foreign type unit count
	.long	2                               ## Header: bucket count
	.long	2                               ## Header: name count
.set Lset11, Lnames_abbrev_end0-Lnames_abbrev_start0 ## Header: abbreviation table size
	.long	Lset11
	.long	8                               ## Header: augmentation string size
	.ascii	"LLVM0700"                      ## Header: augmentation string
.set Lset12, Lcu_begin0-Lsection_info   ## Compilation unit 0
	.long	Lset12
	.long	1                               ## Bucket 0
	.long	0                               ## Bucket 1
	.long	193495088                       ## Hash in Bucket 0
	.long	2090499946                      ## Hash in Bucket 0
	.long	203                             ## String in Bucket 0: int
	.long	198                             ## String in Bucket 0: main
.set Lset13, Lnames1-Lnames_entries0    ## Offset in Bucket 0
	.long	Lset13
.set Lset14, Lnames0-Lnames_entries0    ## Offset in Bucket 0
	.long	Lset14
Lnames_abbrev_start0:
	.byte	1                               ## Abbrev code
	.byte	36                              ## DW_TAG_base_type
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	2                               ## Abbrev code
	.byte	46                              ## DW_TAG_subprogram
	.byte	3                               ## DW_IDX_die_offset
	.byte	19                              ## DW_FORM_ref4
	.byte	4                               ## DW_IDX_parent
	.byte	25                              ## DW_FORM_flag_present
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev
	.byte	0                               ## End of abbrev list
Lnames_abbrev_end0:
Lnames_entries0:
Lnames1:
L1:
	.byte	1                               ## Abbreviation code
	.long	121                             ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: int
Lnames0:
L0:
	.byte	2                               ## Abbreviation code
	.long	36                              ## DW_IDX_die_offset
	.byte	0                               ## DW_IDX_parent
                                        ## End of list: main
	.p2align	2, 0x0
Lnames_end0:
.subsections_via_symbols
	.section	__DWARF,__debug_line,regular,debug
Lsection_line:
Lline_table_start0:
