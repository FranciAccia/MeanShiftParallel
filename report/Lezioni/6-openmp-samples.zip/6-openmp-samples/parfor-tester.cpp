#include <omp.h> // for OpenMP library functions
#include <iostream>

using namespace std;

int main() {
#ifdef _OPENMP
    std::cout << "_OPENMP defined" << std::endl;
#endif

    int tid;
    int a[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

#pragma omp parallel for private(tid)
    for (int i = 0; i < 10; i++) {
        int nthreads = omp_get_num_threads();
        tid = omp_get_thread_num();
        printf("Loop thread = %d/%d - i = %d - a[i] = %d\n", tid, nthreads, i, a[i]);
    }

#pragma omp parallel for private(tid)
    for (int j = 0; j < 10; j++) {
        a[j] += 10;
        int nthreads = omp_get_num_threads();
        tid = omp_get_thread_num();
        printf("Loop thread test 2 = %d/%d - j = %d - a[j] = %d\n", tid, nthreads, j, a[j]);
    }

#pragma omp parallel for private(tid)
    for (int j = 1; j < 10; j++) {
        a[j] = a[j-1]; // ERROR ! - this loop must be executed only in sequential order
        int nthreads = omp_get_num_threads();
        tid = omp_get_thread_num();
        printf("Wrong loop thread = %d/%d - j = %d - a[j] = %d\n", tid, nthreads, j, a[j]);
    }

    //
    // test collapsed for
    //
    int result = 0;

    // Define the loop bounds
    const int n = 1000;

    // Without collapse: Iterating over 2 nested loops
#pragma omp parallel for reduction(+:result)
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            result += 1; // Some computation, no race condition thanks to the reduction clause
        }
    }
    printf("Result without collapse: %d\n", result);

    // With collapse: Collapse both loops into a single loop
    // This allows OpenMP to divide the combined work between
    // threads more evenly, potentially improving load balancing
    // and parallel efficiency.
    // The parallelization becomes more efficient as the number
    // of iterations increases, reducing the overhead associated
    // with thread management.
    result = 0;  // Reset result

#pragma omp parallel for collapse(2) reduction(+:result)
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            result += 1; // Some computation, no race condition thanks to the reduction clause
        }
    }

    printf("Result with collapse: %d\n", result);
    return 0;
}