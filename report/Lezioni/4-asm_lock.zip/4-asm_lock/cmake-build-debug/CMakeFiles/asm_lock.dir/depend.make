# Empty dependencies file for asm_lock.
# This may be replaced when dependencies are built.
