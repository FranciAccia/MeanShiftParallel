file(REMOVE_RECURSE
  "4b_profiling"
  "4b_profiling.pdb"
  "CMakeFiles/4b_profiling.dir/main.cpp.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/4b_profiling.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
