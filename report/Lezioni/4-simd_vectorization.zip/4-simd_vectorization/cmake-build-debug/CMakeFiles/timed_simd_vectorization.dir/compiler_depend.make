# Empty compiler generated dependencies file for timed_simd_vectorization.
# This may be replaced when dependencies are built.
