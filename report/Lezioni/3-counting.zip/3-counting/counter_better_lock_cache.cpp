#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
#include <sys/time.h>

#include "params.h"
#define CACHE_LINE_SIZE 64

struct padded_int {
    int value;
    char padding[CACHE_LINE_SIZE - sizeof(int)];
} private_counter[NUM_THREADS];
int counter = 0;
int buffer[BUFFER_SIZE];
pthread_mutex_t lock;

void prepareBuffer() {
    for (long i = 0; i < BUFFER_SIZE; ++i) {
        buffer[i] = i % 10;
    }
}

void* countEven(void* data) {
    int* thread_id = (int*) data;
    int length_per_thread = BUFFER_SIZE / NUM_THREADS;
    int start = *thread_id * length_per_thread;
    for (int i = start; i < start + length_per_thread; i++) {
        if (buffer[i] % 2) {
            private_counter[*thread_id].value++;
            buffer[i] += 2;
        } else {
            buffer[i] *= 2;
        }
    }
    return NULL;
}

void* count3orig(void* data) {
    int* thread_id = (int*) data;
    int length_per_thread = BUFFER_SIZE / NUM_THREADS;
    int start = *thread_id * length_per_thread;
    for (int i = start; i < start + length_per_thread; i++) {
        if (buffer[i] == 3) {
            private_counter[*thread_id].value++;
        }
    }
    return NULL;
}

int main() {
    prepareBuffer();
    pthread_t thread_ids[NUM_THREADS];
    int id[NUM_THREADS];
    pthread_mutex_init(&lock, NULL);

    timeval t1, t2;
    gettimeofday(&t1, NULL);
    for (int times=0; times < REPETITIONS; times++) {
        for (int i = 0; i < NUM_THREADS; i++) {
            id[i] = i;
            private_counter[i].value = 0;
            pthread_create(&thread_ids[i], NULL, count3orig, (void*) (id + i));
        }
        for (int i = 0; i < NUM_THREADS; i++) {
            pthread_join(thread_ids[i], NULL);
            counter += private_counter[i].value;
        }
    }
    gettimeofday(&t2, NULL);
    double elapsedTimeMs = (t2.tv_sec - t1.tv_sec) * 1000.0;      // sec to ms
    elapsedTimeMs += (t2.tv_usec - t1.tv_usec) / 1000.0;   // us to ms
    printf("Time taken: %f milliseconds\n", elapsedTimeMs);
    printf("3 Counter: %d\n", counter);

    gettimeofday(&t1, NULL);
    for (int times=0; times < REPETITIONS; times++) {
        for (int i = 0; i < NUM_THREADS; i++) {
            id[i] = i;
            private_counter[i].value = 0;
            pthread_create(&thread_ids[i], NULL, countEven, (void*) (id + i));
        }
        for (int i = 0; i < NUM_THREADS; i++) {
            pthread_join(thread_ids[i], NULL);
            counter += private_counter[i].value;
        }
    }
    gettimeofday(&t2, NULL);
    elapsedTimeMs = (t2.tv_sec - t1.tv_sec) * 1000.0;      // sec to ms
    elapsedTimeMs += (t2.tv_usec - t1.tv_usec) / 1000.0;   // us to ms
    printf("Time taken: %f milliseconds\n", elapsedTimeMs);
    printf("Even Counter: %d\n", counter);
}