file(REMOVE_RECURSE
  "CMakeFiles/first-last-tester.dir/first-last-private.cpp.o"
  "CMakeFiles/first-last-tester.dir/first-last-private.cpp.o.d"
  "first-last-tester"
  "first-last-tester.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/first-last-tester.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
