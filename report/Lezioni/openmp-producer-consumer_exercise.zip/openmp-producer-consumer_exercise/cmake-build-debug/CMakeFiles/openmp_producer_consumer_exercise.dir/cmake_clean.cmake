file(REMOVE_RECURSE
  "CMakeFiles/openmp_producer_consumer_exercise.dir/main.cpp.o"
  "CMakeFiles/openmp_producer_consumer_exercise.dir/utilities.cpp.o"
  "openmp_producer_consumer_exercise"
  "openmp_producer_consumer_exercise.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/openmp_producer_consumer_exercise.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
