file(REMOVE_RECURSE
  "CMakeFiles/omp_msg.dir/omp_msg.cpp.o"
  "CMakeFiles/omp_msg.dir/queue.cpp.o"
  "omp_msg"
  "omp_msg.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/omp_msg.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
