#include <cstdio>
#include "omp.h"

int main() {
#pragma omp parallel default(none)
    {
#pragma omp single
        {
            printf("A ");
#pragma omp task
            { printf("race "); }
#pragma omp task
            { printf("car "); }
#pragma omp taskwait
            printf("is fun to watch.");
        }
    } // End of parallel region
    printf("\n");



#pragma omp parallel default(none)
    {
#pragma omp single
        {
            printf("A ");
#pragma omp task
            { printf("race "); }
#pragma omp task
            { printf("boat "); }
// what happens without taskwait ?? the single thread will execute the following, independently from the tasks...
            printf("is fun to watch.");
        }
    } // End of parallel region
    printf("\n");




#pragma omp parallel default(none)
    {
#pragma omp master  // try using master. check your OpenMP to see if you can use masked
        {
            printf("thread #%d \t", omp_get_thread_num());
#pragma omp task default(none)
            { printf("task 1 - thread #%d \t", omp_get_thread_num()); }
#pragma omp task default(none)
            { printf("task 2 - thread #%d \t", omp_get_thread_num()); }
// what happens without taskwait ?? the single thread will execute the following, independently from the tasks...
#pragma omp taskwait
            printf("thread #%d\n", omp_get_thread_num());
        }
    } // End of parallel region
    printf("\n");

    return 0;
}