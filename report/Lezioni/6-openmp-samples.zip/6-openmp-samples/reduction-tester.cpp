#include <stdio.h>

int main(int argc, char* argv[]) {
    float a[100], b[100];
    for (int i = 0; i < 100; i++)
        a[i] = b[i] = i * 1.0;
    float sum = 0.0;

#pragma omp parallel for reduction(+:sum)
    for (int i = 0; i < 8; i++) {
        sum += (a[i] * b[i]);
        printf("thread sum = %f\n", sum);
    }

    printf("sum = %f\n", sum);
}