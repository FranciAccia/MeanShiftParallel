file(REMOVE_RECURSE
  "CMakeFiles/flush-tester.dir/flush-tester.cpp.o"
  "CMakeFiles/flush-tester.dir/flush-tester.cpp.o.d"
  "flush-tester"
  "flush-tester.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/flush-tester.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
