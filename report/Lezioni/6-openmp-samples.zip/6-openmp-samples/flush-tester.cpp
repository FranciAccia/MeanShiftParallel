#include <omp.h>
#include <cstdio>
#include <unistd.h>

// The example shows how to implement a reliable producer-consumer
// pattern where:
//
// - A producer thread (thread 0) creates data and signals it's ready
// - A consumer thread (thread 1) waits for the signal, then reads the data
void example_flush_producer_consumer() {
    printf("\n=== Example: Flush - Producer/Consumer ===\n");
    int data = 0;
    int flag = 0;

#pragma omp parallel num_threads(2) shared(data, flag)
    {
        int tid = omp_get_thread_num();

        if (tid == 0) {
            // Producer
            printf("Producer: preparing data...\n");
            // Producer side:
            data = 42;                    // 1. Write data
#pragma omp flush(data)       // 2. Ensure data is written to memory
            flag = 1;                     // 3. Set flag
#pragma omp flush(flag)       // 4. Ensure flag is written to memory
            printf("Producer: data published (data=%d, flag=%d)\n", data, flag);
        } else {
            // Consumer
            int local_flag = 0;
            // Consumer side:
            do {
#pragma omp flush(flag)   // 5. Read fresh flag value from memory
                local_flag = flag;
            } while (!local_flag);
#pragma omp flush(data)       // 6. Read fresh data value from memory
            printf("Consumer: received data=%d\n", data);
        }
    }
}

// The example shows 4 threads that:
//
// - Each compute their own value (values[tid])
// - Signal they're ready using a flag (ready[tid])
// - Wait for all other threads to be ready
// - Only then read and sum all values safely
void example_flush_flags() {
    printf("\n=== Example: Flush - Flag Synchronization ===\n");
    int ready[4] = {0, 0, 0, 0};
    int values[4] = {0, 0, 0, 0};

#pragma omp parallel num_threads(4) shared(ready, values)
    {
        int tid = omp_get_thread_num();

        // Phase 1: Publish my result
        // Each thread computes a value
        values[tid] = (tid + 1) * 100;
        printf("Thread %d: computed value %d\n", tid, values[tid]);

#pragma omp flush(values)  // Ensure my value is in shared memory
        ready[tid] = 1;    // Set my ready flag
#pragma omp flush(ready)   // Ensure my flag is visible to others

        // Phase 2: Wait for all others
        // Wait for all threads to be ready
        for (int i = 0; i < 4; i++) {
            if (i != tid) {         // Don't wait for myself
                int is_ready = 0;   // Read fresh ready flag
                while (!is_ready) {
#pragma omp flush(ready)
                    is_ready = ready[i];
                }
            }
        }

        // Phase 3: Safely read all values
#pragma omp flush(values)  // Read fresh values
        // Now safely read all values
        int sum = 0;
        for (int i = 0; i < 4; i++) {
            sum += values[i];  // Now safe to read everyone's results
        }
        printf("Thread %d: sum of all values = %d\n", tid, sum);
    }
}

// The example shows a simple scenario where one thread updates
// three variables (x, y, z) and another thread needs to read
// all three.
// Using #pragma omp flush without a list ensures all variables
// are synchronized together in one atomic operation.
void example_flush_all() {
    printf("\n=== Example: Flush Without Arguments ===\n");
    int x = 0, y = 0, z = 0;

#pragma omp parallel num_threads(2) shared(x, y, z)
    {
        int tid = omp_get_thread_num();

        if (tid == 0) {
            x = 1;
            y = 2;
            z = 3;
#pragma omp flush  // Flushes ALL shared variables
            printf("Thread 0: set x=%d, y=%d, z=%d\n", x, y, z);
        } else {
            usleep(10000);
#pragma omp flush  // Read fresh values
            printf("Thread 1: sees x=%d, y=%d, z=%d\n", x, y, z);
        }
    }
}

int main() {
    printf("Number of processors: %d\n", omp_get_num_procs());
    printf("Max threads: %d\n", omp_get_max_threads());

    example_flush_producer_consumer();
    example_flush_flags();
    example_flush_all();
}