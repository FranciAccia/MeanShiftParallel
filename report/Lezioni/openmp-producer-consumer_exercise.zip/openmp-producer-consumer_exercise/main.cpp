#include <omp.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>

#include "utilities.h"
#include "ConcurrentQueue.h"

using namespace std;


void producer(int tid, ConcurrentQueue<std::string> &sharedQueue) {
    std::string filename = (searchFiles()).front();
    printf("Producer %d: working on file: %s\n", tid, filename.c_str());
    std::ifstream infile(filename);
    std::string line;

    while (std::getline(infile, line)) {
        sharedQueue.enqueue(line);
    }
    printf("Producer %d: closing...\n", tid);
    sharedQueue.producerEnd();
    printf("Producer %d: ends.\n", tid);
}

void consumer(int tid, ConcurrentQueue<std::string> &sharedQueue) {
    std::string line;
    while (!sharedQueue.isDone()) {
        if (sharedQueue.dequeue(line)) {
            printf("Consumer %d: working\n", tid);
            printf("Consumer %d: working on: %s\n", tid, line.c_str());
            for_each(line.begin(), line.end(), convertUpperLower());
            printf("Consumer %d: transformed to: %s\n", tid, line.c_str());
        }
    }
}


int main() {
    ConcurrentQueue<std::string> sharedQueue2(1);

    int tid;
    double start = omp_get_wtime();
#pragma omp parallel default(none) shared(sharedQueue2) private(tid)
    {
        tid = omp_get_thread_num();


    }
    double end = omp_get_wtime( );
    std::cout << "XXX solution completed. Time: " << end-start << std::endl << std::endl;


    return 0;
}