file(REMOVE_RECURSE
  "CMakeFiles/asm_lock.dir/main.cpp.o"
  "CMakeFiles/asm_lock.dir/main.cpp.o.d"
  "asm_lock"
  "asm_lock.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/asm_lock.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
