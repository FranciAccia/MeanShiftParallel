file(REMOVE_RECURSE
  "CMakeFiles/task-tester.dir/task-tester.cpp.o"
  "CMakeFiles/task-tester.dir/task-tester.cpp.o.d"
  "task-tester"
  "task-tester.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/task-tester.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
