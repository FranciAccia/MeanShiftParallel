#include "Timer.h"
#include <x86intrin.h>
#include <iostream>

// XXX test this code in Debug mode

const int n = 4;
const auto repetitions = static_cast<long long>(10e3);

void basic_mul(const float (&vec)[n], const float (&mat)[n][n], float (&result)[n]) {
    for (int row = 0; row < 4; row++) {
        float sum = 0.0;
        for (int col = 0; col < n; col++) {
            float m = mat[row][col];
            float v = vec[col];
            sum += m * v;
        }
        result[row] = sum;
    }
}

void loop_unrolling_mul(const float (&vec)[n], const float (&mat)[n][n], float (&result)[n]) {
    for (int row = 0; row < 4; row++) {
        float sum = 0.0, m, v;
        m = mat[row][0];
        v = vec[0];
        sum += m * v;
        m = mat[row][1];
        v = vec[1];
        sum += m * v;
        m = mat[row][2];
        v = vec[2];
        sum += m * v;
        m = mat[row][3];
        v = vec[3];
        sum += m * v;
        result[row] = sum;
    }
}

void basic_sse_mul(const __m128 &sse_vec, const __m128 (&sse_mat)[n], float (&result)[n]) {
    for (int row = 0; row < n; row++) {
        __m128 mrow = sse_mat[row];
        __m128 v = sse_vec;
        __m128 sum = mrow * v;
        sum = _mm_hadd_ps(sum, sum); /* adds adjacent-two floats */
        _mm_store_ss(&result[row], _mm_hadd_ps(sum, sum)); /* adds those floats */
    }
}

void column_mat_sse(const float (&vec)[n], const __m128 (&sse_mat)[n], __m128 &result) {
    float z = 0.0;
    __m128 sum = _mm_load1_ps(&z);
    for (int col = 0; col < n; col++) {
        __m128 mcol = sse_mat[col];
        float v = vec[col];
        sum += mcol * _mm_load1_ps(&v);
    }
    result = sum;
}

void print_vector(const float (&vec)[n]) {
    std::cout << "Vector: ";
    for (int i = 0; i < n; i++)
        std::cout << vec[i] << " ";
    std::cout << std::endl;
}

void print_vector(const __m128 &vec) {
    std::cout << "SSE Vector: ";
    for (int i = 0; i < n; i++)
        std::cout << vec[i] << " ";
    std::cout << std::endl;
}

int main() {
    float vec[n] = {1, 2, 3, 4};
    float mat[n][n]{1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4};

    Timer timer;
    float result[n] = {0, 0, 0, 0};
    timer.start();
    for (long long i = 0; i < repetitions; i++)
        for (long long j = 0; j < repetitions; j++)
            basic_mul(vec, mat, result);
    timer.stop();
    std::cout << "time basic_mul: " << timer.getElapsedTimeInMicroSec() << " us \n";
    print_vector(result);
    float unrolling_result[n] = {0, 0, 0, 0};
    timer.start();
    for (long long i = 0; i < repetitions; i++)
        for (long long j = 0; j < repetitions; j++)
            loop_unrolling_mul(vec, mat, unrolling_result);
    timer.stop();
    std::cout << "time loop_unrolling_mul: " << timer.getElapsedTimeInMicroSec() << " us \n";
    print_vector(result);

    __m128 sse_mat[n] = {1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4}; /* rows */
    __m128 sse_vec = {1, 2, 3, 4};
    float basic_sse_result[n] = {0, 0, 0, 0};
    timer.start();
    for (long long i = 0; i < repetitions; i++)
        for (long long j = 0; j < repetitions; j++)
            basic_sse_mul(sse_vec, sse_mat, basic_sse_result);
    timer.stop();
    std::cout << "time basic_sse_mul: " << timer.getElapsedTimeInMicroSec() << " us \n";
    print_vector(result);

    __m128 sse_result;
    __m128 sse_mat_t[n] = {1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4}; /* columns */
    timer.start();
    for (long long i = 0; i < repetitions; i++)
        for (long long j = 0; j < repetitions; j++)
            column_mat_sse(vec, sse_mat_t, sse_result);
    timer.stop();
    std::cout << "time column_mat_sse: " << timer.getElapsedTimeInMicroSec() << " us \n";
    print_vector(sse_result);

    return 0;
}