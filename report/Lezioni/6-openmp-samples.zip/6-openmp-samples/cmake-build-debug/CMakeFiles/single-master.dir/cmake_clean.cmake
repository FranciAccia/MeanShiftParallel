file(REMOVE_RECURSE
  "CMakeFiles/single-master.dir/single-master.cpp.o"
  "CMakeFiles/single-master.dir/single-master.cpp.o.d"
  "single-master"
  "single-master.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/single-master.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
