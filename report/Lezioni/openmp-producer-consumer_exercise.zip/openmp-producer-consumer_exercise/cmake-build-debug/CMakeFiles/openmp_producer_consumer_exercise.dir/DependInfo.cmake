
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2021-2022/lab_exercises/Exercise2_OpenMP_producers_consumers/openmp-producer-consumer_exercise/main.cpp" "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2021-2022/lab_exercises/Exercise2_OpenMP_producers_consumers/openmp-producer-consumer_exercise/cmake-build-debug/CMakeFiles/openmp_producer_consumer_exercise.dir/main.cpp.o"
  "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2021-2022/lab_exercises/Exercise2_OpenMP_producers_consumers/openmp-producer-consumer_exercise/utilities.cpp" "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2021-2022/lab_exercises/Exercise2_OpenMP_producers_consumers/openmp-producer-consumer_exercise/cmake-build-debug/CMakeFiles/openmp_producer_consumer_exercise.dir/utilities.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "AppleClang")

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "/usr/local/include"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
