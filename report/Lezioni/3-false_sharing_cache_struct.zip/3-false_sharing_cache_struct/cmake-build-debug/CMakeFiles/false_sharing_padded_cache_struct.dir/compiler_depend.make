# Empty compiler generated dependencies file for false_sharing_padded_cache_struct.
# This may be replaced when dependencies are built.
