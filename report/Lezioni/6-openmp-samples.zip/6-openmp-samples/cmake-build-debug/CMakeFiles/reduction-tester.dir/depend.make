# Empty dependencies file for reduction-tester.
# This may be replaced when dependencies are built.
