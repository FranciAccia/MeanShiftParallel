# Empty dependencies file for simd_vectorization.
# This may be replaced when dependencies are built.
