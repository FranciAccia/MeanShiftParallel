#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 8192
double A[N][N];

int main() {
    clock_t start, end;
    double sum = 0;

    // Row-major (fast)
    start = clock();
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            sum += A[i][j];
    end = clock();
    printf("Row-major: %.3f sec\n", (double)(end-start)/CLOCKS_PER_SEC);

    // Column-major (slow)
    sum = 0;
    start = clock();
    for (int j = 0; j < N; j++)
        for (int i = 0; i < N; i++)
            sum += A[i][j];
    end = clock();
    printf("Column-major: %.3f sec\n", (double)(end-start)/CLOCKS_PER_SEC);
}
