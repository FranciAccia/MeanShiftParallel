//
// Created by Marco Bertini on 03/11/17.
//

#ifndef OPENMP_PRODUCER_CONSUMER_CPP_UTILITIES_H_H
#define OPENMP_PRODUCER_CONSUMER_CPP_UTILITIES_H_H

#include <string>
#include <list>

std::list<std::string> searchFiles(std::string directory="./", std::string extension="txt");

struct convertUpperLower {
    void operator()(char& c) {
        std::locale loc;
        if (std::islower(c, loc))
            c = std::toupper(c, loc);
        else
            c = std::tolower(c, loc);
    }
};

#endif //OPENMP_PRODUCER_CONSUMER_CPP_UTILITIES_H_H
