file(REMOVE_RECURSE
  "CMakeFiles/simd_vectorization.dir/simple_main.cpp.o"
  "CMakeFiles/simd_vectorization.dir/simple_main.cpp.o.d"
  "simd_vectorization"
  "simd_vectorization.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/simd_vectorization.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
