#include <iostream>
#include <cmath>

// Google Perftools:
// Test (after adapting DYLD_INSERT_LIBRARIES/LD_PRELOAD) using:
// DYLD_INSERT_LIBRARIES=/opt/local/lib/libprofiler.dylib CPUPROFILE=/tmp/prof.out CPUPROFILE_FREQUENCY=100 ./7c_profiling
// or:
// DYLD_INSERT_LIBRARIES=/usr/local/lib/libprofiler.dylib CPUPROFILE=/tmp/prof.out CPUPROFILE_FREQUENCY=100 ./7c_profiling
// Analyze results using:
// pprof --text --lines ./7c_profiling /tmp/prof.out

// Valgrind/Callgrind:
// Test using:
// valgrind --tool=callgrind ./7v_profiling
// Analyze results using:
// callgrind_annotate --auto=yes callgrind.out.<pid>

int doSomethingFast(int i) {
    int result = 0;
    for (int k=0; k<10000; k++)
        result += sin(i)+cos(k); // without sin() it may be too fast even with increased profiler sampling rate

    return result;
}

int doSomethingSlow(int i) {
    int result = doSomethingFast(i);
//#pragma omp parallel for reduction(+:result)
    for (int j=0; j<10000; j++) {
        for (int k = 0; k<10000; k++) {
            result++;
        }
    }
    result += doSomethingFast(i);
    return result;
}

int main() {
    int result = doSomethingFast(42);
    result += doSomethingSlow(42);
    result += doSomethingSlow(42);
    std::cout << result << std::endl;
    return 0;
}