//
// Created by Marco Bertini on 03/11/17.
//
#include <dirent.h>
#include <list>
#include <iostream>
#include <string>
#include <locale>

std::list<std::string> searchFiles(std::string directory, std::string extension) {
    DIR* dir;
    struct dirent* ent;
    std::list<std::string> result;
    if ((dir = opendir(directory.c_str())) != NULL) {
        /* print all the files and directories within directory */
        while ((ent = readdir(dir)) != NULL) {
            std::string mystr(ent->d_name);
            printf("File found: %s\n", mystr.substr(mystr.find_last_of(".") + 1).c_str());
            if (mystr.substr(mystr.find_last_of(".") + 1).compare(extension) == 0) {
                result.push_back(mystr);
            }
        }
        closedir(dir);
    } else {
/* could not open directory */
        std::cerr << "can not open directory: " << directory << std::endl;
        exit(EXIT_FAILURE);
    }
    return result;
}