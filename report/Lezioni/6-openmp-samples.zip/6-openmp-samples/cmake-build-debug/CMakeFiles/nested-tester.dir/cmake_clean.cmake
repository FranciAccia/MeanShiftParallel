file(REMOVE_RECURSE
  "CMakeFiles/nested-tester.dir/nested-tester.cpp.o"
  "CMakeFiles/nested-tester.dir/nested-tester.cpp.o.d"
  "nested-tester"
  "nested-tester.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/nested-tester.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
