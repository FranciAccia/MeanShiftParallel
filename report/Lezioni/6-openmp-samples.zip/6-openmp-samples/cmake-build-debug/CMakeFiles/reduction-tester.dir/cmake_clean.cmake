file(REMOVE_RECURSE
  "CMakeFiles/reduction-tester.dir/reduction-tester.cpp.o"
  "CMakeFiles/reduction-tester.dir/reduction-tester.cpp.o.d"
  "reduction-tester"
  "reduction-tester.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/reduction-tester.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
