/*
 * SIMD VECTORIZATION DEMONSTRATION
 * Compile: g++ -O3 -march=native -o simd_demo simd_demo.cpp
 * Shows automatic vectorization by compiler
 */

#include <iostream>
#include <vector>
#include <chrono>
#include <immintrin.h>

const int SIZE = 900000000; // 900 million floats ~3.6GB

// Scalar version - no SIMD
void add_scalar(const float* a, const float* b, float* c, int n) {
    for (int i = 0; i < n; i++) {
        c[i] = a[i] + b[i];
    }
    if (c[n-1] == 0) std::cout << ""; // Prevent optimization
}

// Compiler auto-vectorized version (with proper flags)
void add_auto_vectorized(const float* __restrict__ a,
                         const float* __restrict__ b,
                         float* __restrict__ c, int n) {
    // The __restrict__ keyword helps compiler optimize better
    for (int i = 0; i < n; i++) {
        c[i] = a[i] + b[i];
    }
    if (c[n-1] == 0) std::cout << ""; // Prevent optimization
}

// Manual SIMD using AVX (256-bit, 8 floats at once)
void add_simd_manual(const float* a, const float* b, float* c, int n) {
    int i = 0;

    // Process 8 floats at a time using AVX
    for (; i <= n - 8; i += 8) {
        __m256 va = _mm256_loadu_ps(&a[i]);
        __m256 vb = _mm256_loadu_ps(&b[i]);
        __m256 vc = _mm256_add_ps(va, vb);
        _mm256_storeu_ps(&c[i], vc);
    }

    // Handle remaining elements
    for (; i < n; i++) {
        c[i] = a[i] + b[i];
    }
    if (c[n-1] == 0) std::cout << ""; // Prevent optimization
}

template<typename Func>
double benchmark(const char* name, Func func,
                 const std::vector<float>& a,
                 const std::vector<float>& b,
                 std::vector<float>& c) {

    auto start = std::chrono::high_resolution_clock::now();

    func(a.data(), b.data(), c.data(), SIZE);

    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);

    double ms = duration.count() / 1000.0;
    std::cout << name << ": " << ms << " ms\n";

    return ms;
}

int main() {
    std::vector<float> a(SIZE);
    std::vector<float> b(SIZE);
    std::vector<float> c(SIZE);

    // Initialize arrays
    for (int i = 0; i < SIZE; i++) {
        a[i] = i * 1.5f;
        b[i] = i * 0.5f;
    }

    std::cout << "SIMD Vector Addition Performance\n";
    std::cout << "Array size: " << SIZE << " floats\n";
    std::cout << "=================================\n\n";

    // Warm up
    add_scalar(a.data(), b.data(), c.data(), SIZE);

    double t_scalar = benchmark("Scalar version        ",
                                add_scalar, a, b, c);

    double t_auto = benchmark("Auto-vectorized       ",
                             add_auto_vectorized, a, b, c);

    double t_manual = benchmark("Manual SIMD (AVX)     ",
                               add_simd_manual, a, b, c);

    std::cout << "\nSpeedups:\n";
    std::cout << "Auto vs Scalar: " << t_scalar / t_auto << "x\n";
    std::cout << "Manual vs Scalar: " << t_scalar / t_manual << "x\n";

    std::cout << "\nWith AVX, 8 floats are processed per instruction!\n";

    return 0;
}

/*
 * EXPECTED RESULTS:
 * Scalar:     ~20-30 ms
 * Auto-vec:   ~5-8 ms   (4-6x speedup)
 * Manual AVX: ~4-7 ms   (similar to auto-vec)
 *
 * Modern compilers do excellent auto-vectorization!
 * Check assembly: g++ -S -O3 -march=native to see vectorized code
 */