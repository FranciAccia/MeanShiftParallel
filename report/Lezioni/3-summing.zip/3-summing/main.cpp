#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include <cstdlib>
#include <sys/time.h>

#ifdef __DEBUG__
#define REPETITIONS 99999l
#else
#define REPETITIONS 999999999l
#endif
#define CACHE_LINE_SIZE 64

#define PAD_TO_CACHELINE(size) \
char __pad[CACHE_LINE_SIZE - ((size) % CACHE_LINE_SIZE)]

/*
* From C99 §6.7.2.1:
*
* Each non-bit-field member of a structure or union object is aligned in an implementation- defined manner appropriate to its type.
*
* I.e., the compiler is free to add padding between structure members.
* The sizeof a structure is at least the sum of the sizes of its members, but is often larger.
* The sizeof of my_struct should be 12 but it may be (and probably will) be 16.
* Account for this in the padding !
*/

typedef struct my_struct {
    int n;
    long long sum;
} my_struct_t;

/*
 * Using size_t for n there's no extra alignment so the padding formula works correctly
 * Using int for n, the compiler adds 4 bytes of padding after n to align sum on 8 bytes and the padding won't work,
 * but alignas will force to align everything to 64, resulting in 128 overall !
 */
typedef struct alignas(CACHE_LINE_SIZE) my_struct_cache {
    size_t n;  // TODO change to int (and update the sizeof in the padding !): what happens to struct size ? And to performance (w.r.t. basic parallel) ?
    long long sum;
    PAD_TO_CACHELINE(sizeof(size_t)+sizeof(long long));
} my_struct_cache_t;

/*
 * Using size_t for n there's no extra alignment so the padding formula works correctly.
 * Using int for n, the compiler adds 4 bytes of padding after n to align sum on 8 bytes and the padding won't work !
 */
typedef struct my_struct_unaligned_cache {
    size_t n;  // TODO change to int (and update the sizeof in the padding !): what happens to struct size ?
    long long sum;
    PAD_TO_CACHELINE(sizeof(size_t)+sizeof(long long));
} my_struct_unaligned_cache_t;

void *sumFrom1(void *sit) {
    my_struct_t *local_sit = (my_struct_t *) sit;
    long int i;
    long int j;
    local_sit->sum = 0;

    // Loops for consuming time
    for (j = 0; j < REPETITIONS; j++) {
        for (i = 0; i <= local_sit->n; i++)
            local_sit->sum ++;
        if (local_sit->sum % 2 != 0)
            local_sit->sum ++;
    }
    return NULL;
}


void *sumFrom1Opt(void *sit) {
    my_struct_t *local_sit = (my_struct_t *) sit;
    long int i;
    long int j;
    long long local_sum = 0;

    // Loops for consuming time
    for (j = 0; j < REPETITIONS; j++) {
        for (i = 0; i <= local_sit->n; i++)
            local_sum ++;
        if (local_sum % 2 != 0)
            local_sum ++;
    }
    local_sit->sum = local_sum;

    return NULL;
}

void *sumFrom1OptCache(void *sit) {
    my_struct_cache_t *local_sit = (my_struct_cache_t *) sit;
    long int i;
    long int j;
    local_sit->sum = 0;
    // Loops for consuming time
    for (j = 0; j < REPETITIONS; j++) {
        for (i = 0; i <= local_sit->n; i++)
            local_sit->sum ++;
        if (local_sit->sum % 2 != 0)
            local_sit->sum ++;
    }

    return NULL;
}

void *sumFrom1OptCacheLocal(void *sit) {
    my_struct_cache_t *local_sit = (my_struct_cache_t *) sit;
    long int i;
    long int j;
    long long local_sum = 0;

    // Loops for consuming time
    for (j = 0; j < REPETITIONS; j++) {
        for (i = 0; i <= local_sit->n; i++)
            local_sum ++;
        if (local_sum % 2 != 0)
            local_sum ++;
    }
    local_sit->sum = local_sum;

    return NULL;
}

int main() {
    my_struct_t si1;
//    char         memHolder[4096];
    my_struct_t si2;
    my_struct_t si3;
    si1.n = 40000;
    si2.n = 40000;
    si3.n = 40000;
    my_struct_cache_t osi1;
    my_struct_cache_t osi2;
    my_struct_cache_t osi3;
    osi1.n = si1.n;
    osi2.n = si2.n;
    osi3.n = si3.n;

    timeval t1, t2;


    printf("sizeof(int): %ld\n", sizeof(int));
    printf("sizeof(long long): %ld\n", sizeof(long long));
    printf("sizeof(size_t): %ld\n", sizeof(size_t));
    printf("\n");
    printf("sizeof(my_struct_t): %ld\n", sizeof(my_struct_t));
    printf("sizeof(my_struct_cache_t): %ld\n", sizeof(my_struct_cache_t));
    printf("sizeof(my_struct_unaligned_cache_t): %ld\n", sizeof(my_struct_unaligned_cache_t));
    printf("padding size: %ld\n", (CACHE_LINE_SIZE - ((sizeof(int)+sizeof(long long)) % CACHE_LINE_SIZE)) );
    printf("Repetitions: %ld\n\n", REPETITIONS);

    {
        printf("Sequential execution\n");
        gettimeofday(&t1, NULL);
        sumFrom1((void *) &si1);
        sumFrom1((void *) &si2);
        sumFrom1((void *) &si3);
        gettimeofday(&t2, NULL);
        // compute and print the elapsed time in millisec
        double elapsedTimeMs = (t2.tv_sec - t1.tv_sec) * 1000.0;      // sec to ms
        elapsedTimeMs += (t2.tv_usec - t1.tv_usec) / 1000.0;   // us to ms
        printf("Time taken: %f milliseconds\n", (elapsedTimeMs));
        printf("sum of 1..%d: %lld\n", si1.n, si1.sum);
        printf("sum of 1..%d: %lld\n", si2.n, si2.sum);
        printf("sum of 1..%d: %lld\n\n", si3.n, si3.sum);
    }
    {
        printf("Parallel execution\n");
        pthread_t thread1;
        pthread_t thread2;
        pthread_t thread3;
        gettimeofday(&t1, NULL);
        int iret1 = pthread_create(&thread1, NULL, sumFrom1, (void *) &si1);
        int iret2 = pthread_create(&thread2, NULL, sumFrom1, (void *) &si2);
        int iret3 = pthread_create(&thread3, NULL, sumFrom1, (void *) &si3);
        pthread_join(thread1, NULL);
        pthread_join(thread2, NULL);
        pthread_join(thread3, NULL);
        gettimeofday(&t2, NULL);
        // compute and print the elapsed time in millisec
        double elapsedTimeMs = (t2.tv_sec - t1.tv_sec) * 1000.0;      // sec to ms
        elapsedTimeMs += (t2.tv_usec - t1.tv_usec) / 1000.0;   // us to ms
        printf("Time taken: %f milliseconds\n", (elapsedTimeMs));
        printf("Thread 1 returns: %d - sum: %lld\n", iret1, si1.sum);
        printf("Thread 2 returns: %d - sum: %lld\n", iret2, si2.sum);
        printf("Thread 3 returns: %d - sum: %lld\n\n", iret3, si3.sum);
    }
    {
        printf("Parallel execution (cache friendly)\n");
        pthread_t thread1;
        pthread_t thread2;
        pthread_t thread3;
        gettimeofday(&t1, NULL);
        int iret1 = pthread_create(&thread1, NULL, sumFrom1OptCache, (void *) &osi1);
        int iret2 = pthread_create(&thread2, NULL, sumFrom1OptCache, (void *) &osi2);
        int iret3 = pthread_create(&thread3, NULL, sumFrom1OptCache, (void *) &osi3);
        pthread_join(thread1, NULL);
        pthread_join(thread2, NULL);
        pthread_join(thread3, NULL);
        gettimeofday(&t2, NULL);
        // compute and print the elapsed time in millisec
        double elapsedTimeMs = (t2.tv_sec - t1.tv_sec) * 1000.0;      // sec to ms
        elapsedTimeMs += (t2.tv_usec - t1.tv_usec) / 1000.0;   // us to ms
        printf("Time taken: %f milliseconds\n", (elapsedTimeMs));
        printf("Thread 1 returns: %d - sum: %lld\n", iret1, osi1.sum);
        printf("Thread 2 returns: %d - sum: %lld\n", iret2, osi2.sum);
        printf("Thread 3 returns: %d - sum: %lld\n\n", iret3, osi3.sum);
    }
    {
        printf("Parallel execution (local variable)\n");
        pthread_t thread1;
        pthread_t thread2;
        pthread_t thread3;
        gettimeofday(&t1, NULL);
        int iret1 = pthread_create(&thread1, NULL, sumFrom1Opt, (void *) &si1);
        int iret2 = pthread_create(&thread2, NULL, sumFrom1Opt, (void *) &si2);
        int iret3 = pthread_create(&thread3, NULL, sumFrom1Opt, (void *) &si3);
        pthread_join(thread1, NULL);
        pthread_join(thread2, NULL);
        pthread_join(thread3, NULL);
        gettimeofday(&t2, NULL);
        // compute and print the elapsed time in millisec
        double elapsedTimeMs = (t2.tv_sec - t1.tv_sec) * 1000.0;      // sec to ms
        elapsedTimeMs += (t2.tv_usec - t1.tv_usec) / 1000.0;   // us to ms
        printf("Time taken: %f milliseconds\n", (elapsedTimeMs));
        printf("Thread 1 returns: %d - sum: %lld\n", iret1, si1.sum);
        printf("Thread 2 returns: %d - sum: %lld\n", iret2, si2.sum);
        printf("Thread 3 returns: %d - sum: %lld\n\n", iret3, si3.sum);
    }

    {
        printf("Parallel execution (cache friendly w/ local variable)\n");
        pthread_t thread1;
        pthread_t thread2;
        pthread_t thread3;
        gettimeofday(&t1, NULL);
        int iret1 = pthread_create(&thread1, NULL, sumFrom1OptCacheLocal, (void *) &osi1);
        int iret2 = pthread_create(&thread2, NULL, sumFrom1OptCacheLocal, (void *) &osi2);
        int iret3 = pthread_create(&thread3, NULL, sumFrom1OptCacheLocal, (void *) &osi3);
        pthread_join(thread1, NULL);
        pthread_join(thread2, NULL);
        pthread_join(thread3, NULL);
        gettimeofday(&t2, NULL);
        // compute and print the elapsed time in millisec
        double elapsedTimeMs = (t2.tv_sec - t1.tv_sec) * 1000.0;      // sec to ms
        elapsedTimeMs += (t2.tv_usec - t1.tv_usec) / 1000.0;   // us to ms
        printf("Time taken: %f milliseconds\n", (elapsedTimeMs));
        printf("Thread 1 returns: %d - sum: %lld\n", iret1, osi1.sum);
        printf("Thread 2 returns: %d - sum: %lld\n", iret2, osi2.sum);
        printf("Thread 3 returns: %d - sum: %lld\n\n", iret3, osi3.sum);
    }



    return 0;
}