# Empty dependencies file for counter_lock.
# This may be replaced when dependencies are built.
