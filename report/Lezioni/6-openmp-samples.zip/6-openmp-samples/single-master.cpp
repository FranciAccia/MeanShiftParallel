#include <cstdio>
#include "omp.h"

int main() {

#pragma omp parallel num_threads(4)
    {
        int tid = omp_get_thread_num();
        printf("Thread %d: starting\n", tid);

#pragma omp single
        {
            printf("  SINGLE: Executed by thread %d only\n",
                   omp_get_thread_num());
        }
        // Implicit barrier after single

#pragma omp master
{
    printf("  MASTER: Executed by thread %d only (no barrier)\n",
           omp_get_thread_num());
}
        // NO implicit barrier after master

        printf("Thread %d: finishing\n", tid);
    }
}