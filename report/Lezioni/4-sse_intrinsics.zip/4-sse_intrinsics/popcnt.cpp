#include <iostream>
#include <nmmintrin.h>

#include "Timer.h"

// XXX test this code in Debug mode

//types and constants used in the functions below

const uint64_t m1  = 0x5555555555555555; //binary: 0101...
const uint64_t m2  = 0x3333333333333333; //binary: 00110011..
const uint64_t m4  = 0x0f0f0f0f0f0f0f0f; //binary:  4 zeros,  4 ones ...
const uint64_t m8  = 0x00ff00ff00ff00ff; //binary:  8 zeros,  8 ones ...
const uint64_t m16 = 0x0000ffff0000ffff; //binary: 16 zeros, 16 ones ...
const uint64_t m32 = 0x00000000ffffffff; //binary: 32 zeros, 32 ones
const uint64_t hff = 0xffffffffffffffff; //binary: all ones
const uint64_t h01 = 0x0101010101010101; //the sum of 256 to the power of 0,1,2,3...

//This uses fewer arithmetic operations than any other known
//implementation on machines with slow multiplication.
//It uses 17 arithmetic operations.
int popcount_2(uint64_t x) {
    x -= (x >> 1) & m1;             //put count of each 2 bits into those 2 bits
    x = (x & m2) + ((x >> 2) & m2); //put count of each 4 bits into those 4 bits
    x = (x + (x >> 4)) & m4;        //put count of each 8 bits into those 8 bits
    x += x >>  8;  //put count of each 16 bits into their lowest 8 bits
    x += x >> 16;  //put count of each 32 bits into their lowest 8 bits
    x += x >> 32;  //put count of each 64 bits into their lowest 8 bits
    return x & 0x7f;
}

//This uses fewer arithmetic operations than any other known
//implementation on machines with fast multiplication.
//It uses 12 arithmetic operations, one of which is a multiply.
int popcount_3(uint64_t x) {
    x -= (x >> 1) & m1;             //put count of each 2 bits into those 2 bits
    x = (x & m2) + ((x >> 2) & m2); //put count of each 4 bits into those 4 bits
    x = (x + (x >> 4)) & m4;        //put count of each 8 bits into those 8 bits
    return (x * h01)>>56;  //returns left 8 bits of x + (x<<8) + (x<<16) + (x<<24) + ...
}


int main ()
{
    uint64_t a = 0x123456789ABCDEF0;

    Timer timer;
    auto max_loop = static_cast<long long>(10e2);
    int res;

    // intrinsic
    timer.start();
    for (long i = 0; i < max_loop; i++)
        for (long j = 0; j < max_loop; j++)
            for (long j = 0; j < max_loop; j++)
                res = _mm_popcnt_u64(a);
    timer.stop();
    std::cout << "time _mm_popcnt_u64: " << timer.getElapsedTimeInMicroSec() << " us \n";
    std::cout << "Result res should be 32: " << res << std::endl;

    // slow mul
    timer.start();
    for (long i = 0; i < max_loop; i++)
        for (long j = 0; j < max_loop; j++)
            for (long j = 0; j < max_loop; j++)
                res = popcount_2(a);
    timer.stop();
    std::cout << "time popcount_2: " << timer.getElapsedTimeInMicroSec() << " us \n";
    std::cout << "Result res should be 32: " << res << std::endl;

    // fast mul
    timer.start();
    for (long i = 0; i < max_loop; i++)
        for (long j = 0; j < max_loop; j++)
            for (long j = 0; j < max_loop; j++)
                res = popcount_3(a);
    timer.stop();
    std::cout << "time popcount_3: " << timer.getElapsedTimeInMicroSec() << " us \n";
    std::cout << "Result res should be 32: " << res << std::endl;

    return 0;
}