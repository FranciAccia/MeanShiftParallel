file(REMOVE_RECURSE
  "CMakeFiles/matrix_cache_friendly_access.dir/matrix_cache_friendly_access.cpp.o"
  "CMakeFiles/matrix_cache_friendly_access.dir/matrix_cache_friendly_access.cpp.o.d"
  "matrix_cache_friendly_access"
  "matrix_cache_friendly_access.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matrix_cache_friendly_access.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
