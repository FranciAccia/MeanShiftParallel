file(REMOVE_RECURSE
  "CMakeFiles/threadprivate-tester.dir/threadprivate-tester.cpp.o"
  "CMakeFiles/threadprivate-tester.dir/threadprivate-tester.cpp.o.d"
  "threadprivate-tester"
  "threadprivate-tester.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/threadprivate-tester.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
