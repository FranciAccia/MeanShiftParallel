file(REMOVE_RECURSE
  "CMakeFiles/openmp_producer_consumer_cpp.dir/ConcurrentQueue.cpp.o"
  "CMakeFiles/openmp_producer_consumer_cpp.dir/main.cpp.o"
  "CMakeFiles/openmp_producer_consumer_cpp.dir/utilities.cpp.o"
  "openmp_producer_consumer_cpp"
  "openmp_producer_consumer_cpp.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/openmp_producer_consumer_cpp.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
