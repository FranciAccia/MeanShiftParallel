# Empty dependencies file for sse_vector_matrix.
# This may be replaced when dependencies are built.
