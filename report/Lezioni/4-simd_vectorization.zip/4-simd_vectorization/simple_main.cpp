int main() {
    int n = 10000;
    int *a = new int[n];

    // initialize
    for (int i = 0; i < n; ++i) {
        a[i] = 1;
    }
    // sum
    int sum = 0;
    for (int i = 0; i < n; ++i) {
        sum += a[i];
    }
    delete[] a;
    return sum; // to avoid excessive optimization... the loops may be simply eliminated
}