file(REMOVE_RECURSE
  "CMakeFiles/counter_bad.dir/counter_bad.cpp.o"
  "CMakeFiles/counter_bad.dir/counter_bad.cpp.o.d"
  "counter_bad"
  "counter_bad.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/counter_bad.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
