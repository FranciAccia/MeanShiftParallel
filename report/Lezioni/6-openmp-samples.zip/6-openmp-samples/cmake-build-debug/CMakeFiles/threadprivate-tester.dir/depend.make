# Empty dependencies file for threadprivate-tester.
# This may be replaced when dependencies are built.
