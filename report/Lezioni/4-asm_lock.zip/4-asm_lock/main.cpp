#include <stdlib.h>
#include <thread>

#define NUM_ITERS 10000
#define NUM_THREADS 10

int counter = 0; // shared memory variable

void asm_inc() {
    int* p_counter = &counter;
    for (int i = 0; i < NUM_ITERS; ++i) {
        // XXX compile activating one of the two following lines and check different results
        __asm__("incl (%0) \n\t" : : "r" (p_counter)); // incl is not atomic: it's a load followed by add, then followed by store
        //__asm__("lock incl (%0) \n\t" : : "r" (p_counter)); // lock prefix can be added to some instructions.
        // to lock code sequences use xchg or cmpxchg
        // See http://davidad.github.io/blog/2014/03/23/concurrency-primitives-in-intel-64-assembly/
    }
}

int main() {
    std::thread t[NUM_THREADS];
    // start threads
    for (int i = 0; i < NUM_THREADS; ++i) {
        t[i] = std::thread(asm_inc);
    }
    // wait threads completion
    for (int i = 0; i < NUM_THREADS; ++i) {
        t[i].join();
    }
    printf("Counter value: %i - expected: %i\n", counter, NUM_ITERS*NUM_THREADS);
    return 0;
}