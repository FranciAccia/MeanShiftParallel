file(REMOVE_RECURSE
  "CMakeFiles/parfor-tester.dir/parfor-tester.cpp.o"
  "CMakeFiles/parfor-tester.dir/parfor-tester.cpp.o.d"
  "parfor-tester"
  "parfor-tester.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/parfor-tester.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
