#include <iostream>

#define CACHE_LINE_SIZE 64

// C++ (using C++11 alignment syntax)
template<typename T>
struct alignas(CACHE_LINE_SIZE) cache_line_storage {
    alignas(CACHE_LINE_SIZE) T data;
    char pad[CACHE_LINE_SIZE > sizeof(T)
             ? CACHE_LINE_SIZE - sizeof(T)
             : 1];
};

template<typename T>
struct alignas(CACHE_LINE_SIZE) cache_line_storage2 {
    alignas(CACHE_LINE_SIZE) T data;
    alignas(CACHE_LINE_SIZE) T data2; // TODO try this !
    //T data2;  // TODO try also this !
    char pad[CACHE_LINE_SIZE > sizeof(T)
             ? CACHE_LINE_SIZE - sizeof(T)
             : 1];
};


using namespace std;

int main() {
    cache_line_storage<int> myData;
    cache_line_storage2<float> myData2;

    cout << " -- cache_line_storage<int> -- " << endl;
    cout << "Struct address: " << &myData << endl;
    cout << "Field address " << &(myData.data) << endl;
    cout << "Struct size: " << sizeof(myData) << endl;
    cout << " -- cache_line_storage2<float> -- " << endl;
    cout << "Struct2 address: " << &myData2 << endl;
    cout << "Field address: " << &(myData2.data) << endl;
    cout << "Field2 address: " << &(myData2.data2) << endl;
    cout << "Field/Field2 distance: " << (&(myData2.data2) - &(myData2.data)) * sizeof(int) << endl;
    cout << "Struct2 size: " << sizeof(myData2) << endl;
}