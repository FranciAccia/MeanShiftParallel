#include <stdio.h>
#include <omp.h>

#define CACHE_LINE_SIZE 64
#define N 900000000

typedef struct {
    int x;
} Data;

typedef struct {
    int x;
    // Uncomment padding to fix false sharing
    char pad[CACHE_LINE_SIZE - sizeof(int)];
} Padded_Data;

Data arr[2];
Padded_Data pad_arr[2];

int main() {
    printf("Struct w/o padding");
    double start = omp_get_wtime();
#pragma omp parallel num_threads(2)
    {
        int tid = omp_get_thread_num();
        for (long i = 0; i < N; i++) {
            arr[tid].x++;
        }
    }
    double end = omp_get_wtime();
    printf("Time: %.3f sec, arr[0]=%d arr[1]=%d\n", end - start, arr[0].x, arr[1].x);

    printf("Padded array:\n");
    start = omp_get_wtime();
#pragma omp parallel num_threads(2)
    {
        int tid = omp_get_thread_num();
        for (long i = 0; i < N; i++) {
            pad_arr[tid].x++;
        }
    }
    end = omp_get_wtime();
    printf("Time: %.3f sec, pad_arr[0]=%d pad_arr[1]=%d\n", end - start, pad_arr[0].x, pad_arr[1].x);
}