CMakeFiles/simd_vectorization.dir/simple_main.cpp.o: \
  /Users/bertini/Documents/presentazioni/lezioni/Parallel\ Programming\ 2025-2026/workspace/CLion/4-simd_vectorization/simple_main.cpp
