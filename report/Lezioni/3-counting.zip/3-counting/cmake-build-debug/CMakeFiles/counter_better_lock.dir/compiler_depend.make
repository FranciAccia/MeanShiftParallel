# Empty compiler generated dependencies file for counter_better_lock.
# This may be replaced when dependencies are built.
