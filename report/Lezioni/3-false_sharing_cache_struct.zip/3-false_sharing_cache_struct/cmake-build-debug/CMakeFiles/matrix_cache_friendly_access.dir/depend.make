# Empty dependencies file for matrix_cache_friendly_access.
# This may be replaced when dependencies are built.
