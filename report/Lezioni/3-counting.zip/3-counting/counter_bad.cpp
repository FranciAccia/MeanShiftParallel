#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <pthread.h>

#include "params.h"

int counter = 0;
int buffer[BUFFER_SIZE];

void prepareBuffer() {
    for (long i = 0; i < BUFFER_SIZE; ++i) {
        buffer[i] = i % 10;
    }
}

void* count3orig(void* data) {
    int* thread_id = (int*) data;
    int length_per_thread = BUFFER_SIZE / NUM_THREADS;
    int start = *thread_id * length_per_thread;
    for (int i = start; i < start + length_per_thread; i++) {
        if (buffer[i] == 3) {
            counter++;
        }
    }
    return NULL;
}

int main() {
    prepareBuffer();
    pthread_t thread_ids[NUM_THREADS];
    int id[NUM_THREADS];

    timeval t1, t2;
    gettimeofday(&t1, NULL);
    for (int times=0; times < REPETITIONS; times++) {
        for (int i = 0; i < NUM_THREADS; i++) {
            id[i] = i;
            pthread_create(&thread_ids[i], NULL, count3orig, (void*) (id + i));
        }
        for (int i = 0; i < NUM_THREADS; i++)
            pthread_join(thread_ids[i], NULL);
    }
    gettimeofday(&t2, NULL);
    double elapsedTimeMs = (t2.tv_sec - t1.tv_sec) * 1000.0;      // sec to ms
    elapsedTimeMs += (t2.tv_usec - t1.tv_usec) / 1000.0;   // us to ms
    printf("Time taken: %f milliseconds\n", elapsedTimeMs);
    printf("3 Counter: %d\n", counter);
}