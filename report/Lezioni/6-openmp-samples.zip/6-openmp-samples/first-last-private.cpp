#include <stdio.h>
#include <omp.h>

int main(void) {
    int i = 10;
    int j = 17;

#pragma omp parallel private(i, j)
    {
        int num_thread = omp_get_thread_num();
        j = 1000 + num_thread;
        printf("thread %d: i = %d - j = %d\n", num_thread, i, j);
    }

    printf("i = %d - j = %d\n", i, j);

#pragma omp parallel firstprivate(i)
    {
        int num_thread = omp_get_thread_num();
#pragma omp for lastprivate(j)
        for (int k = 0; k < 3; k++)
            j = (1000 * k);
        printf("thread %d: i = %d - j = %d\n", num_thread, i, j);
        j += num_thread;
    }

    printf("i = %d - j = %d\n", i, j);

    int x = 44;
    printf("x = %d\n", x);
#pragma omp parallel for firstprivate(x) lastprivate(x)
    for (i = 0; i <= 10; i++) {
        x += i;
        printf("Thread number: %d - x: %d\n", omp_get_thread_num(), x);
    }
    printf("x = %d\n", x);

    return 0;
}