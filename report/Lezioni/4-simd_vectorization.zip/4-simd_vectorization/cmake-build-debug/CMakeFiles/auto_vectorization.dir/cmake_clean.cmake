file(REMOVE_RECURSE
  "CMakeFiles/auto_vectorization.dir/auto_vectorization.cpp.o"
  "CMakeFiles/auto_vectorization.dir/auto_vectorization.cpp.o.d"
  "auto_vectorization"
  "auto_vectorization.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/auto_vectorization.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
