#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define SIZE 1000000
#define ITERATIONS 10000

// AoS structure
typedef struct {
    float x;
    float y;
    float z;
    float result;
} Point_AoS;

// SoA structure
typedef struct {
    float* x;
    float* y;
    float* z;
    float* result;
} Points_SoA;

// Function to initialize data
void initialize_data(Point_AoS* aos, Points_SoA* soa) {
    for (int i = 0; i < SIZE; i++) {
        float x = (float)rand() / RAND_MAX;
        float y = (float)rand() / RAND_MAX;
        float z = (float)rand() / RAND_MAX;

        aos[i].x = x;
        aos[i].y = y;
        aos[i].z = z;

        soa->x[i] = x;
        soa->y[i] = y;
        soa->z[i] = z;
    }
}

// Compare ASM code for process_aos and process_soa in godbolt.org,
// activate -O3 optimization and check the SIMD code !

// Function to process AoS data
void process_aos(Point_AoS* data) {
    for (int i = 0; i < SIZE; i++) {
        data[i].result = data[i].x * data[i].y + data[i].z;
    }
}

// Function to process SoA data (can be optimized up to FMA adding -mfma to the compiler settings !)
void process_soa(Points_SoA* data) {
    for (int i = 0; i < SIZE; i++) {
        data->result[i] = data->x[i] * data->y[i] + data->z[i];
    }
}

// Function to measure execution time
double measure_time(void (*func)(void*), void* data) {
    clock_t start = clock();

    for (int i = 0; i < ITERATIONS; i++) {
        func(data);
    }

    clock_t end = clock();
    return ((double)(end - start)) / CLOCKS_PER_SEC;
}

int main() {
    // Allocate memory
    Point_AoS* aos_data = (Point_AoS*)malloc(SIZE * sizeof(Point_AoS));
    Points_SoA soa_data;
    soa_data.x = (float*)malloc(SIZE * sizeof(float));
    soa_data.y = (float*)malloc(SIZE * sizeof(float));
    soa_data.z = (float*)malloc(SIZE * sizeof(float));
    soa_data.result = (float*)malloc(SIZE * sizeof(float));

    // Initialize data
    initialize_data(aos_data, &soa_data);

    // Measure AoS performance
    double aos_time = measure_time((void (*)(void*))process_aos, aos_data);

    // Measure SoA performance
    double soa_time = measure_time((void (*)(void*))process_soa, &soa_data);

    // Print results
    printf("AoS time: %.6f seconds\n", aos_time);
    printf("SoA time: %.6f seconds\n", soa_time);
    printf("Speedup: %.2fx\n", aos_time / soa_time);

    // to guarantee function execution
    printf("\n\nAoS result: %.2f - SoA result: %2f\n", aos_data[0].result, soa_data.result[0]);


    // Free memory
    free(aos_data);
    free(soa_data.x);
    free(soa_data.y);
    free(soa_data.z);
    free(soa_data.result);

    return 0;
}