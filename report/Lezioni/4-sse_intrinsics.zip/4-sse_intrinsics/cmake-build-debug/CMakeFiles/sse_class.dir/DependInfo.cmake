
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-sse_intrinsics/Timer.cpp" "CMakeFiles/sse_class.dir/Timer.cpp.o" "gcc" "CMakeFiles/sse_class.dir/Timer.cpp.o.d"
  "/Users/bertini/Documents/presentazioni/lezioni/Parallel Programming 2025-2026/workspace/CLion/4-sse_intrinsics/sse_class.cpp" "CMakeFiles/sse_class.dir/sse_class.cpp.o" "gcc" "CMakeFiles/sse_class.dir/sse_class.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
