# Empty compiler generated dependencies file for single-master.
# This may be replaced when dependencies are built.
