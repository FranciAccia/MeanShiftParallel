file(REMOVE_RECURSE
  "CMakeFiles/bad-flush_producer_consumer.dir/bad-flush_producer_consumer.cpp.o"
  "CMakeFiles/bad-flush_producer_consumer.dir/bad-flush_producer_consumer.cpp.o.d"
  "bad-flush_producer_consumer"
  "bad-flush_producer_consumer.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/bad-flush_producer_consumer.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
