file(REMOVE_RECURSE
  "CMakeFiles/counter_better_lock.dir/counter_better_lock.cpp.o"
  "CMakeFiles/counter_better_lock.dir/counter_better_lock.cpp.o.d"
  "counter_better_lock"
  "counter_better_lock.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/counter_better_lock.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
