file(REMOVE_RECURSE
  "CMakeFiles/timed_simd_vectorization.dir/Timer.cpp.o"
  "CMakeFiles/timed_simd_vectorization.dir/Timer.cpp.o.d"
  "CMakeFiles/timed_simd_vectorization.dir/timed_main.cpp.o"
  "CMakeFiles/timed_simd_vectorization.dir/timed_main.cpp.o.d"
  "timed_simd_vectorization"
  "timed_simd_vectorization.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/timed_simd_vectorization.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
