#include <iostream>
#include <vector>
#include <omp.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

// change OMP_NUM_THREADS environment variable to run with 1 to X threads...
// check configuration in drop down menu
// XXX check working directory so that ./images and ./output are valid !

static const int maxImageIdx = 564;

struct STBImage {
    int width{0}, height{0}, channels{0};
    uint8_t *rgb_image{nullptr};
    std::string filename{};

    bool loadImage(const std::string &name) {
        rgb_image = stbi_load(name.c_str(), &width, &height, &channels, 3);
        if (!rgb_image)
            return false;
        else {
            filename = name;
            return true;
        }
    }

    void saveImage(const std::string &newName) const {
        stbi_write_jpg(newName.c_str(), width, height, channels, rgb_image, width * channels);
    }
};


std::vector<STBImage> load_images(int start_idx, int end_idx) {
    std::vector<STBImage> img_lst;

    double startTime = omp_get_wtime();
    for (unsigned long i = start_idx; i <= end_idx; i++) {
        std::string filename = "./images/" + std::to_string(i) + ".jpg";
        STBImage img;
        bool isRead = img.loadImage(filename);
        if (!isRead) {
            std::cerr << "ERROR: Failed to load image: " << filename << std::endl;
        } else {
            img_lst.push_back(img);
        }
    }
    double endTime = omp_get_wtime();
    std::cout << "Images load time: " << endTime - startTime << std::endl << std::endl;
    std::cout << "Images loaded: " << img_lst.size() << std::endl;

    return img_lst;
}


int main() {
    std::cout << "Using # " << omp_get_max_threads() << " threads." << std::endl;
    auto images = load_images(1, maxImageIdx);
    std::cout << "Images loaded #: " << images.size() << " - expected #: " << maxImageIdx << std::endl;
    std::cout << "Saving images..." << std::endl;
    for(int i = 0; i < 4; i++) {
        std::cout << images[i].filename << " - width: " << images[i].width << " - height: " << images[i].height
                  << std::endl;
        std::string output_filename = "./output/output-" + std::to_string(i) + ".jpg";
        images[i].saveImage(output_filename);
    }
}
