#ifndef OPENMP_PRODUCER_CONSUMER_CPP_CONCURRENTQUEUE_H
#define OPENMP_PRODUCER_CONSUMER_CPP_CONCURRENTQUEUE_H

#include <omp.h>

template <typename T>
class NodeTemplate {
public:
    T value;
    NodeTemplate<T>* next;
};

template <typename T>
class ConcurrentQueue {
public:
    ConcurrentQueue(int numProd) {
        NodeTemplate<T>* tmp = new NodeTemplate<T>();
        tmp->next = 0;
        head = tail = tmp;
        enqueued = dequeued = 0;
        omp_init_lock(&headLock);
        omp_init_lock(&tailLock);
        numProducers = numProd;
    }
    ~ConcurrentQueue() {
        NodeTemplate<T>* curr = head;
        NodeTemplate<T>* tmp;

        while (curr != 0) {
            tmp = curr;
            curr = curr->next;
            delete(tmp);
        }
        enqueued = dequeued = 0;
        head = tail = 0;
        omp_destroy_lock(&headLock);
        omp_destroy_lock(&tailLock);
    }
    void enqueue(T value) {
        NodeTemplate<T>* tmp = new NodeTemplate<T>();
        tmp->value = value;
        tmp->next  = 0;
        omp_set_lock(&tailLock);
        tail->next = tmp;
        tail = tmp;
        enqueued++;
        omp_unset_lock(&tailLock);
    }
    bool dequeue(T& result) {
        omp_set_lock(&headLock);
        NodeTemplate<T>* tmp = head;
        NodeTemplate<T>* newHead = tmp->next;
        if (newHead == 0) {
            omp_unset_lock(&headLock);
            return false; // queue was empty
        }
        result = newHead->value;
        head = newHead;
        dequeued++;
        omp_unset_lock(&headLock);
        delete tmp;
        return true;
    }
    bool isDone() {
#pragma omp flush(dequeued, enqueued, numProducers)
        if(enqueued-dequeued==0 && numProducers == 0)
            return true;
        else
            return false;
    }
    void producerEnd() {
#pragma omp atomic
        numProducers--;
    }

private:
    NodeTemplate<T>* head;
    NodeTemplate<T>* tail;
    omp_lock_t headLock;
    omp_lock_t tailLock;
    int enqueued;
    int dequeued;
    int numProducers;
};


#endif //OPENMP_PRODUCER_CONSUMER_CPP_CONCURRENTQUEUE_H
