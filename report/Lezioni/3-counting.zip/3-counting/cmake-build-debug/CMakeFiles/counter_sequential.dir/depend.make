# Empty dependencies file for counter_sequential.
# This may be replaced when dependencies are built.
