/*
 * BRANCH PREDICTION DEMONSTRATION
 * Shows impact of predictable vs unpredictable branches
 */

#include <iostream>
#include <vector>
#include <chrono>
#include <algorithm>
#include <random>

const int SIZE = 32768;
const int ITERATIONS = 10000;

long long test_branched(const std::vector<int>& data) {
    long long sum = 0;
    
    auto start = std::chrono::high_resolution_clock::now();
    
    for (int iter = 0; iter < ITERATIONS; iter++) {
        for (int i = 0; i < SIZE; i++) {
            if (data[i] >= 128) {  // Will be a predictable pattern after sorting
                sum += data[i];
            }
        }
    }
    if (sum == 0) std::cout << ""; // Prevent optimization
    
    auto end = std::chrono::high_resolution_clock::now();
    return std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
}


long long test_branchless(const std::vector<int>& data) {
    long long sum = 0;
    
    auto start = std::chrono::high_resolution_clock::now();
    
    for (int iter = 0; iter < ITERATIONS; iter++) {
        for (int i = 0; i < SIZE; i++) {
            // Branchless: use arithmetic instead of if
            int mask = -(data[i] >= 128);  // -1 if true, 0 if false
            sum += data[i] & mask;
        }
    }
    if (sum == 0) std::cout << ""; // Prevent optimization
    
    auto end = std::chrono::high_resolution_clock::now();
    return std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
}

int main() {
    // Generate random data
    std::vector<int> data(SIZE);
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 255);
    
    for (int i = 0; i < SIZE; i++) {
        data[i] = dis(gen);
    }
    
    std::cout << "Branch Prediction Performance Test\n";
    std::cout << "===================================\n\n";
    
    // Test with unsorted (unpredictable branches)
    auto unsorted_time = test_branched(data);
    std::cout << "Unsorted (unpredictable branches): " << unsorted_time << " ms\n";
    
    // Sort the data to make branches predictable
    std::sort(data.begin(), data.end());
    
    // Test with sorted (predictable branches)
    auto sorted_time = test_branched(data);
    std::cout << "Sorted (predictable branches):     " << sorted_time << " ms\n";
    
    // Test branchless version
    auto branchless_time = test_branchless(data);
    std::cout << "Branchless version:                " << branchless_time << " ms\n";
    
    std::cout << "\nSpeedup from sorting: " << (double)unsorted_time / sorted_time << "x\n";
    std::cout << "Branch mispredictions cause severe slowdowns!\n";
    
    return 0;
}

/*
 * TYPICAL RESULTS:
 * Unsorted: ~400-600 ms (many branch mispredictions)
 * Sorted:   ~100-150 ms (branch predictor works perfectly)
 * Speedup:  3-5x just from making branches predictable!
 * 
 * The branchless version may be faster than unsorted but slower than sorted.
 */