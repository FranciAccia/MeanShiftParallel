#include <iostream>
#include <iomanip>
#include <string>
#include <chrono>
#include <vector>
#include <numeric>

using namespace std;
using namespace chrono;

const long NUM_ELEMENTS = 500'000'000;  // with less elements the AoS may be faster in Release mode
                                        // because it's easier to vectorize its loops

//
// Array of structures approach
//
struct Point {
    Point(int x, int y) : x(x), y(y) {}

    int x;
    int y;
};

struct Particle {
    Particle(Point pos, Point vel, int id) : position(pos.x, pos.y), velocity(vel.x, vel.y), id(id) {}

    Point position;
    Point velocity;
    int id;
};

void addParticle(std::vector<Particle> &v, Particle &&p) {
    v.push_back(std::move(p));
}

int update_positions(std::vector<Particle> &particles) {
    int num_processed = 0;
    for (auto &p: particles) {
        p.position.x += p.velocity.x;
        p.position.y += p.velocity.y; // try commenting out y update in AoS and SoA
        num_processed++;
    }
    return num_processed;
}

int count_ids(const std::vector<Particle> &particles, int id) {
    int count = 0;
    for (const auto &p: particles) {
        if (p.id == id)
            count++;
    }
    return count;
}


//
// Structure of arrays approach
//
struct Particles {
    int numParticles = 0;
    std::vector<int> xPos;
    std::vector<int> yPos;
    std::vector<int> xVelocity;
    std::vector<int> yVelocity;
    std::vector<int> id;

    void addParticle(int x, int y, int xv, int yv, int id) {
        xPos.push_back(x);
        yPos.push_back(y);
        xVelocity.push_back(xv);
        yVelocity.push_back(yv);
        this->id.push_back(id);
        numParticles++;
    }

    int update_positions() {
        int num_processed = 0;
        for (int i = 0; i < numParticles; i++) {
            xPos[i] += xVelocity[i];
            num_processed++;
        }
        for (int i = 0; i < numParticles; i++) {
            yPos[i] += yVelocity[i]; // try commenting out y update in AoS and SoA
            num_processed++;
        }
        return num_processed;
    }

    int count_ids(int id) const {
        int count = 0;
        for (int i = 0; i < numParticles; i++) {
            if (this->id[i] == id)
                count++;
        }
        return count;
    }
};


int main() {
    vector<Particle> v1;
    v1.reserve(NUM_ELEMENTS);
    for (int i = 0; i < NUM_ELEMENTS; ++i)
        addParticle(v1, Particle(Point(rand() % 0xFFFF, rand() % 0xFFFF), Point(rand() % 0xFFFF, rand() % 0xFFFF), rand() % 0xFFFF));

    // AoS
    auto start_time = high_resolution_clock::now();
    // use sum to avoid elimination of function calls due to compiler optimization
    auto sum = update_positions(v1);
    sum += count_ids(v1, 0);
    auto end_time = high_resolution_clock::now();
    auto aos_time = duration_cast<microseconds>(end_time - start_time).count() / 1000.f;
    cout << fixed << setprecision(3);
    cout << "AoS duration " << aos_time << " ms" << endl;
    v1.clear();
    v1.shrink_to_fit();

    // SoA
    Particles p;
    p.xPos.reserve(NUM_ELEMENTS);
    p.yPos.reserve(NUM_ELEMENTS);
    p.xVelocity.reserve(NUM_ELEMENTS);
    p.yVelocity.reserve(NUM_ELEMENTS);
    p.id.reserve(NUM_ELEMENTS);
    for (int i = 0; i < NUM_ELEMENTS; ++i)
        p.addParticle(rand() % 0xFFFF, rand() % 0xFFFF, rand() % 0xFFFF, rand() % 0xFFFF, rand() % 0xFFFF);

    start_time = high_resolution_clock::now();
    sum += p.update_positions();
    sum += p.count_ids(0);
    end_time = high_resolution_clock::now();
    auto soa_time = duration_cast<microseconds>(end_time - start_time).count() / 1000.f;
    cout << "SoA duration " << soa_time << " ms" << endl;

    cout << "Speedup SoA vs. AoS: " << float(aos_time) / soa_time << endl;
    return sum;  // to avoid elimination of function calls due to compiler optimization
}