#include <iostream>
#include <xmmintrin.h>

#include "Timer.h"
const auto repetitions = static_cast<long long>(10e2);

// XXX test this code in Release mode

// original code from https://www.cs.uaf.edu/2011/spring/cs641/lecture/02_22_sse_branching.html

class fourfloats; /* forward declaration */

/* Wrapper around four bitmasks: 0 if false, all-ones (NAN) if true.
  This class is used to implement comparisons on SSE registers.
*/
class fourmasks {
    __m128 mask;
public:
    fourmasks(__m128 m) { mask = m; }

    __m128 if_then_else(fourfloats dthen, fourfloats delse);
};

/* Nice wrapper around __m128:
   it represents four floating point values. */
class fourfloats {
    __m128 v;
public:
    fourfloats(float onevalue) { v = _mm_load1_ps(&onevalue); }

    fourfloats(__m128 ssevalue) { v = ssevalue; } // put in an SSE value
    operator __m128() const { return v; } // take out an SSE value

    fourfloats(const float* fourvalues) { v = _mm_load_ps(fourvalues); }

    void store(float* fourvalues) { _mm_store_ps(fourvalues, v); }

/* arithmetic operations return blocks of floats */
    fourfloats operator+(const fourfloats &right) {
        return _mm_add_ps(v, right.v);
    }

/* comparison operations return blocks of masks (bools) */
    fourmasks operator<(const fourfloats &right) {
        return _mm_cmplt_ps(v, right.v);
    }
};

// transforms if (x) y=a; else y=b;   into:
// y=(x&a)|((~x)&b);
// (assumes x is all zero bits, or all one bits)
inline __m128 fourmasks::if_then_else(fourfloats dthen, fourfloats delse) {
    return _mm_and_ps(mask, dthen) +
           _mm_andnot_ps(mask, delse);
}

float src[4] = {1.0, 5.0, 3.0, 4.0};
float dest[4];

int main() {
    Timer timer;

    timer.start();
    for (long int j = 0; j < repetitions; j++) {
        for (long int j = 0; j < repetitions; j++) {
            // Serial code
            for (int i = 0; i < 4; i++) {
                if (src[i] < 4.0)
                    dest[i] = src[i] * 2.0;
                else
                    dest[i] = 17.0;
            }
        }
    }
    timer.stop();
    std::cout << "time basic_mul: " << timer.getElapsedTimeInMicroSec() << " us \n";
    for (int i = 0; i < 4; i++)
        std::cout << "dest[" << i << "]=" << dest[i] << std::endl;

    // Parallel code
    fourfloats s(src);
    timer.start();
    for (long int j = 0; j < repetitions; j++) {
        for (long int j = 0; j < repetitions; j++) {
            fourfloats d = (s < 4.0).if_then_else(s + s, 17.0);
            d.store(dest);
        }
    }
    timer.stop();
    std::cout << "time SSE: " << timer.getElapsedTimeInMicroSec() << " us \n";

    for (int i = 0; i < 4; i++)
        std::cout << "dest[" << i << "]=" << dest[i] << std::endl;
    return 0;
}