#include <omp.h> // for OpenMP library functions
#include <iostream>

int main() {
#ifdef _OPENMP
    std::cout << "_OPNMP defined" << std::endl;
    int num_nested = omp_get_nested();
    std::cout << "Nested: " << num_nested << std::endl;
    // try commenting/uncommenting the following lines and check the value of nthreads
    if (num_nested == 0) {
        omp_set_nested(1);
        std::cout << "Nested after set: " << omp_get_nested() << std::endl;
    }
#endif
    int tid;
    int mtid;

#pragma omp parallel private(mtid, tid)
    {
        mtid = omp_get_thread_num();
        int nthreads = omp_get_num_threads();
        printf("Parallel thread = %d/%d\n", mtid, nthreads);

#pragma omp parallel for
        for (int i = 0; i < 10; i++) {
            int fthreads = omp_get_num_threads();
            tid = omp_get_thread_num();
            printf("Loop thread = %d/%d/%d - i = %d\n", tid, fthreads, mtid, i);
        }

    }
    return 0;
}