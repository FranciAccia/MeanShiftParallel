# Empty dependencies file for sections-tester.
# This may be replaced when dependencies are built.
