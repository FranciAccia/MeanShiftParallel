# Empty dependencies file for auto_vectorization.
# This may be replaced when dependencies are built.
